# 免费部署方案对比

## 1. Railway（推荐）⭐

**优点**：免费、自动 HTTPS、内置数据库、一键部署
**缺点**：免费额度有限（每月 $5 或 500 小时）
**适合**：测试、小流量网站

### 部署步骤
```bash
# 1. Fork 本项目到 GitHub
# 2. 登录 https://railway.app/（用 GitHub 账号）
# 3. New Project → Deploy from GitHub repo
# 4. 选择仓库，自动部署
# 5. 获得域名：xxx.up.railway.app
```

---

## 2. Render

**优点**：免费、自动 HTTPS、支持自定义域名
**缺点**：免费实例 15 分钟无访问会休眠（冷启动慢）
**适合**：展示型网站

---

## 3. Fly.io

**优点**：全球 CDN、免费额度充足
**缺点**：需要信用卡验证（不扣费）
**适合**：需要全球访问速度

---

## 快速开始（Railway）

1. **Fork 仓库**
   - 访问 GitHub 仓库
   - 点击 Fork 按钮

2. **部署到 Railway**
   - 访问 https://railway.app/
   - New Project → Deploy from GitHub repo
   - 选择你的 Fork
   - 自动部署完成

3. **查看域名**
   - Railway Dashboard → 你的项目
   - 右侧显示默认域名（如 `xxx.up.railway.app`）
   - 点击即可访问！

4. **绑定自定义域名（可选）**
   - Settings → Domains → Custom Domain
   - 输入你的域名
   - 在域名商添加 CNAME 记录
   - 自动 SSL

---

## 一键部署按钮

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/yourusername/wosuo-store)

（需要将 `yourusername` 替换为实际 GitHub 用户名）
