import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Download, Eye, Package, Truck, XCircle, RotateCcw, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

interface IOrder {
  id: string;
  orderNo: string;
  customerName: string;
  customerPhone: string;
  totalAmount: number;
  payAmount: number;
  status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'completed' | 'cancelled' | 'refunding';
  payMethod: string;
  createTime: string;
  items: { name: string; image: string; quantity: number }[];
}

const mockOrders: IOrder[] = [
  {
    id: '1',
    orderNo: 'ORD202603140001',
    customerName: '张三',
    customerPhone: '138****8888',
    totalAmount: 14999.00,
    payAmount: 14999.00,
    status: 'pending',
    payMethod: '微信支付',
    createTime: '2026-03-14 10:30:00',
    items: [{ name: 'MacBook Pro', image: 'https://picsum.photos/seed/macbook/80/80', quantity: 1 }],
  },
  {
    id: '2',
    orderNo: 'ORD202603140002',
    customerName: '李四',
    customerPhone: '139****9999',
    totalAmount: 7999.00,
    payAmount: 7999.00,
    status: 'paid',
    payMethod: '支付宝',
    createTime: '2026-03-14 09:15:00',
    items: [{ name: 'iPhone 15 Pro', image: 'https://picsum.photos/seed/iphone/80/80', quantity: 1 }],
  },
  {
    id: '3',
    orderNo: 'ORD202603140003',
    customerName: '王五',
    customerPhone: '137****7777',
    totalAmount: 1899.00,
    payAmount: 1899.00,
    status: 'shipped',
    payMethod: '微信支付',
    createTime: '2026-03-13 16:45:00',
    items: [{ name: 'AirPods Pro', image: 'https://picsum.photos/seed/airpods/80/80', quantity: 1 }],
  },
  {
    id: '4',
    orderNo: 'ORD202603140004',
    customerName: '赵六',
    customerPhone: '136****6666',
    totalAmount: 4799.00,
    payAmount: 4599.00,
    status: 'delivered',
    payMethod: '微信支付',
    createTime: '2026-03-12 14:20:00',
    items: [{ name: 'iPad Air', image: 'https://picsum.photos/seed/ipad/80/80', quantity: 1 }],
  },
  {
    id: '5',
    orderNo: 'ORD202603140005',
    customerName: '钱七',
    customerPhone: '135****5555',
    totalAmount: 6299.00,
    payAmount: 6299.00,
    status: 'completed',
    payMethod: '支付宝',
    createTime: '2026-03-10 11:00:00',
    items: [{ name: 'Watch Ultra', image: 'https://picsum.photos/seed/watch/80/80', quantity: 1 }],
  },
  {
    id: '6',
    orderNo: 'ORD202603140006',
    customerName: '孙八',
    customerPhone: '134****4444',
    totalAmount: 11499.00,
    payAmount: 11499.00,
    status: 'cancelled',
    payMethod: '-',
    createTime: '2026-03-09 08:30:00',
    items: [{ name: 'Studio Display', image: 'https://picsum.photos/seed/display/80/80', quantity: 1 }],
  },
  {
    id: '7',
    orderNo: 'ORD202603140007',
    customerName: '周九',
    customerPhone: '133****3333',
    totalAmount: 2399.00,
    payAmount: 2399.00,
    status: 'refunding',
    payMethod: '微信支付',
    createTime: '2026-03-08 15:00:00',
    items: [{ name: 'Magic Keyboard', image: 'https://picsum.photos/seed/keyboard/80/80', quantity: 1 }],
  },
  {
    id: '8',
    orderNo: 'ORD202603140008',
    customerName: '吴十',
    customerPhone: '132****2222',
    totalAmount: 699.00,
    payAmount: 699.00,
    status: 'pending',
    payMethod: '微信支付',
    createTime: '2026-03-14 12:00:00',
    items: [{ name: 'Magic Mouse', image: 'https://picsum.photos/seed/mouse/80/80', quantity: 1 }],
  },
];

const statusConfig: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  pending: { label: '待付款', variant: 'secondary' },
  paid: { label: '待发货', variant: 'default' },
  shipped: { label: '待收货', variant: 'outline' },
  delivered: { label: '待评价', variant: 'outline' },
  completed: { label: '已完成', variant: 'outline' },
  cancelled: { label: '已取消', variant: 'outline' },
  refunding: { label: '售后中', variant: 'destructive' },
};

interface IAdminOrdersProps {}

const AdminOrders: React.FC<IAdminOrdersProps> = () => {
  const navigate = useNavigate();
  const [orders] = useState<IOrder[]>(mockOrders);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');

  const filteredOrders = orders.filter((order) => {
    const matchKeyword =
      searchKeyword === '' ||
      order.orderNo.includes(searchKeyword) ||
      order.customerName.includes(searchKeyword) ||
      order.customerPhone.includes(searchKeyword);
    const matchStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchKeyword && matchStatus;
  });

  const handleExport = () => {
    const headers = ['订单号', '客户名称', '客户电话', '订单金额', '实付金额', '支付方式', '状态', '下单时间'];
    const rows = filteredOrders.map((order) => [
      order.orderNo,
      order.customerName,
      order.customerPhone,
      order.totalAmount.toFixed(2),
      order.payAmount.toFixed(2),
      order.payMethod,
      statusConfig[order.status]?.label || order.status,
      order.createTime,
    ]);
    const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `订单列表_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const columns = [
    {
      title: '订单信息',
      dataIndex: 'orderNo',
      key: 'orderNo',
      render: (_: string, record: IOrder) => (
        <div className="flex items-center gap-4">
          <div className="flex -space-x-2">
            {record.items.slice(0, 2).map((item, idx) => (
              <img
                key={idx}
                src={item.image}
                alt={item.name}
                className="w-10 h-10 rounded-lg border-2 border-white object-cover bg-gray-100"
              />
            ))}
          </div>
          <div>
            <p className="font-medium text-gray-900">{record.orderNo}</p>
            <p className="text-xs text-gray-500">{record.createTime}</p>
          </div>
        </div>
      ),
    },
    {
      title: '客户信息',
      dataIndex: 'customerName',
      key: 'customerName',
      render: (name: string, record: IOrder) => (
        <div>
          <p className="text-gray-900">{name}</p>
          <p className="text-xs text-gray-500">{record.customerPhone}</p>
        </div>
      ),
    },
    {
      title: '金额',
      dataIndex: 'totalAmount',
      key: 'totalAmount',
      render: (amount: number, record: IOrder) => (
        <div>
          <p className="font-medium text-gray-900">¥{record.payAmount.toLocaleString()}</p>
          {record.payAmount < amount && (
            <p className="text-xs text-gray-400 line-through">¥{amount.toLocaleString()}</p>
          )}
        </div>
      ),
    },
    {
      title: '支付方式',
      dataIndex: 'payMethod',
      key: 'payMethod',
      render: (method: string) => <span className="text-gray-600">{method}</span>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const config = statusConfig[status];
        return (
          <Badge variant={config?.variant} className="font-normal">
            {config?.label}
          </Badge>
        );
      },
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right' as const,
      render: (_: unknown, record: IOrder) => (
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 px-3 text-gray-600 hover:text-gray-900"
            onClick={() => navigate(`/admin/orders/${record.id}`)}
          >
            <Eye className="w-4 h-4 mr-1.5" />
            查看
          </Button>
          {record.status === 'paid' && (
            <Button size="sm" className="h-8 px-3 bg-gray-900 hover:bg-gray-800 text-white">
              <Truck className="w-4 h-4 mr-1.5" />
              发货
            </Button>
          )}
        </div>
      ),
    },
  ];

  const statsData = [
    { label: '今日订单', value: 24, subtext: '较昨日 +12%' },
    { label: '待发货', value: 8, subtext: '需处理', highlight: true },
    { label: '待付款', value: 5, subtext: '需跟进' },
    { label: '售后中', value: 2, subtext: '需处理', highlight: true },
  ];

  return (
    <>
      <style jsx>{`
        .admin-orders {
          animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="admin-orders w-full space-y-6">
        <section className="w-full">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">订单管理</h1>
              <p className="text-sm text-gray-500 mt-1">处理客户订单，完成发货与售后</p>
            </div>
            <Button onClick={handleExport} variant="outline" className="gap-2">
              <Download className="w-4 h-4" />
              导出
            </Button>
          </div>
        </section>

        <section className="w-full">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statsData.map((stat) => (
              <Card key={stat.label} className={cn('border-0 shadow-sm', stat.highlight && 'ring-1 ring-gray-900')}> 
                <CardContent className="p-5">
                  <p className="text-sm text-gray-500">{stat.label}</p>
                  <div className="flex items-end justify-between mt-2">
                    <span className="text-3xl font-semibold text-gray-900">{stat.value}</span>
                    <span className={cn('text-xs', stat.highlight ? 'text-gray-900 font-medium' : 'text-gray-400')}>
                      {stat.subtext}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="w-full">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-5">
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 min-w-[240px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="搜索订单号、客户姓名或手机号"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="pl-10 bg-gray-50 border-0"
                  />
                </div>

                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px] bg-gray-50 border-0">
                    <SelectValue placeholder="全部状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="pending">待付款</SelectItem>
                    <SelectItem value="paid">待发货</SelectItem>
                    <SelectItem value="shipped">待收货</SelectItem>
                    <SelectItem value="completed">已完成</SelectItem>
                    <SelectItem value="cancelled">已取消</SelectItem>
                    <SelectItem value="refunding">售后中</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex items-center gap-2">
                  <Input
                    type="date"
                    value={dateFrom}
                    onChange={(e) => setDateFrom(e.target.value)}
                    className="w-[130px] bg-gray-50 border-0"
                  />
                  <span className="text-gray-400">-</span>
                  <Input
                    type="date"
                    value={dateTo}
                    onChange={(e) => setDateTo(e.target.value)}
                    className="w-[130px] bg-gray-50 border-0"
                  />
                </div>

                <Button 
                  variant="ghost" 
                  onClick={() => { setSearchKeyword(''); setStatusFilter('all'); setDateFrom(''); setDateTo(''); }}
                  className="text-gray-500"
                >
                  重置
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-gray-100">
                {[
                  { key: 'all', label: '全部' },
                  { key: 'pending', label: '待付款' },
                  { key: 'paid', label: '待发货' },
                  { key: 'shipped', label: '待收货' },
                  { key: 'refunding', label: '售后中' },
                ].map((item) => (
                  <Button
                    key={item.key}
                    variant={statusFilter === item.key ? 'default' : 'ghost'}
                    size="sm"
                    className={cn(
                      'h-8 text-sm rounded-full',
                      statusFilter === item.key ? 'bg-gray-900 text-white hover:bg-gray-800' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                    onClick={() => setStatusFilter(item.key)}
                  >
                    {item.label}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="w-full">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-0">
              <Table
                columns={columns}
                dataSource={filteredOrders}
                rowKey="id"
                scroll={{ x: 900 }}
                pagination={{
                  total: filteredOrders.length,
                  pageSize: 10,
                  showSizeChanger: false,
                  showTotal: (total) => `共 ${total} 个订单`,
                }}
              />
            </CardContent>
          </Card>
        </section>
      </div>
    </>
  );
};

export default AdminOrders;
