import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import {
  Plus,
  X,
  Upload,
  Trash2,
  ArrowLeft,
  Save,
  CalendarIcon,
  ImageIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { TiptapEditorComplete } from '@/components/business-ui/tiptap-editor';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface IAdminProductEditProps {}

interface ISkuSpec {
  id: string;
  name: string;
  values: string[];
}

interface ISkuItem {
  id: string;
  specs: Record<string, string>;
  price: number;
  originalPrice: number;
  stock: number;
  code: string;
  image?: string;
}

interface IProductParam {
  id: string;
  key: string;
  value: string;
}

const AdminProductEdit: React.FC<IAdminProductEditProps> = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id?: string }>();
  const isEdit = !!id;

  const [name, setName] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState('');
  const [brand, setBrand] = useState('');
  const [keywords, setKeywords] = useState('');
  const [isNew, setIsNew] = useState(false);
  const [isHot, setIsHot] = useState(false);
  const [isRecommend, setIsRecommend] = useState(false);

  const [basePrice, setBasePrice] = useState('');
  const [marketPrice, setMarketPrice] = useState('');
  const [stock, setStock] = useState('');
  const [stockWarning, setStockWarning] = useState('10');

  const [skuSpecs, setSkuSpecs] = useState<ISkuSpec[]>([]);
  const [skuItems, setSkuItems] = useState<ISkuItem[]>([]);
  const [newSpecName, setNewSpecName] = useState('');
  const [newSpecValue, setNewSpecValue] = useState('');

  const [images, setImages] = useState<string[]>([]);
  const [detail, setDetail] = useState('');
  const [params, setParams] = useState<IProductParam[]>([]);

  const [saleType, setSaleType] = useState<'now' | 'schedule'>('now');
  const [scheduleDate, setScheduleDate] = useState<Date>();

  const [seoTitle, setSeoTitle] = useState('');
  const [seoKeywords, setSeoKeywords] = useState('');
  const [seoDesc, setSeoDesc] = useState('');

  const categories = [
    { id: '1', name: '数码电器' },
    { id: '2', name: '服饰鞋包' },
    { id: '3', name: '家居生活' },
    { id: '4', name: '美妆护肤' },
    { id: '5', name: '食品饮料' },
  ];

  const brands = [
    { id: '1', name: 'Apple' },
    { id: '2', name: '小米' },
    { id: '3', name: '华为' },
    { id: '4', name: '索尼' },
  ];

  useEffect(() => {
    if (isEdit) {
      setName('MacBook Pro 14英寸');
      setSubtitle('M3 Pro 芯片，专业级性能');
      setCategory('1');
      setBrand('1');
      setKeywords('MacBook,笔记本,苹果');
      setBasePrice('14999');
      setMarketPrice('16999');
      setStock('500');
      setImages([
        'https://picsum.photos/seed/macbook1/400/400',
        'https://picsum.photos/seed/macbook2/400/400',
        'https://picsum.photos/seed/macbook3/400/400',
      ]);
      setSkuSpecs([
        { id: '1', name: '芯片', values: ['M3', 'M3 Pro', 'M3 Max'] },
        { id: '2', name: '内存', values: ['8GB', '16GB', '32GB'] },
      ]);
      setSkuItems([
        { id: '1', specs: { 芯片: 'M3', 内存: '8GB' }, price: 14999, originalPrice: 16999, stock: 100, code: 'MBP-M3-8G' },
        { id: '2', specs: { 芯片: 'M3', 内存: '16GB' }, price: 16999, originalPrice: 18999, stock: 80, code: 'MBP-M3-16G' },
        { id: '3', specs: { 芯片: 'M3 Pro', 内存: '16GB' }, price: 19999, originalPrice: 21999, stock: 60, code: 'MBP-PRO-16G' },
      ]);
      setParams([
        { id: '1', key: '屏幕尺寸', value: '14.2 英寸' },
        { id: '2', key: '分辨率', value: '3024 x 1964' },
        { id: '3', key: '重量', value: '1.55 kg' },
      ]);
      setDetail('<p>全新 MacBook Pro，搭载 M3 系列芯片，带来专业级性能表现。</p>');
      setIsHot(true);
      setIsRecommend(true);
    }
  }, [isEdit]);

  const generateSkuCombinations = () => {
    if (skuSpecs.length === 0) {
      setSkuItems([]);
      return;
    }

    const combinations: ISkuItem[] = [];
    const generate = (index: number, current: Record<string, string>) => {
      if (index === skuSpecs.length) {
        const existingSku = skuItems.find(sku => 
          Object.keys(current).every(key => sku.specs[key] === current[key])
        );
        combinations.push({
          id: existingSku?.id || Math.random().toString(36).substr(2, 9),
          specs: { ...current },
          price: existingSku?.price || Number(basePrice) || 0,
          originalPrice: existingSku?.originalPrice || Number(marketPrice) || 0,
          stock: existingSku?.stock || 0,
          code: existingSku?.code || `SKU${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
        });
        return;
      }
      const spec = skuSpecs[index];
      for (const value of spec.values) {
        generate(index + 1, { ...current, [spec.name]: value });
      }
    };
    generate(0, {});
    setSkuItems(combinations);
  };

  useEffect(() => {
    generateSkuCombinations();
  }, [skuSpecs]);

  const addSpec = () => {
    if (!newSpecName.trim()) {
      toast.error('请输入规格名称');
      return;
    }
    if (!newSpecValue.trim()) {
      toast.error('请输入规格值');
      return;
    }
    const values = newSpecValue.split(/[,，]/).map(v => v.trim()).filter(Boolean);
    setSkuSpecs([...skuSpecs, { id: Date.now().toString(), name: newSpecName, values }]);
    setNewSpecName('');
    setNewSpecValue('');
  };

  const removeSpec = (specId: string) => {
    setSkuSpecs(skuSpecs.filter(s => s.id !== specId));
  };

  const updateSku = (skuId: string, field: keyof ISkuItem, value: any) => {
    setSkuItems(skuItems.map(item => item.id === skuId ? { ...item, [field]: value } : item));
  };

  const removeSku = (skuId: string) => {
    setSkuItems(skuItems.filter(item => item.id !== skuId));
  };

  const addParam = () => {
    setParams([...params, { id: Date.now().toString(), key: '', value: '' }]);
  };

  const updateParam = (id: string, field: 'key' | 'value', value: string) => {
    setParams(params.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const removeParam = (id: string) => {
    setParams(params.filter(p => p.id !== id));
  };

  const handleImageUpload = () => {
    const newImage = `https://picsum.photos/seed/${Date.now()}/400/400`;
    setImages([...images, newImage]);
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    if (!name.trim()) {
      toast.error('请输入商品名称');
      return;
    }
    if (!category) {
      toast.error('请选择商品分类');
      return;
    }
    toast.success(isEdit ? '商品更新成功' : '商品创建成功');
    navigate('/admin/products');
  };

  return (
    <>
      <style jsx>{`
        .sku-row:hover {
          background-color: hsl(var(--muted));
        }
      `}</style>

      <div className="w-full space-y-8">
        <section className="w-full flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/products')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-semibold text-foreground tracking-tight">
                {isEdit ? '编辑商品' : '新增商品'}
              </h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                {isEdit ? `商品编号: ${id}` : '创建新的商品信息'}
              </p>
            </div>
          </div>
          <Button onClick={handleSave} size="lg" className="gap-2">
            <Save className="h-4 w-4" />
            保存
          </Button>
        </section>

        <section className="w-full">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="w-full justify-start bg-transparent border-b rounded-none h-auto p-0 gap-6">
              <TabsTrigger value="basic" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">基本信息</TabsTrigger>
              <TabsTrigger value="images" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">商品图片</TabsTrigger>
              <TabsTrigger value="sku" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">SKU管理</TabsTrigger>
              <TabsTrigger value="detail" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">图文详情</TabsTrigger>
              <TabsTrigger value="params" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">商品参数</TabsTrigger>
              <TabsTrigger value="seo" className="rounded-none border-b-2 border-transparent data-[state=active]:border-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none pb-3">SEO设置</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-6 pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">基本信息</CardTitle>
                  <CardDescription className="text-muted-foreground">填写商品的基本信息</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="name" className="text-sm font-medium">
                        商品名称 <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="name"
                        placeholder="请输入商品名称"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="subtitle" className="text-sm font-medium">商品副标题</Label>
                      <Input
                        id="subtitle"
                        placeholder="简要描述商品特点"
                        value={subtitle}
                        onChange={(e) => setSubtitle(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category" className="text-sm font-medium">
                        所属分类 <span className="text-destructive">*</span>
                      </Label>
                      <Select value={category} onValueChange={setCategory}>
                        <SelectTrigger className="h-11 bg-white">
                          <SelectValue placeholder="选择分类" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((cat) => (
                            <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="brand" className="text-sm font-medium">商品品牌</Label>
                      <Select value={brand} onValueChange={setBrand}>
                        <SelectTrigger className="h-11 bg-white">
                          <SelectValue placeholder="选择品牌" />
                        </SelectTrigger>
                        <SelectContent>
                          {brands.map((b) => (
                            <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="keywords" className="text-sm font-medium">搜索关键词</Label>
                      <Input
                        id="keywords"
                        placeholder="多个关键词用逗号分隔"
                        value={keywords}
                        onChange={(e) => setKeywords(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h4 className="text-sm font-medium mb-4">商品标签</h4>
                    <div className="flex flex-wrap gap-6">
                      <div className="flex items-center gap-3">
                        <Switch id="isNew" checked={isNew} onCheckedChange={setIsNew} />
                        <Label htmlFor="isNew" className="text-sm">新品</Label>
                      </div>
                      <div className="flex items-center gap-3">
                        <Switch id="isHot" checked={isHot} onCheckedChange={setIsHot} />
                        <Label htmlFor="isHot" className="text-sm">热卖</Label>
                      </div>
                      <div className="flex items-center gap-3">
                        <Switch id="isRecommend" checked={isRecommend} onCheckedChange={setIsRecommend} />
                        <Label htmlFor="isRecommend" className="text-sm">推荐</Label>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">价格与库存</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="basePrice" className="text-sm font-medium">
                        销售价 <span className="text-destructive">*</span>
                      </Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">¥</span>
                        <Input
                          id="basePrice"
                          type="number"
                          className="pl-7 h-11 bg-white"
                          placeholder="0.00"
                          value={basePrice}
                          onChange={(e) => setBasePrice(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="marketPrice" className="text-sm font-medium">市场价</Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">¥</span>
                        <Input
                          id="marketPrice"
                          type="number"
                          className="pl-7 h-11 bg-white"
                          placeholder="0.00"
                          value={marketPrice}
                          onChange={(e) => setMarketPrice(e.target.value)}
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stock" className="text-sm font-medium">
                        库存总量 <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="stock"
                        type="number"
                        placeholder="0"
                        value={stock}
                        onChange={(e) => setStock(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="stockWarning" className="text-sm font-medium">库存预警</Label>
                      <Input
                        id="stockWarning"
                        type="number"
                        placeholder="10"
                        value={stockWarning}
                        onChange={(e) => setStockWarning(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">上架设置</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex gap-4">
                    <div
                      className={cn(
                        'flex-1 p-5 rounded-xl border-2 cursor-pointer transition-all',
                        saleType === 'now' ? 'border-foreground bg-white' : 'border-transparent bg-white hover:border-gray-200'
                      )}
                      onClick={() => setSaleType('now')}
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn('w-5 h-5 rounded-full border-2 flex items-center justify-center', saleType === 'now' ? 'border-foreground' : 'border-gray-300')}>
                          {saleType === 'now' && <div className="w-2.5 h-2.5 rounded-full bg-foreground" />}
                        </div>
                        <span className="font-medium">立即上架</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-2 ml-8">保存后立即上架销售</p>
                    </div>
                    <div
                      className={cn(
                        'flex-1 p-5 rounded-xl border-2 cursor-pointer transition-all',
                        saleType === 'schedule' ? 'border-foreground bg-white' : 'border-transparent bg-white hover:border-gray-200'
                      )}
                      onClick={() => setSaleType('schedule')}
                    >
                      <div className="flex items-center gap-3">
                        <div className={cn('w-5 h-5 rounded-full border-2 flex items-center justify-center', saleType === 'schedule' ? 'border-foreground' : 'border-gray-300')}>
                          {saleType === 'schedule' && <div className="w-2.5 h-2.5 rounded-full bg-foreground" />}
                        </div>
                        <span className="font-medium">定时上架</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-2 ml-8">设置指定时间自动上架</p>
                    </div>
                  </div>

                  {saleType === 'schedule' && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">上架时间</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              'w-full justify-start text-left font-normal h-11 bg-white',
                              !scheduleDate && 'text-muted-foreground'
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {scheduleDate ? format(scheduleDate, 'yyyy-MM-dd HH:mm', { locale: zhCN }) : '选择上架时间'}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <Calendar
                            mode="single"
                            selected={scheduleDate}
                            onSelect={setScheduleDate}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="images" className="pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">商品图片</CardTitle>
                  <CardDescription className="text-muted-foreground">上传商品主图，最多10张，第一张为主图</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-6 gap-4">
                    {images.map((img, index) => (
                      <div key={index} className="relative aspect-square rounded-xl overflow-hidden border bg-white group">
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        <button
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 w-8 h-8 bg-white/90 hover:bg-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                        >
                          <X className="h-4 w-4" />
                        </button>
                        {index === 0 && (
                          <Badge className="absolute top-2 left-2 bg-foreground text-white border-0">主图</Badge>
                        )}
                      </div>
                    ))}
                    {images.length < 10 && (
                      <button
                        onClick={handleImageUpload}
                        className="aspect-square rounded-xl border-2 border-dashed border-gray-300 hover:border-foreground transition-colors flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-foreground bg-white"
                      >
                        <Upload className="h-6 w-6" />
                        <span className="text-sm">上传</span>
                      </button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sku" className="space-y-6 pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">规格设置</CardTitle>
                  <CardDescription className="text-muted-foreground">设置商品规格，系统将自动生成SKU组合</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex gap-4 items-end">
                    <div className="flex-1 space-y-2">
                      <Label className="text-sm font-medium">规格名称</Label>
                      <Input
                        placeholder="如：颜色、尺码"
                        value={newSpecName}
                        onChange={(e) => setNewSpecName(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                    <div className="flex-[2] space-y-2">
                      <Label className="text-sm font-medium">规格值（多个用逗号分隔）</Label>
                      <Input
                        placeholder="如：红色,蓝色,黑色"
                        value={newSpecValue}
                        onChange={(e) => setNewSpecValue(e.target.value)}
                        className="h-11 bg-white"
                      />
                    </div>
                    <Button onClick={addSpec} className="h-11 gap-2">
                      <Plus className="h-4 w-4" />
                      添加
                    </Button>
                  </div>

                  {skuSpecs.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-sm font-medium">已添加规格</h4>
                      <div className="space-y-3">
                        {skuSpecs.map((spec) => (
                          <div key={spec.id} className="flex items-center gap-4 p-4 bg-white rounded-xl border">
                            <div className="flex-1">
                              <span className="font-medium text-sm">{spec.name}</span>
                              <div className="flex gap-2 mt-2">
                                {spec.values.map((value, idx) => (
                                  <Badge key={idx} variant="secondary" className="bg-gray-100 text-gray-700 hover:bg-gray-100">{value}</Badge>
                                ))}
                              </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => removeSpec(spec.id)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {skuItems.length > 0 && (
                <Card className="border-0 shadow-none bg-gray-50/50">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-semibold">SKU列表</CardTitle>
                    <CardDescription className="text-muted-foreground">共 {skuItems.length} 个SKU</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="border rounded-xl overflow-hidden bg-white">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50 border-b">
                          <tr>
                            {skuSpecs.map(spec => (
                              <th key={spec.id} className="px-4 py-3 text-left font-medium text-muted-foreground">{spec.name}</th>
                            ))}
                            <th className="px-4 py-3 text-left font-medium text-muted-foreground">SKU编码</th>
                            <th className="px-4 py-3 text-left font-medium text-muted-foreground">销售价</th>
                            <th className="px-4 py-3 text-left font-medium text-muted-foreground">原价</th>
                            <th className="px-4 py-3 text-left font-medium text-muted-foreground">库存</th>
                            <th className="px-4 py-3 text-left font-medium text-muted-foreground">操作</th>
                          </tr>
                        </thead>
                        <tbody>
                          {skuItems.map((sku) => (
                            <tr key={sku.id} className="sku-row border-t">
                              {skuSpecs.map(spec => (
                                <td key={spec.id} className="px-4 py-3">{sku.specs[spec.name]}</td>
                              ))}
                              <td className="px-4 py-3">
                                <Input className="h-9 w-28" value={sku.code} onChange={(e) => updateSku(sku.id, 'code', e.target.value)} />
                              </td>
                              <td className="px-4 py-3">
                                <Input type="number" className="h-9 w-24" value={sku.price} onChange={(e) => updateSku(sku.id, 'price', Number(e.target.value))} />
                              </td>
                              <td className="px-4 py-3">
                                <Input type="number" className="h-9 w-24" value={sku.originalPrice} onChange={(e) => updateSku(sku.id, 'originalPrice', Number(e.target.value))} />
                              </td>
                              <td className="px-4 py-3">
                                <Input type="number" className="h-9 w-20" value={sku.stock} onChange={(e) => updateSku(sku.id, 'stock', Number(e.target.value))} />
                              </td>
                              <td className="px-4 py-3">
                                <Button variant="ghost" size="icon" onClick={() => removeSku(sku.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="detail" className="pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">图文详情</CardTitle>
                  <CardDescription className="text-muted-foreground">编辑商品的详细图文介绍</CardDescription>
                </CardHeader>
                <CardContent>
                  <TiptapEditorComplete
                    value={detail}
                    onValueChange={setDetail}
                    placeholder="请输入商品详情描述..."
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="params" className="pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="flex flex-row items-center justify-between pb-4">
                  <div>
                    <CardTitle className="text-lg font-semibold">商品参数</CardTitle>
                    <CardDescription className="text-muted-foreground">添加商品的技术参数和规格信息</CardDescription>
                  </div>
                  <Button onClick={addParam} className="gap-2">
                    <Plus className="h-4 w-4" />
                    添加参数
                  </Button>
                </CardHeader>
                <CardContent className="space-y-4">
                  {params.map((param) => (
                    <div key={param.id} className="flex gap-4 items-start">
                      <div className="flex-1 space-y-2">
                        <Label className="text-sm font-medium">参数名称</Label>
                        <Input
                          placeholder="如：材质、重量"
                          value={param.key}
                          onChange={(e) => updateParam(param.id, 'key', e.target.value)}
                          className="h-11 bg-white"
                        />
                      </div>
                      <div className="flex-[2] space-y-2">
                        <Label className="text-sm font-medium">参数值</Label>
                        <Input
                          placeholder="如：纯棉、500g"
                          value={param.value}
                          onChange={(e) => updateParam(param.id, 'value', e.target.value)}
                          className="h-11 bg-white"
                        />
                      </div>
                      <Button variant="ghost" size="icon" className="mt-8" onClick={() => removeParam(param.id)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {params.length === 0 && (
                    <div className="text-center py-12 text-muted-foreground bg-white rounded-xl border border-dashed">
                      暂无参数，点击右上角按钮添加
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="seo" className="pt-6">
              <Card className="border-0 shadow-none bg-gray-50/50">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold">SEO设置</CardTitle>
                  <CardDescription className="text-muted-foreground">设置搜索引擎优化信息</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="seoTitle" className="text-sm font-medium">页面标题</Label>
                    <Input
                      id="seoTitle"
                      placeholder="建议不超过60个字符"
                      value={seoTitle}
                      onChange={(e) => setSeoTitle(e.target.value)}
                      className="h-11 bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seoKeywords" className="text-sm font-medium">关键词</Label>
                    <Input
                      id="seoKeywords"
                      placeholder="多个关键词用逗号分隔"
                      value={seoKeywords}
                      onChange={(e) => setSeoKeywords(e.target.value)}
                      className="h-11 bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="seoDesc" className="text-sm font-medium">描述</Label>
                    <Input
                      id="seoDesc"
                      placeholder="建议不超过200个字符"
                      value={seoDesc}
                      onChange={(e) => setSeoDesc(e.target.value)}
                      className="h-11 bg-white"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </div>
    </>
  );
};

export default AdminProductEdit;
