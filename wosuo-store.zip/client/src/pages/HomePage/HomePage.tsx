import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ChevronRight, ArrowRight } from 'lucide-react';
import { useLanguage } from '@/lib/i18n';

// 精选产品
const featuredProducts = [
  { 
    id: 1, 
    name: 'MacBook Pro', 
    subtitle: 'M3 芯片，专业性能',
    price: 14999, 
    image: 'https://picsum.photos/seed/macbook/800/600',
    category: '笔记本'
  },
  { 
    id: 2, 
    name: 'iPhone 15 Pro', 
    subtitle: '钛金属设计',
    price: 7999, 
    image: 'https://picsum.photos/seed/iphone/800/600',
    category: '手机'
  },
  { 
    id: 3, 
    name: 'AirPods Pro', 
    subtitle: '主动降噪，空间音频',
    price: 1899, 
    image: 'https://picsum.photos/seed/airpods/800/600',
    category: '音频'
  },
  { 
    id: 4, 
    name: 'iPad Air', 
    subtitle: '轻薄设计，强劲性能',
    price: 4799, 
    image: 'https://picsum.photos/seed/ipad/800/600',
    category: '平板'
  },
];

// 更多产品
const moreProducts = [
  { id: 5, name: 'Watch Ultra', price: 6299, image: 'https://picsum.photos/seed/watch/400/400' },
  { id: 6, name: 'Studio Display', price: 11499, image: 'https://picsum.photos/seed/display/400/400' },
  { id: 7, name: 'Magic Keyboard', price: 2399, image: 'https://picsum.photos/seed/keyboard/400/400' },
  { id: 8, name: 'Magic Mouse', price: 699, image: 'https://picsum.photos/seed/mouse/400/400' },
];

interface IHomePageProps {}

const HomePage: React.FC<IHomePageProps> = () => {
  const { t } = useLanguage();
  
  return (
    <>
      <style jsx>{`
        .hero-title {
          letter-spacing: -0.02em;
        }
        .product-card:hover .product-image {
          transform: scale(1.02);
        }
        .product-image {
          transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>

      <div className="w-full">
        {/* Hero Section */}
        <section className="w-full bg-gray-50">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-24 md:py-32 lg:py-40">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="hero-title text-4xl md:text-5xl lg:text-6xl font-semibold text-gray-900 leading-tight mb-6">
                全新 MacBook Pro
              </h1>
              <p className="text-xl md:text-2xl text-gray-500 mb-10 font-normal">
                M3 芯片加持，专业性能，从容应对每一项挑战。
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button 
                  size="lg" 
                  className="h-12 px-8 text-base bg-gray-900 hover:bg-gray-800 text-white rounded-full"
                >
                  {t('buyNow')}
                </Button>
                <Link 
                  to="/product/1" 
                  className="inline-flex items-center gap-2 text-base text-gray-900 hover:text-gray-600 transition-colors"
                >
                  {t('learnMore')} <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
            <div className="mt-16 md:mt-20">
              <img 
                src="https://picsum.photos/seed/hero-macbook/1200/600" 
                alt="MacBook Pro"
                className="w-full max-w-5xl mx-auto rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="w-full py-20 md:py-28">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">
                  {t('featuredProducts')}
                </h2>
                <p className="text-gray-500 mt-2 text-lg">{t('discoverCollection')}</p>
              </div>
              <Link 
                to="/category" 
                className="hidden md:inline-flex items-center gap-2 text-gray-900 hover:text-gray-600 transition-colors"
              >
                {t('viewAll')} <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
              {featuredProducts.map((product) => (
                <Link 
                  key={product.id} 
                  to={`/product/${product.id}`}
                  className="product-card group block bg-gray-50 rounded-2xl overflow-hidden"
                >
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="product-image w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6 md:p-8">
                    <p className="text-sm text-gray-500 mb-2">{product.category}</p>
                    <h3 className="text-xl md:text-2xl font-semibold text-gray-900 mb-1">
                      {product.name}
                    </h3>
                    <p className="text-gray-500 mb-4">{product.subtitle}</p>
                    <p className="text-lg font-medium text-gray-900">
                      ¥{product.price.toLocaleString()}
                    </p>
                  </div>
                </Link>
              ))}
            </div>

            <div className="mt-8 text-center md:hidden">
              <Link 
                to="/category" 
                className="inline-flex items-center gap-2 text-gray-900"
              >
                {t('viewAll')} <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* More Products Grid */}
        <section className="w-full bg-gray-50 py-20 md:py-28">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <h2 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight mb-12">
              配件与更多
            </h2>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              {moreProducts.map((product) => (
                <Link 
                  key={product.id} 
                  to={`/product/${product.id}`}
                  className="product-card group block bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                >
                  <div className="aspect-square overflow-hidden p-6">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="product-image w-full h-full object-cover rounded-xl"
                    />
                  </div>
                  <div className="px-6 pb-6">
                    <h3 className="text-base font-medium text-gray-900 mb-1">
                      {product.name}
                    </h3>
                    <p className="text-gray-500">
                      ¥{product.price.toLocaleString()}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-20 md:py-28">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="bg-gray-900 rounded-3xl py-16 md:py-24 px-6 md:px-12 text-center">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-semibold text-white tracking-tight mb-6">
                为企业而生
              </h2>
              <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
                为团队提供专属解决方案，享受专属折扣与技术支持。
              </p>
              <Button 
                size="lg" 
                variant="outline"
                className="h-12 px-8 text-base bg-transparent border-white text-white hover:bg-white hover:text-gray-900 rounded-full"
              >
                联系企业销售
              </Button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default HomePage;
