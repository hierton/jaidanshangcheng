import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import {
  ArrowLeft,
  Truck,
  Package,
  User,
  Phone,
  MapPin,
  CreditCard,
  Tag,
  Clock,
  CheckCircle2,
  XCircle,
  Printer,
  RotateCcw,
  FileEdit,
  Ban,
} from 'lucide-react';

// 订单状态映射
const orderStatusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'outline' | 'destructive' }> = {
  pending: { label: '待付款', variant: 'secondary' },
  paid: { label: '已付款', variant: 'default' },
  shipped: { label: '已发货', variant: 'outline' },
  completed: { label: '已完成', variant: 'default' },
  cancelled: { label: '已取消', variant: 'destructive' },
  refunding: { label: '退款中', variant: 'destructive' },
};

// 快递公司
const expressCompanies = [
  { code: 'sf', name: '顺丰速运' },
  { code: 'jd', name: '京东物流' },
  { code: 'yt', name: '圆通速递' },
  { code: 'zt', name: '中通快递' },
  { code: 'ems', name: 'EMS' },
];

// Mock 数据
const mockOrderDetail = {
  id: 'ORD202603140001',
  status: 'paid',
  createdAt: '2026-03-14 10:30:25',
  paidAt: '2026-03-14 10:32:18',
  shippedAt: null,
  completedAt: null,
  user: {
    id: 'U001',
    nickname: '张三',
    phone: '138****8888',
    avatar: 'https://picsum.photos/seed/user1/100/100',
  },
  address: {
    name: '张三',
    phone: '138****8888',
    province: '北京市',
    city: '北京市',
    district: '朝阳区',
    detail: '建国路88号SOHO现代城A座1201室',
  },
  items: [
    {
      id: 1,
      name: 'MacBook Pro 14英寸',
      image: 'https://picsum.photos/seed/macbook/100/100',
      specs: { color: '深空灰', chip: 'M3 Pro' },
      price: 16999,
      quantity: 1,
      total: 16999,
    },
    {
      id: 2,
      name: 'Magic Mouse',
      image: 'https://picsum.photos/seed/mouse/100/100',
      specs: { color: '白色' },
      price: 699,
      quantity: 1,
      total: 699,
    },
  ],
  payment: {
    method: '微信支付',
    amount: 17698,
    discount: 500,
    shipping: 0,
    total: 17198,
  },
  discountCode: {
    code: 'STORE2026',
    name: '新品优惠500元',
    discount: 500,
  },
  remark: '请尽快发货，急用',
  internalNote: '',
  logistics: null,
  refund: null,
  operationLogs: [
    { time: '2026-03-14 10:32:18', action: '订单支付成功', operator: '系统' },
    { time: '2026-03-14 10:30:25', action: '订单创建', operator: '用户' },
  ],
};

interface IAdminOrderDetailProps {}

const AdminOrderDetail: React.FC<IAdminOrderDetailProps> = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState(mockOrderDetail);
  const [loading, setLoading] = useState(false);

  // 弹窗状态
  const [shipDialogOpen, setShipDialogOpen] = useState(false);
  const [shipForm, setShipForm] = useState({ company: '', trackingNo: '' });
  
  const [refundDialogOpen, setRefundDialogOpen] = useState(false);
  const [refundAction, setRefundAction] = useState<'approve' | 'reject' | null>(null);
  const [refundReason, setRefundReason] = useState('');
  
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [internalNote, setInternalNote] = useState(order.internalNote);
  
  const [priceDialogOpen, setPriceDialogOpen] = useState(false);
  const [newPrice, setNewPrice] = useState(order.payment.total.toString());
  const [priceReason, setPriceReason] = useState('');

  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);

  // 处理发货
  const handleShip = () => {
    if (!shipForm.company || !shipForm.trackingNo) return;
    setLoading(true);
    setTimeout(() => {
      setOrder({
        ...order,
        status: 'shipped',
        shippedAt: new Date().toISOString(),
        logistics: { company: shipForm.company, trackingNo: shipForm.trackingNo },
        operationLogs: [
          { time: new Date().toLocaleString(), action: `发货：${shipForm.trackingNo}`, operator: '管理员' },
          ...order.operationLogs,
        ],
      });
      setShipDialogOpen(false);
      setLoading(false);
    }, 500);
  };

  // 处理退款
  const handleRefund = () => {
    if (!refundAction) return;
    setLoading(true);
    setTimeout(() => {
      const actionText = refundAction === 'approve' ? '同意退款' : '拒绝退款';
      setOrder({
        ...order,
        status: refundAction === 'approve' ? 'cancelled' : order.status,
        refund: {
          status: refundAction,
          reason: refundReason,
          handledAt: new Date().toISOString(),
        },
        operationLogs: [
          { time: new Date().toLocaleString(), action: `${actionText}${refundReason ? `：${refundReason}` : ''}`, operator: '管理员' },
          ...order.operationLogs,
        ],
      });
      setRefundDialogOpen(false);
      setLoading(false);
    }, 500);
  };

  // 保存备注
  const handleSaveNote = () => {
    setOrder({
      ...order,
      internalNote,
      operationLogs: [
        { time: new Date().toLocaleString(), action: '更新内部备注', operator: '管理员' },
        ...order.operationLogs,
      ],
    });
    setNoteDialogOpen(false);
  };

  // 修改价格
  const handleUpdatePrice = () => {
    const price = parseFloat(newPrice);
    if (isNaN(price) || price <= 0) return;
    setLoading(true);
    setTimeout(() => {
      setOrder({
        ...order,
        payment: { ...order.payment, total: price },
        operationLogs: [
          { time: new Date().toLocaleString(), action: `修改价格：¥${price}${priceReason ? `，原因：${priceReason}` : ''}`, operator: '管理员' },
          ...order.operationLogs,
        ],
      });
      setPriceDialogOpen(false);
      setLoading(false);
    }, 500);
  };

  // 取消订单
  const handleCancel = () => {
    setCancelDialogOpen(true);
  };

  const confirmCancel = () => {
    setOrder({
      ...order,
      status: 'cancelled',
      operationLogs: [
        { time: new Date().toLocaleString(), action: '取消订单', operator: '管理员' },
        ...order.operationLogs,
      ],
    });
    setCancelDialogOpen(false);
  };

  const itemColumns = [
    {
      title: '商品',
      dataIndex: 'name',
      key: 'name',
      render: (_: string, record: typeof order.items[0]) => (
        <div className="flex items-center gap-4">
          <img src={record.image} alt={record.name} className="w-14 h-14 rounded-lg object-cover bg-gray-100" />
          <div>
            <p className="font-medium text-gray-900">{record.name}</p>
            <p className="text-sm text-gray-500">
              {Object.entries(record.specs).map(([k, v]) => v).join(' · ')}
            </p>
          </div>
        </div>
      ),
    },
    { title: '单价', dataIndex: 'price', key: 'price', width: 120, render: (price: number) => `¥${price.toLocaleString()}` },
    { title: '数量', dataIndex: 'quantity', key: 'quantity', width: 80 },
    { title: '小计', dataIndex: 'total', key: 'total', width: 120, render: (total: number) => `¥${total.toLocaleString()}` },
  ];

  const logColumns = [
    { title: '时间', dataIndex: 'time', key: 'time', width: 180 },
    { title: '操作', dataIndex: 'action', key: 'action' },
    { title: '操作人', dataIndex: 'operator', key: 'operator', width: 120 },
  ];

  const status = orderStatusMap[order.status];

  return (
    <>
      <style jsx>{`
        .order-detail {
          animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="w-full space-y-6 order-detail">
        {/* 头部 */}
        <section className="w-full flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => navigate('/admin/orders')}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">订单详情</h1>
              <p className="text-sm text-gray-500">{id}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="h-9">
              <Printer className="w-4 h-4 mr-2" />
              打印
            </Button>
            {order.status === 'paid' && (
              <Button size="sm" className="h-9" onClick={() => setShipDialogOpen(true)}>
                <Truck className="w-4 h-4 mr-2" />
                发货
              </Button>
            )}
            {order.status === 'pending' && (
              <>
                <Button variant="outline" size="sm" className="h-9" onClick={() => setPriceDialogOpen(true)}>
                  改价
                </Button>
                <Button variant="destructive" size="sm" className="h-9" onClick={handleCancel}>
                  <Ban className="w-4 h-4 mr-2" />
                  取消
                </Button>
              </>
            )}
          </div>
        </section>

        {/* 状态 */}
        <section className="w-full">
          <Card className="border-gray-200">
            <CardContent className="p-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <Badge variant={status.variant} className="px-3 py-1 text-sm font-medium">
                    {status.label}
                  </Badge>
                  <span className="text-sm text-gray-500">创建于 {order.createdAt}</span>
                </div>
                <div className="flex items-center gap-8 text-sm">
                  <div className={`flex items-center gap-2 ${order.paidAt ? 'text-gray-900' : 'text-gray-400'}`}>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>付款</span>
                  </div>
                  <div className={`flex items-center gap-2 ${order.shippedAt ? 'text-gray-900' : 'text-gray-400'}`}>
                    <Truck className="w-4 h-4" />
                    <span>发货</span>
                  </div>
                  <div className={`flex items-center gap-2 ${order.completedAt ? 'text-gray-900' : 'text-gray-400'}`}>
                    <Package className="w-4 h-4" />
                    <span>完成</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* 信息卡片 */}
        <section className="w-full grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 收货信息 */}
          <Card className="border-gray-200">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                收货信息
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <p className="font-medium text-gray-900">{order.address.name}</p>
              <p className="text-sm text-gray-500">{order.address.phone}</p>
              <p className="text-sm text-gray-500 leading-relaxed">
                {order.address.province} {order.address.city} {order.address.district}
                <br />
                {order.address.detail}
              </p>
            </CardContent>
          </Card>

          {/* 支付信息 */}
          <Card className="border-gray-200">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                支付信息
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">支付方式</span>
                <span className="text-gray-900">{order.payment.method}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">商品金额</span>
                <span className="text-gray-900">¥{order.payment.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">运费</span>
                <span className="text-gray-900">¥{order.payment.shipping}</span>
              </div>
              {order.discountCode && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">优惠</span>
                  <span className="text-red-600">-¥{order.payment.discount.toLocaleString()}</span>
                </div>
              )}
              <Separator className="my-3" />
              <div className="flex justify-between">
                <span className="font-medium text-gray-900">实付金额</span>
                <span className="text-lg font-semibold text-gray-900">¥{order.payment.total.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          {/* 用户信息 */}
          <Card className="border-gray-200">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                <User className="w-4 h-4" />
                客户信息
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 pt-0">
              <div className="flex items-center gap-3">
                <img src={order.user.avatar} alt="" className="w-10 h-10 rounded-full bg-gray-100" />
                <div>
                  <p className="font-medium text-gray-900">{order.user.nickname}</p>
                  <p className="text-xs text-gray-500">{order.user.phone}</p>
                </div>
              </div>
              <Separator />
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-4">
                  <span className="text-sm text-gray-500 shrink-0">用户备注</span>
                  <span className="text-sm text-gray-900 text-right">{order.remark || '无'}</span>
                </div>
                <div className="flex items-start justify-between gap-4">
                  <span className="text-sm text-gray-500 shrink-0">内部备注</span>
                  <span className="text-sm text-gray-900 text-right">{order.internalNote || '无'}</span>
                </div>
                <Button variant="link" size="sm" className="h-auto p-0 text-sm" onClick={() => setNoteDialogOpen(true)}>
                  <FileEdit className="w-3 h-3 mr-1" />
                  编辑备注
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* 商品列表 */}
        <section className="w-full">
          <Card className="border-gray-200">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                <Package className="w-4 h-4" />
                商品明细
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Table columns={itemColumns} dataSource={order.items} pagination={false} rowKey="id" />
            </CardContent>
          </Card>
        </section>

        {/* 物流信息 */}
        {order.logistics && (
          <section className="w-full">
            <Card className="border-gray-200">
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                  <Truck className="w-4 h-4" />
                  物流信息
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap items-center gap-6">
                  <div>
                    <span className="text-sm text-gray-500">快递公司：</span>
                    <span className="text-gray-900 font-medium ml-1">
                      {expressCompanies.find(c => c.code === order.logistics?.company)?.name || order.logistics?.company}
                    </span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-500">运单号：</span>
                    <span className="text-gray-900 font-medium ml-1">{order.logistics?.trackingNo}</span>
                  </div>
                  <Button variant="outline" size="sm">查看物流</Button>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* 优惠码 */}
        {order.discountCode && (
          <section className="w-full">
            <Card className="border-gray-200">
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                  <Tag className="w-4 h-4" />
                  优惠码
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center gap-6">
                  <span className="text-gray-900 font-medium">{order.discountCode.code}</span>
                  <span className="text-sm text-gray-500">{order.discountCode.name}</span>
                  <span className="text-red-600 font-medium">-¥{order.discountCode.discount.toLocaleString()}</span>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* 售后 */}
        {order.refund && (
          <section className="w-full">
            <Card className="border-red-200 bg-red-50/30">
              <CardHeader className="pb-4">
                <CardTitle className="text-sm font-medium text-red-600 flex items-center gap-2">
                  <RotateCcw className="w-4 h-4" />
                  售后处理
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex items-center gap-4">
                  <Badge variant={order.refund.status === 'approve' ? 'default' : 'destructive'}>
                    {order.refund.status === 'approve' ? '已同意退款' : '已拒绝退款'}
                  </Badge>
                  <span className="text-sm text-gray-500">处理时间：{order.refund.handledAt}</span>
                </div>
                {order.refund.reason && (
                  <p className="text-sm text-gray-600 mt-3">{order.refund.reason}</p>
                )}
              </CardContent>
            </Card>
          </section>
        )}

        {/* 操作日志 */}
        <section className="w-full">
          <Card className="border-gray-200">
            <CardHeader className="pb-4">
              <CardTitle className="text-sm font-medium text-gray-500 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                操作日志
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Table columns={logColumns} dataSource={order.operationLogs} pagination={false} rowKey={(record: typeof order.operationLogs[0]) => `${record.time}-${record.action}`} />
            </CardContent>
          </Card>
        </section>

        {/* 发货弹窗 */}
        <Dialog open={shipDialogOpen} onOpenChange={setShipDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">订单发货</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-gray-700">快递公司</Label>
                <Select value={shipForm.company} onValueChange={(v) => setShipForm({ ...shipForm, company: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择快递公司" />
                  </SelectTrigger>
                  <SelectContent>
                    {expressCompanies.map((c) => (
                      <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700">运单号</Label>
                <Input placeholder="请输入运单号" value={shipForm.trackingNo} onChange={(e) => setShipForm({ ...shipForm, trackingNo: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShipDialogOpen(false)}>取消</Button>
              <Button onClick={handleShip} disabled={!shipForm.company || !shipForm.trackingNo || loading}>确认发货</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 备注弹窗 */}
        <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">编辑内部备注</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <Textarea placeholder="输入内部备注（仅后台可见）" value={internalNote} onChange={(e) => setInternalNote(e.target.value)} rows={4} />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setNoteDialogOpen(false)}>取消</Button>
              <Button onClick={handleSaveNote}>保存</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 改价弹窗 */}
        <Dialog open={priceDialogOpen} onOpenChange={setPriceDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">修改订单价格</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label className="text-gray-700">新价格</Label>
                <Input type="number" placeholder="请输入新价格" value={newPrice} onChange={(e) => setNewPrice(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700">修改原因</Label>
                <Textarea placeholder="请输入修改原因" value={priceReason} onChange={(e) => setPriceReason(e.target.value)} rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPriceDialogOpen(false)}>取消</Button>
              <Button onClick={handleUpdatePrice} disabled={loading}>确认修改</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 退款弹窗 */}
        <Dialog open={refundDialogOpen} onOpenChange={setRefundDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">处理退款申请</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="flex gap-4">
                <Button variant={refundAction === 'approve' ? 'default' : 'outline'} className="flex-1" onClick={() => setRefundAction('approve')}>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  同意退款
                </Button>
                <Button variant={refundAction === 'reject' ? 'destructive' : 'outline'} className="flex-1" onClick={() => setRefundAction('reject')}>
                  <XCircle className="w-4 h-4 mr-2" />
                  拒绝退款
                </Button>
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700">处理说明</Label>
                <Textarea placeholder="请输入处理说明" value={refundReason} onChange={(e) => setRefundReason(e.target.value)} rows={3} />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setRefundDialogOpen(false)}>取消</Button>
              <Button onClick={handleRefund} disabled={!refundAction || loading}>确认处理</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 取消订单确认对话框 */}
        <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>确认取消订单</DialogTitle>
            </DialogHeader>
            <p className="text-gray-600 py-4">确定要取消此订单吗？此操作不可撤销。</p>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCancelDialogOpen(false)}>取消</Button>
              <Button variant="destructive" onClick={confirmCancel}>确认取消</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default AdminOrderDetail;
