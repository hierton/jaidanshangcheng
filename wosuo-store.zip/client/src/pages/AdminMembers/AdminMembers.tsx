import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import {
  Search,
  Users,
  ShoppingBag,
  DollarSign,
  Calendar,
  Phone,
  MapPin,
  Ban,
  CheckCircle,
  Eye,
  UserX,
  UserCheck,
} from 'lucide-react';

// 会员数据类型
interface IMember {
  id: string;
  nickname: string;
  phone: string;
  avatar?: string;
  registerTime: string;
  lastLogin: string;
  orderCount: number;
  totalSpent: number;
  isBlacklisted: boolean;
  status: 'active' | 'inactive' | 'blacklisted';
}

// 收货地址类型
interface IAddress {
  id: string;
  name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  isDefault: boolean;
}

// Mock 会员数据
const mockMembers: IMember[] = [
  {
    id: '1',
    nickname: '张三',
    phone: '13800138001',
    avatar: 'https://picsum.photos/seed/user1/100/100',
    registerTime: '2026-01-15',
    lastLogin: '2026-03-14',
    orderCount: 12,
    totalSpent: 3580,
    isBlacklisted: false,
    status: 'active',
  },
  {
    id: '2',
    nickname: '李四',
    phone: '13800138002',
    avatar: 'https://picsum.photos/seed/user2/100/100',
    registerTime: '2026-02-01',
    lastLogin: '2026-03-13',
    orderCount: 5,
    totalSpent: 1299,
    isBlacklisted: false,
    status: 'active',
  },
  {
    id: '3',
    nickname: '王五',
    phone: '13800138003',
    avatar: 'https://picsum.photos/seed/user3/100/100',
    registerTime: '2026-02-10',
    lastLogin: '2026-03-10',
    orderCount: 0,
    totalSpent: 0,
    isBlacklisted: false,
    status: 'inactive',
  },
  {
    id: '4',
    nickname: '赵六',
    phone: '13800138004',
    avatar: 'https://picsum.photos/seed/user4/100/100',
    registerTime: '2026-01-20',
    lastLogin: '2026-02-28',
    orderCount: 3,
    totalSpent: 899,
    isBlacklisted: true,
    status: 'blacklisted',
  },
  {
    id: '5',
    nickname: '钱七',
    phone: '13800138005',
    avatar: 'https://picsum.photos/seed/user5/100/100',
    registerTime: '2026-03-01',
    lastLogin: '2026-03-14',
    orderCount: 8,
    totalSpent: 2456,
    isBlacklisted: false,
    status: 'active',
  },
];

// Mock 收货地址
const mockAddresses: IAddress[] = [
  {
    id: '1',
    name: '张三',
    phone: '13800138001',
    province: '北京市',
    city: '北京市',
    district: '朝阳区',
    detail: '建国路88号SOHO现代城A座1201',
    isDefault: true,
  },
  {
    id: '2',
    name: '张三',
    phone: '13800138001',
    province: '上海市',
    city: '上海市',
    district: '浦东新区',
    detail: '陆家嘴环路1000号',
    isDefault: false,
  },
];

// Mock 订单记录
const mockOrders = [
  { id: 'ORD20260314001', date: '2026-03-14', amount: 299, status: '已完成' },
  { id: 'ORD20260310002', date: '2026-03-10', amount: 599, status: '已完成' },
  { id: 'ORD20260305003', date: '2026-03-05', amount: 129, status: '已完成' },
];

interface IAdminMembersProps {}

const AdminMembers: React.FC<IAdminMembersProps> = () => {
  const [members, setMembers] = useState<IMember[]>(mockMembers);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [selectedMember, setSelectedMember] = useState<IMember | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isBlacklistDialogOpen, setIsBlacklistDialogOpen] = useState(false);
  const [blacklistReason, setBlacklistReason] = useState('');

  // 过滤会员
  const filteredMembers = members.filter((member) => {
    const matchSearch =
      member.nickname.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      member.phone.includes(searchKeyword);
    const matchTab =
      activeTab === 'all'
        ? true
        : activeTab === 'active'
          ? member.status === 'active'
          : activeTab === 'blacklisted'
            ? member.status === 'blacklisted'
            : true;
    return matchSearch && matchTab;
  });

  // 查看详情
  const handleViewDetail = (member: IMember) => {
    setSelectedMember(member);
    setIsDetailOpen(true);
  };

  // 加入黑名单
  const handleAddToBlacklist = (member: IMember) => {
    setSelectedMember(member);
    setIsBlacklistDialogOpen(true);
  };

  // 确认加入黑名单
  const confirmAddToBlacklist = () => {
    if (selectedMember) {
      setMembers((prev) =>
        prev.map((m) =>
          m.id === selectedMember.id
            ? { ...m, isBlacklisted: true, status: 'blacklisted' }
            : m
        )
      );
      setIsBlacklistDialogOpen(false);
      setBlacklistReason('');
    }
  };

  // 移出黑名单
  const handleRemoveFromBlacklist = (memberId: string) => {
    setMembers((prev) =>
      prev.map((m) =>
        m.id === memberId
          ? { ...m, isBlacklisted: false, status: 'active' }
          : m
      )
    );
  };

  // 表格列定义
  const columns = [
    {
      title: '会员信息',
      key: 'member',
      render: (_: unknown, record: IMember) => (
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={record.avatar} alt={record.nickname} />
            <AvatarFallback className="bg-gray-100 text-gray-600 text-sm">
              {record.nickname.slice(0, 1)}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium text-gray-900">{record.nickname}</p>
            <p className="text-sm text-gray-500">{record.phone}</p>
          </div>
        </div>
      ),
    },
    {
      title: '注册时间',
      key: 'registerTime',
      dataIndex: 'registerTime',
      render: (text: string) => (
        <div className="flex items-center gap-2 text-gray-500">
          <Calendar className="h-4 w-4" />
          <span className="text-sm">{text}</span>
        </div>
      ),
    },
    {
      title: '订单数',
      key: 'orderCount',
      dataIndex: 'orderCount',
      render: (count: number) => (
        <div className="flex items-center gap-2">
          <ShoppingBag className="h-4 w-4 text-gray-400" />
          <span className="text-sm font-medium text-gray-900">{count}</span>
        </div>
      ),
    },
    {
      title: '累计消费',
      key: 'totalSpent',
      dataIndex: 'totalSpent',
      render: (amount: number) => (
        <div className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-gray-400" />
          <span className="text-sm font-medium text-gray-900">
            ¥{amount.toLocaleString()}
          </span>
        </div>
      ),
    },
    {
      title: '状态',
      key: 'status',
      render: (_: unknown, record: IMember) => (
        <Badge
          variant="outline"
          className={
            record.status === 'active'
              ? 'border-green-200 bg-green-50 text-green-700'
              : record.status === 'inactive'
                ? 'border-gray-200 bg-gray-100 text-gray-600'
                : 'border-red-200 bg-red-50 text-red-700'
          }
        >
          {record.status === 'active'
            ? '正常'
            : record.status === 'inactive'
              ? '未激活'
              : '已拉黑'}
        </Badge>
      ),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right' as const,
      render: (_: unknown, record: IMember) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 text-gray-600 hover:text-gray-900"
            onClick={() => handleViewDetail(record)}
          >
            <Eye className="h-4 w-4 mr-1" />
            详情
          </Button>
          {!record.isBlacklisted ? (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={() => handleAddToBlacklist(record)}
            >
              <UserX className="h-4 w-4 mr-1" />
              拉黑
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-green-600 hover:text-green-700 hover:bg-green-50"
              onClick={() => handleRemoveFromBlacklist(record.id)}
            >
              <UserCheck className="h-4 w-4 mr-1" />
              解除
            </Button>
          )}
        </div>
      ),
    },
  ];

  // 统计卡片数据
  const stats = [
    {
      title: '总会员数',
      value: members.length,
      icon: Users,
    },
    {
      title: '活跃会员',
      value: members.filter((m) => m.status === 'active').length,
      icon: CheckCircle,
    },
    {
      title: '黑名单',
      value: members.filter((m) => m.status === 'blacklisted').length,
      icon: Ban,
    },
    {
      title: '总消费额',
      value: `¥${members.reduce((sum, m) => sum + m.totalSpent, 0).toLocaleString()}`,
      icon: DollarSign,
    },
  ];

  return (
    <>
      <style jsx>{`
        .members-page {
          animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>

      <div className="members-page w-full space-y-6">
        {/* 页面标题 */}
        <section className="w-full">
          <h1 className="text-2xl font-semibold text-gray-900">客户管理</h1>
          <p className="text-gray-500 mt-1 text-sm">
            查看和管理商城注册用户
          </p>
        </section>

        {/* 统计卡片 */}
        <section className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => (
            <Card key={index} className="border-gray-200">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-gray-100">
                    <stat.icon className="h-5 w-5 text-gray-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">{stat.title}</p>
                    <p className="text-xl font-semibold text-gray-900">
                      {stat.value}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        {/* 会员列表 */}
        <section className="w-full">
          <Card className="border-gray-200">
            <CardContent className="p-5">
              {/* 筛选栏 */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-5">
                <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1">
                  {[
                    { key: 'all', label: '全部' },
                    { key: 'active', label: '活跃' },
                    { key: 'blacklisted', label: '黑名单' },
                  ].map((tab) => (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key)}
                      className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
                        activeTab === tab.key
                          ? 'bg-white text-gray-900 shadow-sm'
                          : 'text-gray-500 hover:text-gray-700'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜索客户姓名或手机号"
                    className="pl-10 w-[260px] border-gray-200"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                  />
                </div>
              </div>

              {/* 表格 */}
              <Table
                columns={columns}
                dataSource={filteredMembers}
                rowKey="id"
                pagination={{
                  pageSize: 10,
                  showSizeChanger: false,
                  showTotal: (total: number) => `共 ${total} 位客户`,
                }}
              />
            </CardContent>
          </Card>
        </section>

        {/* 会员详情弹窗 */}
        <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto border-gray-200">
            <DialogHeader>
              <DialogTitle className="text-gray-900">客户详情</DialogTitle>
              <DialogDescription className="text-gray-500">
                查看客户的详细信息和历史记录
              </DialogDescription>
            </DialogHeader>
            {selectedMember && (
              <div className="space-y-6 mt-4">
                {/* 基本信息 */}
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage
                      src={selectedMember.avatar}
                      alt={selectedMember.nickname}
                    />
                    <AvatarFallback className="bg-gray-100 text-gray-600 text-lg">
                      {selectedMember.nickname.slice(0, 1)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900">
                      {selectedMember.nickname}
                    </h3>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="flex items-center gap-1 text-sm text-gray-500">
                        <Phone className="h-4 w-4" />
                        {selectedMember.phone}
                      </span>
                      <Badge
                        variant="outline"
                        className={
                          selectedMember.status === 'active'
                            ? 'border-green-200 bg-green-50 text-green-700'
                            : 'border-red-200 bg-red-50 text-red-700'
                        }
                      >
                        {selectedMember.status === 'active' ? '正常' : '已拉黑'}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* 统计信息 */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-2xl font-semibold text-gray-900">
                      {selectedMember.orderCount}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">订单数</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-2xl font-semibold text-gray-900">
                      ¥{selectedMember.totalSpent.toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">累计消费</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center">
                    <p className="text-lg font-semibold text-gray-900">
                      {selectedMember.registerTime}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">注册时间</p>
                  </div>
                </div>

                {/* 收货地址 */}
                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    收货地址
                  </h4>
                  <div className="space-y-2">
                    {mockAddresses.map((addr) => (
                      <div
                        key={addr.id}
                        className="p-3 border border-gray-200 rounded-lg flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-900">{addr.name}</span>
                            <span className="text-sm text-gray-500">
                              {addr.phone}
                            </span>
                            {addr.isDefault && (
                              <Badge variant="outline" className="text-xs border-gray-200">
                                默认
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            {addr.province} {addr.city} {addr.district} {addr.detail}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 最近订单 */}
                <div>
                  <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <ShoppingBag className="h-4 w-4 text-gray-500" />
                    最近订单
                  </h4>
                  <div className="space-y-2">
                    {mockOrders.map((order) => (
                      <div
                        key={order.id}
                        className="p-3 border border-gray-200 rounded-lg flex items-center justify-between"
                      >
                        <div>
                          <p className="font-medium text-gray-900">{order.id}</p>
                          <p className="text-sm text-gray-500">{order.date}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium text-gray-900">
                            ¥{order.amount}
                          </p>
                          <Badge variant="outline" className="text-xs border-gray-200">
                            {order.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            <DialogFooter className="gap-2">
              <Button 
                variant="outline" 
                onClick={() => setIsDetailOpen(false)}
                className="border-gray-200"
              >
                关闭
              </Button>
              {selectedMember && !selectedMember.isBlacklisted && (
                <Button
                  variant="destructive"
                  onClick={() => {
                    setIsDetailOpen(false);
                    handleAddToBlacklist(selectedMember);
                  }}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <UserX className="h-4 w-4 mr-2" />
                  加入黑名单
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* 黑名单确认弹窗 */}
        <Dialog
          open={isBlacklistDialogOpen}
          onOpenChange={setIsBlacklistDialogOpen}
        >
          <DialogContent className="border-gray-200">
            <DialogHeader>
              <DialogTitle className="text-gray-900">确认加入黑名单</DialogTitle>
              <DialogDescription className="text-gray-500">
                拉黑后该用户将无法登录和下单
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              {selectedMember && (
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Avatar className="h-10 w-10">
                    <AvatarImage
                      src={selectedMember.avatar}
                      alt={selectedMember.nickname}
                    />
                    <AvatarFallback className="bg-gray-100 text-gray-600">
                      {selectedMember.nickname.slice(0, 1)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-gray-900">{selectedMember.nickname}</p>
                    <p className="text-sm text-gray-500">{selectedMember.phone}</p>
                  </div>
                </div>
              )}
              <div>
                <label className="text-sm font-medium text-gray-700">拉黑原因（选填）</label>
                <Input
                  placeholder="请输入拉黑原因"
                  value={blacklistReason}
                  onChange={(e) => setBlacklistReason(e.target.value)}
                  className="mt-2 border-gray-200"
                />
              </div>
            </div>
            <DialogFooter className="gap-2 mt-4">
              <Button
                variant="outline"
                onClick={() => setIsBlacklistDialogOpen(false)}
                className="border-gray-200"
              >
                取消
              </Button>
              <Button 
                variant="destructive" 
                onClick={confirmAddToBlacklist}
                className="bg-red-600 hover:bg-red-700"
              >
                确认拉黑
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default AdminMembers;
