import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  Package, 
  Truck, 
  MapPin, 
  User, 
  CreditCard, 
  FileText,
  ChevronRight,
  Copy,
  ShoppingBag,
  CheckCircle2,
  Clock,
  Box
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface IOrderDetailPageProps {}

interface IOrderItem {
  id: string;
  productId: string;
  name: string;
  image: string;
  specs: Record<string, string>;
  price: number;
  quantity: number;
}

interface ILogisticsTrack {
  time: string;
  status: string;
  location?: string;
}

interface IOrderData {
  id: string;
  orderNo: string;
  status: 'pending' | 'paid' | 'shipped' | 'delivered' | 'completed' | 'cancelled';
  statusText: string;
  createTime: string;
  payTime?: string;
  shipTime?: string;
  receiveTime?: string;
  items: IOrderItem[];
  receiver: {
    name: string;
    phone: string;
    province: string;
    city: string;
    district: string;
    detail: string;
  };
  logistics?: {
    company: string;
    companyCode: string;
    trackingNo: string;
    tracks: ILogisticsTrack[];
  };
  payment: {
    method: string;
    total: number;
    shipping: number;
    discount: number;
    actual: number;
  };
  invoice?: {
    type: 'personal' | 'company';
    title: string;
    taxNo?: string;
  };
}

const mockOrderData: IOrderData = {
  id: '1',
  orderNo: '202603140001',
  status: 'shipped',
  statusText: '运输中',
  createTime: '2026-03-12 14:30',
  payTime: '2026-03-12 14:32',
  shipTime: '2026-03-13 09:15',
  items: [
    {
      id: 'item1',
      productId: 'p1',
      name: 'AirPods Pro',
      image: 'https://picsum.photos/seed/airpods/400/400',
      specs: { 颜色: '白色' },
      price: 1999,
      quantity: 1
    },
    {
      id: 'item2',
      productId: 'p2',
      name: 'USB-C 充电线',
      image: 'https://picsum.photos/seed/cable/400/400',
      specs: { 长度: '1米' },
      price: 149,
      quantity: 2
    }
  ],
  receiver: {
    name: '张三',
    phone: '138****8888',
    province: '北京市',
    city: '北京市',
    district: '朝阳区',
    detail: '建国路88号'
  },
  logistics: {
    company: '顺丰速运',
    companyCode: 'SF',
    trackingNo: 'SF1234567890123',
    tracks: [
      { time: '2026-03-13 14:30', status: '快件已到达北京朝阳区营业点', location: '北京' },
      { time: '2026-03-13 09:15', status: '快件已发出，准备送往北京朝阳区', location: '北京' },
      { time: '2026-03-13 07:20', status: '顺丰速运已收取快件', location: '上海' }
    ]
  },
  payment: {
    method: '微信支付',
    total: 2297,
    shipping: 0,
    discount: 0,
    actual: 2297
  },
  invoice: {
    type: 'personal',
    title: '张三'
  }
};

const statusConfig: Record<string, { label: string; description: string }> = {
  pending: { label: '待付款', description: '请在30分钟内完成支付' },
  paid: { label: '已付款', description: '商家正在准备您的订单' },
  shipped: { label: '运输中', description: '预计明日送达' },
  delivered: { label: '已送达', description: '快件已送达' },
  completed: { label: '已完成', description: '订单已完成' },
  cancelled: { label: '已取消', description: '订单已取消' }
};

const OrderDetailPage: React.FC<IOrderDetailPageProps> = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<IOrderData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAllTracks, setShowAllTracks] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setOrder(mockOrderData);
      setLoading(false);
    }, 300);
  }, [id]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('已复制');
  };

  if (loading) {
    return (
      <div className="w-full max-w-3xl mx-auto py-12 px-6">
        <div className="animate-pulse space-y-8">
          <div className="h-24 bg-gray-100 rounded-2xl" />
          <div className="h-32 bg-gray-100 rounded-2xl" />
          <div className="h-48 bg-gray-100 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="w-full max-w-3xl mx-auto py-24 px-6 text-center">
        <Box className="w-16 h-16 text-gray-300 mx-auto mb-6" strokeWidth={1.5} />
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">订单不存在</h2>
        <p className="text-gray-500 mb-8">抱歉，未找到该订单信息</p>
        <Button variant="outline" onClick={() => navigate('/orders')}>
          返回订单列表
        </Button>
      </div>
    );
  }

  const config = statusConfig[order.status];
  const latestTrack = order.logistics?.tracks[0];

  return (
    <div className="w-full max-w-3xl mx-auto py-8 px-6 space-y-8">
      {/* 订单状态 */}
      <section className="w-full">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-3xl font-semibold text-gray-900 mb-1">{config.label}</h1>
            <p className="text-gray-500">{config.description}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400 mb-1">订单编号</p>
            <div className="flex items-center gap-2">
              <span className="font-medium text-gray-900">{order.orderNo}</span>
              <button 
                onClick={() => handleCopy(order.orderNo)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 物流进度 */}
        {order.logistics && order.status !== 'cancelled' && (
          <div className="bg-gray-50 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Truck className="w-5 h-5 text-gray-700" strokeWidth={1.5} />
                <span className="font-medium text-gray-900">{order.logistics.company}</span>
              </div>
              <button 
                onClick={() => handleCopy(order.logistics!.trackingNo)}
                className="text-sm text-gray-500 hover:text-gray-700 transition-colors flex items-center gap-1"
              >
                {order.logistics.trackingNo}
                <Copy className="w-3.5 h-3.5" />
              </button>
            </div>
            
            {latestTrack && (
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-2 shrink-0" />
                <div className="flex-1">
                  <p className="text-gray-900 mb-1">{latestTrack.status}</p>
                  <p className="text-sm text-gray-400">{latestTrack.time}</p>
                </div>
              </div>
            )}

            {/* 物流详情 */}
            <div className="mt-4 pt-4 border-t border-gray-200">
              <button 
                onClick={() => setShowAllTracks(!showAllTracks)}
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-1"
              >
                {showAllTracks ? '收起' : '查看全部物流信息'}
                <ChevronRight className={cn("w-4 h-4 transition-transform", showAllTracks && "rotate-90")} />
              </button>
              
              {showAllTracks && (
                <div className="mt-4 space-y-4">
                  {order.logistics.tracks.map((track, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <div className={cn(
                        "w-2 h-2 rounded-full mt-2 shrink-0",
                        index === 0 ? "bg-green-500" : "bg-gray-300"
                      )} />
                      <div className="flex-1">
                        <p className={cn(
                          "text-sm mb-0.5",
                          index === 0 ? "text-gray-900" : "text-gray-500"
                        )}>
                          {track.status}
                        </p>
                        <p className="text-xs text-gray-400">{track.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* 商品列表 */}
      <section className="w-full">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">商品</h2>
        <div className="space-y-4">
          {order.items.map((item) => (
            <Link 
              key={item.id} 
              to={`/product/${item.productId}`}
              className="flex gap-4 p-4 bg-white rounded-2xl border border-gray-100 hover:border-gray-200 transition-colors"
            >
              <img 
                src={item.image} 
                alt={item.name}
                className="w-20 h-20 object-cover rounded-xl bg-gray-100"
              />
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-gray-900 mb-1">{item.name}</h3>
                <p className="text-sm text-gray-500 mb-2">
                  {Object.entries(item.specs).map(([key, value]) => `${key}: ${value}`).join(' · ')}
                </p>
                <div className="flex items-center justify-between">
                  <span className="font-medium text-gray-900">¥{item.price.toLocaleString()}</span>
                  <span className="text-sm text-gray-400">数量 {item.quantity}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 收货信息 */}
      <section className="w-full">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">收货信息</h2>
        <div className="bg-gray-50 rounded-2xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
              <User className="w-5 h-5 text-gray-600" strokeWidth={1.5} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <span className="font-medium text-gray-900">{order.receiver.name}</span>
                <span className="text-gray-500">{order.receiver.phone}</span>
              </div>
              <p className="text-gray-500 text-sm leading-relaxed">
                {order.receiver.province} {order.receiver.city} {order.receiver.district} {order.receiver.detail}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 支付信息 */}
      <section className="w-full">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">支付信息</h2>
        <div className="bg-gray-50 rounded-2xl p-6 space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">商品小计</span>
            <span className="text-gray-900">¥{order.payment.total.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">运费</span>
            <span className="text-gray-900">{order.payment.shipping === 0 ? '免费' : `¥${order.payment.shipping}`}</span>
          </div>
          {order.payment.discount > 0 && (
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">优惠</span>
              <span className="text-green-600">-¥{order.payment.discount}</span>
            </div>
          )}
          <Separator className="my-3" />
          <div className="flex justify-between items-center">
            <span className="font-medium text-gray-900">总计</span>
            <span className="text-2xl font-semibold text-gray-900">¥{order.payment.actual.toLocaleString()}</span>
          </div>
          <div className="pt-2 text-sm text-gray-400">
            支付方式：{order.payment.method}
          </div>
        </div>
      </section>

      {/* 发票信息 */}
      {order.invoice && (
        <section className="w-full">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">发票</h2>
          <div className="bg-gray-50 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-3">
              <FileText className="w-5 h-5 text-gray-500" strokeWidth={1.5} />
              <span className="font-medium text-gray-900">
                {order.invoice.type === 'personal' ? '个人发票' : '公司发票'}
              </span>
            </div>
            <p className="text-gray-600 text-sm ml-8">{order.invoice.title}</p>
          </div>
        </section>
      )}

      {/* 操作按钮 */}
      <section className="w-full pt-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {order.status === 'pending' && (
            <>
              <Button 
                className="flex-1 h-12 bg-gray-900 hover:bg-gray-800 text-white rounded-full"
                onClick={() => navigate(`/checkout?order=${order.id}`)}
              >
                立即支付
              </Button>
              <Button 
                variant="outline" 
                className="flex-1 h-12 rounded-full border-gray-300"
                onClick={() => {}}
              >
                取消订单
              </Button>
            </>
          )}
          {order.status === 'shipped' && (
            <>
              <Button 
                className="flex-1 h-12 bg-gray-900 hover:bg-gray-800 text-white rounded-full"
                onClick={() => {}}
              >
                确认收货
              </Button>
              <Button 
                variant="outline" 
                className="flex-1 h-12 rounded-full border-gray-300"
                onClick={() => navigate('/support')}
              >
                需要帮助
              </Button>
            </>
          )}
          {order.status === 'delivered' && (
            <Button 
              className="w-full h-12 bg-gray-900 hover:bg-gray-800 text-white rounded-full"
              onClick={() => navigate(`/orders/${order.id}/review`)}
            >
              评价商品
            </Button>
          )}
          {(order.status === 'completed' || order.status === 'cancelled') && (
            <Button 
              variant="outline" 
              className="w-full h-12 rounded-full border-gray-300"
              onClick={() => navigate('/category')}
            >
              继续购物
            </Button>
          )}
        </div>
      </section>
    </div>
  );
};

export default OrderDetailPage;
