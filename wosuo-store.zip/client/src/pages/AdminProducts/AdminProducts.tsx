import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Search,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  Trash2,
  ArrowUpCircle,
  ArrowDownCircle,
} from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';

interface IProduct {
  id: string;
  name: string;
  image: string;
  category: string;
  price: number;
  stock: number;
  sales: number;
  status: 'on' | 'off';
  createTime: string;
}

const mockProducts: IProduct[] = [
  {
    id: '1',
    name: 'MacBook Pro 14',
    image: 'https://picsum.photos/seed/macbook/80/80',
    category: '笔记本',
    price: 14999,
    stock: 56,
    sales: 234,
    status: 'on',
    createTime: '2026-03-10',
  },
  {
    id: '2',
    name: 'iPhone 15 Pro',
    image: 'https://picsum.photos/seed/iphone/80/80',
    category: '手机',
    price: 7999,
    stock: 128,
    sales: 892,
    status: 'on',
    createTime: '2026-03-09',
  },
  {
    id: '3',
    name: 'AirPods Pro',
    image: 'https://picsum.photos/seed/airpods/80/80',
    category: '音频',
    price: 1899,
    stock: 0,
    sales: 1567,
    status: 'off',
    createTime: '2026-03-08',
  },
  {
    id: '4',
    name: 'iPad Air',
    image: 'https://picsum.photos/seed/ipad/80/80',
    category: '平板',
    price: 4799,
    stock: 89,
    sales: 456,
    status: 'on',
    createTime: '2026-03-07',
  },
  {
    id: '5',
    name: 'Apple Watch Ultra',
    image: 'https://picsum.photos/seed/watch/80/80',
    category: '手表',
    price: 6299,
    stock: 45,
    sales: 234,
    status: 'on',
    createTime: '2026-03-06',
  },
];

interface IAdminProductsProps {}

const AdminProducts: React.FC<IAdminProductsProps> = () => {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([]);

  const handleEdit = (id: string) => {
    navigate(`/admin/products/${id}`);
  };

  const handleDelete = (id: string) => {
    logger.info('Delete product:', id);
  };

  const handleBatchDelete = () => {
    logger.info('Batch delete:', selectedRowKeys);
  };

  const handleBatchOn = () => {
    logger.info('Batch on shelf:', selectedRowKeys);
  };

  const handleBatchOff = () => {
    logger.info('Batch off shelf:', selectedRowKeys);
  };

  const getStatusBadge = (status: IProduct['status']) => {
    switch (status) {
      case 'on':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-700 hover:bg-gray-100">上架中</Badge>;
      case 'off':
        return <Badge variant="secondary" className="bg-gray-100 text-gray-400 hover:bg-gray-100">已下架</Badge>;
    }
  };

  const columns = [
    {
      title: '产品',
      dataIndex: 'name',
      key: 'name',
      fixed: 'left' as const,
      render: (_: unknown, record: IProduct) => (
        <div className="flex items-center gap-3">
          <img
            src={record.image}
            alt={record.name}
            className="w-10 h-10 rounded-lg object-cover bg-gray-100"
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">{record.name}</p>
            <p className="text-xs text-gray-400">{record.category}</p>
          </div>
        </div>
      ),
    },
    {
      title: '价格',
      dataIndex: 'price',
      key: 'price',
      width: 120,
      render: (price: number) => <span className="text-sm text-gray-900">¥{price.toLocaleString()}</span>,
    },
    {
      title: '库存',
      dataIndex: 'stock',
      key: 'stock',
      width: 100,
      render: (stock: number) => (
        <span className={`text-sm ${stock === 0 ? 'text-red-500' : 'text-gray-600'}`}>{stock}</span>
      ),
    },
    {
      title: '销量',
      dataIndex: 'sales',
      key: 'sales',
      width: 100,
      render: (sales: number) => <span className="text-sm text-gray-600">{sales}</span>,
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 100,
      render: (status: IProduct['status']) => getStatusBadge(status),
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 120,
      render: (time: string) => <span className="text-sm text-gray-500">{time}</span>,
    },
    {
      title: '',
      key: 'action',
      fixed: 'right' as const,
      width: 60,
      render: (_: unknown, record: IProduct) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreHorizontal className="h-4 w-4 text-gray-500" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem onClick={() => handleEdit(record.id)} className="cursor-pointer">
              <Edit className="mr-2 h-4 w-4" />
              编辑
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate(`/product/${record.id}`)} className="cursor-pointer">
              <Eye className="mr-2 h-4 w-4" />
              预览
            </DropdownMenuItem>
            {record.status === 'off' ? (
              <DropdownMenuItem onClick={() => {}} className="cursor-pointer">
                <ArrowUpCircle className="mr-2 h-4 w-4" />
                上架
              </DropdownMenuItem>
            ) : (
              <DropdownMenuItem onClick={() => {}} className="cursor-pointer">
                <ArrowDownCircle className="mr-2 h-4 w-4" />
                下架
              </DropdownMenuItem>
            )}
            <DropdownMenuItem
              onClick={() => handleDelete(record.id)}
              className="cursor-pointer text-red-600 focus:text-red-600"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              删除
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];

  const rowSelection = {
    selectedRowKeys,
    onChange: (keys: React.Key[]) => setSelectedRowKeys(keys as string[]),
  };

  return (
    <>
      <style jsx>{`
        .products-page {
          animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="products-page w-full space-y-6">
        <section className="w-full flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">产品</h1>
            <p className="text-sm text-gray-500 mt-1">管理商城产品信息</p>
          </div>
          <Button 
            onClick={() => navigate('/admin/products/new')} 
            className="h-10 px-4 bg-gray-900 hover:bg-gray-800 text-white rounded-lg"
          >
            <Plus className="h-4 w-4 mr-2" />
            新增产品
          </Button>
        </section>

        <section className="w-full">
          <Card className="border-gray-200">
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 min-w-[240px] max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="搜索产品名称..."
                    value={searchText}
                    onChange={(e) => setSearchText(e.target.value)}
                    className="pl-10 h-10 border-gray-200 focus:border-gray-400"
                  />
                </div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[140px] h-10 border-gray-200">
                    <SelectValue placeholder="全部分类" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部分类</SelectItem>
                    <SelectItem value="laptop">笔记本</SelectItem>
                    <SelectItem value="phone">手机</SelectItem>
                    <SelectItem value="audio">音频</SelectItem>
                    <SelectItem value="tablet">平板</SelectItem>
                    <SelectItem value="watch">手表</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px] h-10 border-gray-200">
                    <SelectValue placeholder="全部状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="on">上架中</SelectItem>
                    <SelectItem value="off">已下架</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </section>

        {selectedRowKeys.length > 0 && (
          <section className="w-full">
            <Card className="bg-gray-50 border-gray-200">
              <CardContent className="p-3 flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  已选择 <span className="font-medium text-gray-900">{selectedRowKeys.length}</span> 件产品
                </span>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleBatchOn} className="h-8 border-gray-300">
                    上架
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleBatchOff} className="h-8 border-gray-300">
                    下架
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleBatchDelete} className="h-8 border-red-200 text-red-600 hover:bg-red-50">
                    删除
                  </Button>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        <section className="w-full">
          <Card className="border-gray-200">
            <CardContent className="p-0">
              <Table
                columns={columns}
                dataSource={mockProducts}
                rowKey="id"
                rowSelection={rowSelection}
                scroll={{ x: 800 }}
                pagination={{
                  total: mockProducts.length,
                  pageSize: 10,
                  showSizeChanger: true,
                  showTotal: (total: number) => `共 ${total} 条`,
                }}
              />
            </CardContent>
          </Card>
        </section>
      </div>
    </>
  );
};

export default AdminProducts;
