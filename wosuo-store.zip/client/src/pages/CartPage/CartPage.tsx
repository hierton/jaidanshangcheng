import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingBag, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { Image } from '@/components/ui/image';
import { useLanguage } from '@/lib/i18n';

interface ICartItem {
  id: string;
  productId: string;
  skuId: string;
  name: string;
  image: string;
  specs: Record<string, string>;
  price: number;
  quantity: number;
  stock: number;
  selected: boolean;
  valid: boolean;
}

const STORAGE_KEY = '__global_shop_cart';

const CartPage: React.FC = () => {
  const navigate = useNavigate();
  const { t, lang } = useLanguage();
  const [cartItems, setCartItems] = useState<ICartItem[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [isBatchDelete, setIsBatchDelete] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setCartItems(Array.isArray(parsed) ? parsed : []);
      } catch {
        setCartItems([]);
      }
    }
  }, []);

  useEffect(() => {
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(cartItems));
    window.dispatchEvent(new StorageEvent('storage', { key: STORAGE_KEY }));
  }, [cartItems]);

  const selectedItems = cartItems.filter(item => item.selected && item.valid);
  const selectedCount = selectedItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = selectedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const allSelected = cartItems.length > 0 && cartItems.every(item => item.selected);
  const hasSelected = selectedItems.length > 0;

  const handleSelectAll = (checked: boolean) => {
    setCartItems(prev => prev.map(item => ({ ...item, selected: checked })));
  };

  const handleSelectItem = (id: string, checked: boolean) => {
    setCartItems(prev =>
      prev.map(item => (item.id === id ? { ...item, selected: checked } : item))
    );
  };

  const handleQuantityChange = (id: string, quantity: number) => {
    if (quantity < 1) return;
    const item = cartItems.find(i => i.id === id);
    if (item && quantity > item.stock) {
      quantity = item.stock;
    }
    setCartItems(prev =>
      prev.map(item => (item.id === id ? { ...item, quantity } : item))
    );
  };

  const handleDeleteClick = (id?: string) => {
    if (id) {
      setItemToDelete(id);
      setIsBatchDelete(false);
    } else {
      setIsBatchDelete(true);
    }
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (isBatchDelete) {
      setCartItems(prev => prev.filter(item => !item.selected));
    } else if (itemToDelete) {
      setCartItems(prev => prev.filter(item => item.id !== itemToDelete));
    }
    setDeleteDialogOpen(false);
    setItemToDelete(null);
    setIsBatchDelete(false);
  };

  const handleCheckout = () => {
    if (!hasSelected) return;
    const orderItems = cartItems.filter(item => item.selected && item.valid);
    sessionStorage.setItem('__global_shop_currentOrder', JSON.stringify(orderItems));
    navigate('/checkout');
  };

  const formatPrice = (price: number) => {
    if (lang === 'en') {
      return `$${price.toLocaleString('en-US')}`;
    }
    return `¥${price.toLocaleString('zh-CN')}`;
  };

  const validItems = cartItems.filter(item => item.valid);
  const invalidItems = cartItems.filter(item => !item.valid);

  if (cartItems.length === 0) {
    return (
      <section className="w-full max-w-4xl mx-auto px-6 py-24">
        <div className="flex flex-col items-center justify-center text-center">
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center mb-8">
            <ShoppingBag className="w-8 h-8 text-gray-400" strokeWidth={1.5} />
          </div>
          <h1 className="text-3xl font-semibold text-gray-900 mb-3">{t('emptyCart')}</h1>
          <p className="text-gray-500 mb-8">{lang === 'en' ? 'Discover products you love' : '发现你喜欢的产品，加入购物袋'}</p>
          <Button 
            onClick={() => navigate('/category')} 
            className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-8 h-12 text-base"
          >
            {t('viewAll')}
          </Button>
        </div>
      </section>
    );
  }

  return (
    <section className="w-full max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-4xl font-semibold text-gray-900 mb-12">{t('shoppingCart')}</h1>

      {/* 表头 */}
      <div className="hidden md:grid grid-cols-12 gap-4 pb-4 border-b border-gray-200 text-sm text-gray-500">
        <div className="col-span-5 flex items-center gap-4">
          <Checkbox
            checked={allSelected}
            onCheckedChange={handleSelectAll}
          />
          <span>{t('products')}</span>
        </div>
        <div className="col-span-2 text-center">{lang === 'en' ? 'Price' : '单价'}</div>
        <div className="col-span-2 text-center">{lang === 'en' ? 'Qty' : '数量'}</div>
        <div className="col-span-2 text-right">{lang === 'en' ? 'Subtotal' : '小计'}</div>
        <div className="col-span-1"></div>
      </div>

      {/* 有效商品列表 */}
      <div className="divide-y divide-gray-100">
        {validItems.map(item => (
          <div
            key={item.id}
            className="py-8 grid grid-cols-1 md:grid-cols-12 gap-4 items-center"
          >
            {/* 产品信息 */}
            <div className="col-span-5 flex items-center gap-4">
              <Checkbox
                checked={item.selected}
                onCheckedChange={checked => handleSelectItem(item.id, checked as boolean)}
              />
              <div className="w-24 h-24 rounded-xl overflow-hidden bg-gray-100 shrink-0">
                <Image
                  src={item.image}
                  alt={item.name}
                  width={96}
                  height={96}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3
                  className="text-base font-medium text-gray-900 cursor-pointer hover:opacity-70 transition-opacity"
                  onClick={() => navigate(`/product/${item.productId}`)}
                >
                  {item.name}
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  {Object.entries(item.specs).map(([key, value]) => (
                    <span key={key} className="mr-3">{value}</span>
                  ))}
                </p>
              </div>
            </div>

            {/* 单价 */}
            <div className="md:col-span-2 text-gray-900">
              <span className="md:hidden text-gray-500 mr-2">{lang === 'en' ? 'Price:' : '单价:'}</span>
              <span className="text-base">{formatPrice(item.price)}</span>
            </div>

            {/* 数量 */}
            <div className="md:col-span-2 flex items-center">
              <span className="md:hidden text-gray-500 mr-4">{lang === 'en' ? 'Qty:' : '数量:'}</span>
              <div className="flex items-center border border-gray-200 rounded-lg">
                <button
                  className="w-10 h-10 flex items-center justify-center text-gray-500 hover:text-gray-900 disabled:opacity-30"
                  onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                  disabled={item.quantity <= 1}
                >
                  <Minus className="w-4 h-4" strokeWidth={1.5} />
                </button>
                <Input
                  type="number"
                  value={item.quantity}
                  onChange={e => handleQuantityChange(item.id, parseInt(e.target.value) || 1)}
                  className="w-14 h-10 text-center border-0 p-0 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                  min={1}
                  max={item.stock}
                />
                <button
                  className="w-10 h-10 flex items-center justify-center text-gray-500 hover:text-gray-900 disabled:opacity-30"
                  onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                  disabled={item.quantity >= item.stock}
                >
                  <Plus className="w-4 h-4" strokeWidth={1.5} />
                </button>
              </div>
            </div>

            {/* 小计 */}
            <div className="md:col-span-2 text-right">
              <span className="md:hidden text-gray-500 mr-2">{lang === 'en' ? 'Subtotal:' : '小计:'}</span>
              <span className="text-lg font-medium text-gray-900">
                {formatPrice(item.price * item.quantity)}
              </span>
            </div>

            {/* 删除 */}
            <div className="md:col-span-1 flex justify-end">
              <button
                onClick={() => handleDeleteClick(item.id)}
                className="p-2 text-gray-400 hover:text-gray-900 transition-colors"
              >
                <X className="w-5 h-5" strokeWidth={1.5} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 失效商品 */}
      {invalidItems.length > 0 && (
        <div className="mt-12">
          <h2 className="text-lg font-medium text-gray-900 mb-6">{lang === 'en' ? 'Unavailable Items' : '已失效的产品'}</h2>
          <div className="divide-y divide-gray-100">
            {invalidItems.map(item => (
              <div
                key={item.id}
                className="py-6 grid grid-cols-12 gap-4 items-center opacity-50"
              >
                <div className="col-span-5 flex items-center gap-4">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-100 shrink-0">
                    <Image
                      src={item.image}
                      alt={item.name}
                      width={80}
                      height={80}
                      className="w-full h-full object-cover grayscale"
                    />
                  </div>
                  <div>
                    <h3 className="text-base text-gray-500">{item.name}</h3>
                    <p className="text-sm text-gray-400 mt-1">{t('outOfStock')}</p>
                  </div>
                </div>
                <div className="col-span-6"></div>
                <div className="col-span-1 flex justify-end">
                  <button
                    onClick={() => handleDeleteClick(item.id)}
                    className="p-2 text-gray-400 hover:text-gray-900"
                  >
                    <Trash2 className="w-4 h-4" strokeWidth={1.5} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Separator className="my-12" />

      {/* 结算区域 */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <Checkbox
            checked={allSelected}
            onCheckedChange={handleSelectAll}
          />
          <span className="text-gray-600">{lang === 'en' ? 'Select All' : '全选'}</span>
          {selectedItems.length > 0 && (
            <button
              onClick={() => handleDeleteClick()}
              className="text-gray-500 hover:text-gray-900 text-sm ml-4"
            >
              {lang === 'en' ? 'Delete Selected' : '删除选中'}
            </button>
          )}
        </div>

        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <div className="text-right">
            <div className="flex items-baseline gap-3 justify-end">
              <span className="text-gray-500">{t('total')}</span>
              <span className="text-3xl font-semibold text-gray-900">{formatPrice(totalPrice)}</span>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              {selectedCount} {lang === 'en' ? 'items' : t('items')}
            </p>
          </div>
          <Button
            onClick={handleCheckout}
            disabled={!hasSelected}
            className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-12 h-14 text-lg disabled:bg-gray-300"
          >
            {t('checkout')}
          </Button>
        </div>
      </div>

      {/* 删除确认弹窗 */}
      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">{lang === 'en' ? 'Confirm Delete' : '确认删除'}</DialogTitle>
            <DialogDescription className="text-gray-500">
              {isBatchDelete
                ? `${lang === 'en' ? 'Delete' : '删除'} ${selectedItems.length} ${lang === 'en' ? 'selected items?' : '件选中产品？'}`
                : (lang === 'en' ? 'Delete this item?' : '确定要删除该产品吗？')}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-3">
            <Button 
              variant="outline" 
              onClick={() => setDeleteDialogOpen(false)}
              className="rounded-full"
            >
              {t('cancel')}
            </Button>
            <Button 
              onClick={handleConfirmDelete}
              className="bg-gray-900 text-white hover:bg-gray-800 rounded-full"
            >
              {t('confirm')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default CartPage;
