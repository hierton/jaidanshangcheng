import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

// Mock 商品数据
const mockProduct = {
  id: '1',
  name: '无线降噪耳机',
  subtitle: '主动降噪 · 40小时续航 · 空间音频',
  price: 1999,
  description: '采用先进的主动降噪技术，带来沉浸式聆听体验。40小时超长续航，支持快充。空间音频功能，让音乐环绕在你周围。',
  images: [
    'https://picsum.photos/seed/headphone1/800/800',
    'https://picsum.photos/seed/headphone2/800/800',
    'https://picsum.photos/seed/headphone3/800/800',
    'https://picsum.photos/seed/headphone4/800/800',
  ],
  colors: [
    { id: 'midnight', name: '午夜黑', hex: '#1a1a1a' },
    { id: 'silver', name: '银色', hex: '#c4c4c4' },
    { id: 'space', name: '深空灰', hex: '#4a4a4a' },
  ],
  features: [
    '主动降噪',
    '40小时续航',
    '空间音频',
    '蓝牙5.3',
    '快充支持',
  ],
  specs: [
    { label: '重量', value: '250g' },
    { label: '续航', value: '40小时' },
    { label: '充电', value: 'USB-C' },
    { label: '连接', value: '蓝牙5.3' },
  ],
};

interface IProductDetailPageProps {}

const ProductDetailPage: React.FC<IProductDetailPageProps> = () => {
  const navigate = useNavigate();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState(mockProduct.colors[0].id);
  const [quantity, setQuantity] = useState(1);
  const [isZoomed, setIsZoomed] = useState(false);

  const handlePrevImage = () => {
    setCurrentImageIndex(prev => (prev === 0 ? mockProduct.images.length - 1 : prev - 1));
  };

  const handleNextImage = () => {
    setCurrentImageIndex(prev => (prev === mockProduct.images.length - 1 ? 0 : prev + 1));
  };

  const handleAddToCart = () => {
    const cartItem = {
      id: `${mockProduct.id}-${selectedColor}`,
      productId: mockProduct.id,
      name: mockProduct.name,
      image: mockProduct.images[0],
      color: mockProduct.colors.find(c => c.id === selectedColor)?.name || '',
      price: mockProduct.price,
      quantity,
    };
    
    const existingCart = JSON.parse(sessionStorage.getItem('__global_shop_cart') || '[]');
    const existingIndex = existingCart.findIndex((item: { id: string }) => item.id === cartItem.id);
    
    if (existingIndex >= 0) {
      existingCart[existingIndex].quantity += quantity;
    } else {
      existingCart.push(cartItem);
    }
    
    sessionStorage.setItem('__global_shop_cart', JSON.stringify(existingCart));
    window.dispatchEvent(new StorageEvent('storage'));
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/checkout');
  };

  return (
    <>
      <style jsx>{`
        .product-image {
          transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .product-image.zoomed {
          transform: scale(1.5);
          cursor: zoom-out;
        }
        .fade-in {
          animation: fadeIn 0.4s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>

      <div className="w-full bg-white">
        {/* 主内容区 */}
        <section className="w-full">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[calc(100vh-3.5rem)]">
              {/* 左侧：大图展示 */}
              <div className="relative bg-gray-50 flex items-center justify-center p-8 lg:p-16">
                <div 
                  className="relative w-full max-w-lg aspect-square cursor-zoom-in overflow-hidden"
                  onClick={() => setIsZoomed(!isZoomed)}
                >
                  <img
                    src={mockProduct.images[currentImageIndex]}
                    alt={mockProduct.name}
                    className={cn(
                      "product-image w-full h-full object-contain",
                      isZoomed && "zoomed"
                    )}
                  />
                </div>

                {/* 图片切换按钮 */}
                <button
                  onClick={handlePrevImage}
                  className="absolute left-4 lg:left-8 w-12 h-12 bg-white/80 backdrop-blur rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  onClick={handleNextImage}
                  className="absolute right-4 lg:right-8 w-12 h-12 bg-white/80 backdrop-blur rounded-full flex items-center justify-center shadow-sm hover:bg-white transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                {/* 图片指示器 */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2">
                  {mockProduct.images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={cn(
                        'w-2 h-2 rounded-full transition-all duration-300',
                        index === currentImageIndex ? 'bg-gray-900 w-6' : 'bg-gray-300 hover:bg-gray-400'
                      )}
                    />
                  ))}
                </div>
              </div>

              {/* 右侧：产品信息 */}
              <div className="flex flex-col justify-center px-8 py-12 lg:px-16 lg:py-0">
                <div className="max-w-md mx-auto lg:mx-0 w-full space-y-8">
                  {/* 产品名称 */}
                  <div className="space-y-2">
                    <h1 className="text-3xl lg:text-4xl font-semibold text-gray-900 tracking-tight">
                      {mockProduct.name}
                    </h1>
                    <p className="text-lg text-gray-500 font-normal">
                      {mockProduct.subtitle}
                    </p>
                  </div>

                  {/* 价格 */}
                  <div className="text-2xl font-medium text-gray-900">
                    ¥{mockProduct.price.toLocaleString()}
                  </div>

                  {/* 产品描述 */}
                  <p className="text-gray-600 leading-relaxed">
                    {mockProduct.description}
                  </p>

                  {/* 颜色选择 */}
                  <div className="space-y-3">
                    <span className="text-sm text-gray-500">
                      颜色 - {mockProduct.colors.find(c => c.id === selectedColor)?.name}
                    </span>
                    <div className="flex items-center gap-3">
                      {mockProduct.colors.map((color) => (
                        <button
                          key={color.id}
                          onClick={() => setSelectedColor(color.id)}
                          className={cn(
                            'w-8 h-8 rounded-full border-2 transition-all',
                            selectedColor === color.id
                              ? 'border-gray-900 scale-110'
                              : 'border-transparent hover:border-gray-300'
                          )}
                          style={{ backgroundColor: color.hex }}
                          aria-label={color.name}
                        />
                      ))}
                    </div>
                  </div>

                  {/* 数量选择 */}
                  <div className="space-y-3">
                    <span className="text-sm text-gray-500">数量</span>
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center text-lg font-medium">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:border-gray-400 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="space-y-3 pt-4">
                    <Button
                      size="lg"
                      className="w-full h-14 bg-gray-900 hover:bg-gray-800 text-white rounded-full text-base font-medium"
                      onClick={handleBuyNow}
                    >
                      立即购买
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      className="w-full h-14 border-gray-900 text-gray-900 hover:bg-gray-50 rounded-full text-base font-medium"
                      onClick={handleAddToCart}
                    >
                      加入购物车
                    </Button>
                  </div>

                  {/* 产品特性 */}
                  <div className="pt-8 border-t border-gray-100">
                    <div className="grid grid-cols-2 gap-4">
                      {mockProduct.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                          <div className="w-1.5 h-1.5 rounded-full bg-gray-900" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <Separator />

        {/* 规格参数 */}
        <section className="w-full py-20">
          <div className="max-w-3xl mx-auto px-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-8">技术规格</h2>
            <div className="space-y-0">
              {mockProduct.specs.map((spec, index) => (
                <div 
                  key={index} 
                  className="flex justify-between py-4 border-b border-gray-100 last:border-b-0"
                >
                  <span className="text-gray-500">{spec.label}</span>
                  <span className="text-gray-900 font-medium">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
};

export default ProductDetailPage;
