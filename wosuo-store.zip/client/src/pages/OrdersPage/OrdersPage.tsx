import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

// 订单状态类型
type OrderStatus = 'all' | 'pending' | 'shipped' | 'delivering' | 'completed' | 'refund';

interface IOrderItem {
  id: string;
  productId: string;
  name: string;
  image: string;
  specs: Record<string, string>;
  price: number;
  quantity: number;
}

interface IOrder {
  id: string;
  orderNo: string;
  status: Exclude<OrderStatus, 'all'>;
  createdAt: string;
  items: IOrderItem[];
  totalAmount: number;
  itemCount: number;
}

// 状态配置 - Apple 极简风格
const statusTabs: { key: OrderStatus; label: string }[] = [
  { key: 'all', label: '全部' },
  { key: 'pending', label: '待付款' },
  { key: 'shipped', label: '待发货' },
  { key: 'delivering', label: '待收货' },
  { key: 'completed', label: '已完成' },
  { key: 'refund', label: '售后' },
];

const statusConfig: Record<Exclude<OrderStatus, 'all'>, { label: string; className: string }> = {
  pending: { label: '待付款', className: 'bg-gray-100 text-gray-700' },
  shipped: { label: '待发货', className: 'bg-gray-100 text-gray-700' },
  delivering: { label: '配送中', className: 'bg-blue-50 text-blue-600' },
  completed: { label: '已完成', className: 'bg-gray-100 text-gray-700' },
  refund: { label: '售后中', className: 'bg-gray-100 text-gray-700' },
};

// Mock 订单数据
const mockOrders: IOrder[] = [
  {
    id: '1',
    orderNo: '202603140001',
    status: 'pending',
    createdAt: '2026年3月14日',
    items: [
      { id: 'i1', productId: 'p1', name: 'iPhone 16 Pro', image: 'https://picsum.photos/seed/iphone/200/200', specs: { 颜色: '深空黑', 容量: '256GB' }, price: 8999, quantity: 1 },
      { id: 'i2', productId: 'p2', name: 'AirPods Pro', image: 'https://picsum.photos/seed/airpods/200/200', specs: { 颜色: '白色' }, price: 1899, quantity: 1 },
    ],
    totalAmount: 10898,
    itemCount: 2,
  },
  {
    id: '2',
    orderNo: '202603130002',
    status: 'delivering',
    createdAt: '2026年3月13日',
    items: [
      { id: 'i3', productId: 'p3', name: 'MacBook Air', image: 'https://picsum.photos/seed/macbook/200/200', specs: { 颜色: '银色', 芯片: 'M3' }, price: 10499, quantity: 1 },
    ],
    totalAmount: 10499,
    itemCount: 1,
  },
  {
    id: '3',
    orderNo: '202603120003',
    status: 'completed',
    createdAt: '2026年3月12日',
    items: [
      { id: 'i4', productId: 'p4', name: 'iPad Air', image: 'https://picsum.photos/seed/ipad/200/200', specs: { 颜色: '深空灰', 容量: '128GB' }, price: 4799, quantity: 1 },
    ],
    totalAmount: 4799,
    itemCount: 1,
  },
  {
    id: '4',
    orderNo: '202603110004',
    status: 'completed',
    createdAt: '2026年3月11日',
    items: [
      { id: 'i5', productId: 'p5', name: 'Apple Watch Series 10', image: 'https://picsum.photos/seed/watch/200/200', specs: { 颜色: '午夜色', 尺寸: '45mm' }, price: 3199, quantity: 1 },
    ],
    totalAmount: 3199,
    itemCount: 1,
  },
];

interface IOrdersPageProps {}

const OrdersPage: React.FC<IOrdersPageProps> = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<OrderStatus>('all');

  // 根据状态筛选订单
  const filteredOrders = useMemo(() => {
    if (activeTab === 'all') return mockOrders;
    return mockOrders.filter(order => order.status === activeTab);
  }, [activeTab]);

  // 处理状态切换
  const handleTabChange = (tab: OrderStatus) => {
    setActiveTab(tab);
  };

  // 渲染订单操作按钮
  const renderOrderActions = (order: IOrder) => {
    switch (order.status) {
      case 'pending':
        return (
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-900">
              取消
            </Button>
            <Button size="sm" className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-5">
              付款
            </Button>
          </div>
        );
      case 'shipped':
        return (
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-900">
            提醒发货
          </Button>
        );
      case 'delivering':
        return (
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-900">
              查看物流
            </Button>
            <Button size="sm" className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-5">
              确认收货
            </Button>
          </div>
        );
      case 'completed':
        return (
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-900">
              申请售后
            </Button>
            <Button size="sm" className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-5">
              再次购买
            </Button>
          </div>
        );
      case 'refund':
        return (
          <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-900">
            查看进度
          </Button>
        );
      default:
        return null;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-6 py-12">
      {/* 页面标题 */}
      <section className="w-full mb-10">
        <h1 className="text-3xl font-semibold text-gray-900 tracking-tight">我的订单</h1>
      </section>

      {/* 状态筛选标签 */}
      <section className="w-full mb-8">
        <div className="flex gap-2 border-b border-gray-200">
          {statusTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => handleTabChange(tab.key)}
              className={cn(
                'px-4 py-3 text-sm font-medium transition-colors relative',
                activeTab === tab.key
                  ? 'text-gray-900'
                  : 'text-gray-500 hover:text-gray-700'
              )}
            >
              {tab.label}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-gray-900" />
              )}
            </button>
          ))}
        </div>
      </section>

      {/* 订单列表 */}
      <section className="w-full space-y-6">
        {filteredOrders.length === 0 ? (
          <div className="w-full py-20 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
              <Package className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">暂无订单</h3>
            <p className="text-gray-500 mb-6">您还没有相关订单</p>
            <Button 
              onClick={() => navigate('/')}
              className="bg-gray-900 text-white hover:bg-gray-800 rounded-full px-8"
            >
              继续购物
            </Button>
          </div>
        ) : (
          filteredOrders.map((order) => {
            const status = statusConfig[order.status];
            
            return (
              <div 
                key={order.id} 
                className="w-full bg-white rounded-2xl border border-gray-200 overflow-hidden hover:border-gray-300 transition-colors"
              >
                {/* 订单头部 */}
                <div className="flex items-center justify-between px-6 py-4 bg-gray-50/50">
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-gray-500">订单号：{order.orderNo}</span>
                    <span className="text-sm text-gray-400">{order.createdAt}</span>
                  </div>
                  <Badge 
                    variant="secondary" 
                    className={cn('text-xs font-medium px-3 py-1 rounded-full', status.className)}
                  >
                    {status.label}
                  </Badge>
                </div>

                <Separator className="bg-gray-100" />

                {/* 商品列表 */}
                <div className="px-6 py-5">
                  <div className="space-y-4">
                    {order.items.map((item, idx) => (
                      <div 
                        key={item.id} 
                        className={cn(
                          'flex gap-5',
                          idx !== order.items.length - 1 && 'pb-4 border-b border-gray-100'
                        )}
                      >
                        <div className="w-20 h-20 rounded-xl bg-gray-100 overflow-hidden shrink-0">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0 flex flex-col justify-center">
                          <h4 className="text-base font-medium text-gray-900">
                            {item.name}
                          </h4>
                          <p className="text-sm text-gray-500 mt-1">
                            {Object.entries(item.specs).map(([key, value]) => value).join(' · ')}
                          </p>
                          <p className="text-sm text-gray-900 mt-2">
                            ¥{item.price.toLocaleString()} × {item.quantity}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator className="bg-gray-100" />

                {/* 订单底部 */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">
                      共 {order.itemCount} 件商品
                    </span>
                    <span className="text-gray-300">|</span>
                    <span className="text-sm text-gray-500">
                      合计
                      <span className="text-lg font-semibold text-gray-900 ml-2">
                        ¥{order.totalAmount.toLocaleString()}
                      </span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-gray-500 hover:text-gray-900"
                      onClick={() => navigate(`/orders/${order.id}`)}
                    >
                      查看详情
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                    {renderOrderActions(order)}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </section>
    </div>
  );
};

export default OrdersPage;
