import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

interface ILoginPageProps {}

const STORAGE_KEY_USER = '__global_shop_user';

const LoginPage: React.FC<ILoginPageProps> = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'code' | 'password'>('code');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [loading, setLoading] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const startCountdown = () => {
    setCountdown(60);
    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current);
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleSendCode = () => {
    if (!phone || phone.length !== 11) {
      toast.error('请输入正确的手机号');
      return;
    }
    startCountdown();
    toast.success('验证码已发送');
  };

  const handleLogin = () => {
    if (!phone || phone.length !== 11) {
      toast.error('请输入正确的手机号');
      return;
    }
    if (activeTab === 'code' && !code) {
      toast.error('请输入验证码');
      return;
    }
    if (activeTab === 'password' && !password) {
      toast.error('请输入密码');
      return;
    }
    if (!agreed) {
      toast.error('请同意用户协议和隐私政策');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const user = {
        id: `user_${Date.now()}`,
        nickname: `用户${phone.slice(-4)}`,
        phone,
        isLogin: true,
      };
      sessionStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
      toast.success('登录成功');
      navigate('/');
      setLoading(false);
    }, 1000);
  };

  return (
    <>
      <style jsx>{`
        .login-page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: white;
        }
        .login-container {
          width: 100%;
          max-width: 400px;
          padding: 2rem;
        }
        @media (min-width: 768px) {
          .login-container {
            padding: 3rem;
          }
        }
        .tab-button {
          position: relative;
          padding-bottom: 0.75rem;
          font-size: 0.9375rem;
          font-weight: 500;
          color: rgb(134 134 139);
          transition: color 0.2s;
        }
        .tab-button:hover {
          color: rgb(29 29 31);
        }
        .tab-button.active {
          color: rgb(29 29 31);
        }
        .tab-button.active::after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          height: 2px;
          background: rgb(29 29 31);
        }
        .input-field {
          height: 3.5rem;
          padding: 0 1rem;
          font-size: 1rem;
          border: 1px solid rgb(210 210 215);
          border-radius: 0.75rem;
          background: white;
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        .input-field:focus {
          outline: none;
          border-color: rgb(0 122 255);
          box-shadow: 0 0 0 4px rgba(0, 122, 255, 0.15);
        }
        .input-field::placeholder {
          color: rgb(134 134 139);
        }
        .login-button {
          height: 3.25rem;
          font-size: 1rem;
          font-weight: 500;
          border-radius: 0.75rem;
          background: rgb(0 122 255);
          transition: all 0.2s;
        }
        .login-button:hover {
          background: rgb(0 113 227);
        }
        .login-button:active {
          transform: scale(0.98);
        }
        .code-button {
          height: 3.5rem;
          padding: 0 1.25rem;
          font-size: 0.9375rem;
          font-weight: 500;
          color: rgb(0 122 255);
          background: transparent;
          border: 1px solid rgb(210 210 215);
          border-radius: 0.75rem;
          transition: all 0.2s;
          white-space: nowrap;
        }
        .code-button:hover:not(:disabled) {
          background: rgb(245 245 247);
        }
        .code-button:disabled {
          color: rgb(134 134 139);
          cursor: not-allowed;
        }
      `}</style>

      <div className="login-page">
        <div className="login-container">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-semibold text-gray-900 tracking-tight mb-2">登录</h1>
            <p className="text-gray-500">欢迎回到 Store</p>
          </div>

          <div className="flex gap-8 mb-8 border-b border-gray-200">
            <button
              onClick={() => setActiveTab('code')}
              className={cn('tab-button', activeTab === 'code' && 'active')}
            >
              验证码
            </button>
            <button
              onClick={() => setActiveTab('password')}
              className={cn('tab-button', activeTab === 'password' && 'active')}
            >
              密码
            </button>
          </div>

          <div className="space-y-4">
            <input
              type="tel"
              placeholder="手机号"
              maxLength={11}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
              className="input-field w-full"
            />

            {activeTab === 'code' ? (
              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="验证码"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                  className="input-field flex-1"
                />
                <button
                  onClick={handleSendCode}
                  disabled={countdown > 0 || phone.length !== 11}
                  className="code-button"
                >
                  {countdown > 0 ? `${countdown}秒` : '获取验证码'}
                </button>
              </div>
            ) : (
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field w-full pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            )}
          </div>

          <div className="flex items-start gap-3 mt-6">
            <Checkbox
              id="agreement"
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked as boolean)}
              className="mt-0.5 border-gray-300 data-[state=checked]:bg-gray-900 data-[state=checked]:border-gray-900"
            />
            <label htmlFor="agreement" className="text-sm text-gray-500 leading-relaxed cursor-pointer">
              我已阅读并同意
              <UniversalLink to="#" className="text-gray-900 hover:underline mx-0.5">用户协议</UniversalLink>
              和
              <UniversalLink to="#" className="text-gray-900 hover:underline mx-0.5">隐私政策</UniversalLink>
            </label>
          </div>

          <Button
            onClick={handleLogin}
            disabled={loading}
            className="login-button w-full mt-8"
          >
            {loading ? '登录中...' : '登录'}
            {!loading && <ArrowRight className="w-4 h-4 ml-2" />}
          </Button>

          <div className="mt-8 text-center">
            <UniversalLink to="#" className="text-sm text-blue-500 hover:underline">
              忘记密码？
            </UniversalLink>
          </div>
        </div>
      </div>
    </>
  );
};

export default LoginPage;
