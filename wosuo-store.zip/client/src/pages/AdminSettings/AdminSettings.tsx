import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Store,
  CreditCard,
  Truck,
  Users,
  FileText,
  Upload,
  Plus,
  Edit,
  Trash2,
  Search,
  Save,
  X,
  Check,
} from 'lucide-react';
import { toast } from 'sonner';

interface IShopConfig {
  name: string;
  logo: string;
  phone: string;
  email: string;
  icp: string;
  copyright: string;
  seoTitle: string;
  seoKeywords: string;
  seoDescription: string;
}

interface IPaymentConfig {
  wechatEnabled: boolean;
  wechatAppId: string;
  wechatMchId: string;
  wechatKey: string;
  alipayEnabled: boolean;
  alipayAppId: string;
  alipayPublicKey: string;
  alipayPrivateKey: string;
  sandboxMode: boolean;
}

interface IExpressCompany {
  id: string;
  name: string;
  code: string;
  enabled: boolean;
}

interface IAdmin {
  id: string;
  name: string;
  account: string;
  role: string;
  status: 'active' | 'inactive';
  lastLogin: string;
}

interface IOperationLog {
  id: string;
  operator: string;
  action: string;
  target: string;
  ip: string;
  time: string;
}

const AdminSettings: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // 从 sessionStorage 加载配置
  const loadSavedConfig = () => {
    try {
      const saved = sessionStorage.getItem('__global_shop_settings');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      logger.error('加载配置失败', e);
    }
    return null;
  };

  const savedConfig = loadSavedConfig();
  
  const [shopConfig, setShopConfig] = useState<IShopConfig>(savedConfig?.shop || {
    name: 'Store',
    logo: '',
    phone: '400-888-8888',
    email: 'support@store.com',
    icp: '京ICP备2026000000号',
    copyright: '© 2026 Store. 保留所有权利。',
    seoTitle: 'Store - 优质产品',
    seoKeywords: '在线购物, 电子产品, 生活方式',
    seoDescription: '在 Store 发现优质产品。',
  });

  const [paymentConfig, setPaymentConfig] = useState<IPaymentConfig>(savedConfig?.payment || {
    wechatEnabled: true,
    wechatAppId: 'wx1234567890',
    wechatMchId: '1234567890',
    wechatKey: '',
    alipayEnabled: true,
    alipayAppId: '2024XXXXXXXX',
    alipayPublicKey: '',
    alipayPrivateKey: '',
    sandboxMode: false,
  });

  const [expressCompanies, setExpressCompanies] = useState<IExpressCompany[]>(savedConfig?.express || [
    { id: '1', name: '顺丰速运', code: 'SF', enabled: true },
    { id: '2', name: '圆通速递', code: 'YTO', enabled: true },
    { id: '3', name: '中通快递', code: 'ZTO', enabled: true },
    { id: '4', name: '申通快递', code: 'STO', enabled: true },
    { id: '5', name: '韵达速递', code: 'YD', enabled: true },
    { id: '6', name: '京东物流', code: 'JD', enabled: true },
  ]);

  const [admins, setAdmins] = useState<IAdmin[]>([
    { id: '1', name: '管理员', account: 'admin', role: '超级管理员', status: 'active', lastLogin: '2026-03-14 10:30' },
    { id: '2', name: '运营人员', account: 'operator', role: '运营', status: 'active', lastLogin: '2026-03-14 09:15' },
    { id: '3', name: '客服人员', account: 'support', role: '客服', status: 'active', lastLogin: '2026-03-13 18:20' },
  ]);

  const [operationLogs, setOperationLogs] = useState<IOperationLog[]>([
    { id: '1', operator: 'admin', action: '登录', target: '系统', ip: '192.168.1.100', time: '2026-03-14 10:30' },
    { id: '2', operator: 'operator', action: '更新产品', target: '产品 #1001', ip: '192.168.1.101', time: '2026-03-14 09:45' },
    { id: '3', operator: 'admin', action: '创建优惠码', target: 'SPRING2026', ip: '192.168.1.100', time: '2026-03-14 09:20' },
  ]);

  // 对话框状态
  const [isAddAdminOpen, setIsAddAdminOpen] = useState(false);
  const [isAddExpressOpen, setIsAddExpressOpen] = useState(false);
  
  // 新物流表单
  const [newExpress, setNewExpress] = useState({ name: '', code: '' });
  
  // 新管理员表单
  const [newAdmin, setNewAdmin] = useState({ name: '', account: '', password: '', role: 'operator' });

  // Logo上传处理
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('请选择图片文件');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('图片大小不能超过2MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      setShopConfig(prev => ({ ...prev, logo: result }));
      toast.success('Logo上传成功');
    };
    reader.onerror = () => {
      toast.error('图片读取失败');
    };
    reader.readAsDataURL(file);
  };

  // 清除Logo
  const handleClearLogo = () => {
    setShopConfig(prev => ({ ...prev, logo: '' }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    toast.success('Logo已清除');
  };

  // 保存所有配置
  const handleSaveConfig = () => {
    const configToSave = {
      shop: shopConfig,
      payment: paymentConfig,
      express: expressCompanies,
    };
    sessionStorage.setItem('__global_shop_settings', JSON.stringify(configToSave));
    
    // 添加操作日志
    const newLog: IOperationLog = {
      id: Date.now().toString(),
      operator: 'admin',
      action: '保存设置',
      target: '系统配置',
      ip: '192.168.1.100',
      time: new Date().toLocaleString('zh-CN'),
    };
    setOperationLogs(prev => [newLog, ...prev]);
    
    toast.success('设置已保存成功');
    logger.info('设置已保存', configToSave);
  };

  // 添加物流
  const handleAddExpress = () => {
    if (!newExpress.name.trim() || !newExpress.code.trim()) {
      toast.error('请填写物流公司和编码');
      return;
    }
    
    const company: IExpressCompany = {
      id: Date.now().toString(),
      name: newExpress.name.trim(),
      code: newExpress.code.trim().toUpperCase(),
      enabled: true,
    };
    
    setExpressCompanies(prev => [...prev, company]);
    setNewExpress({ name: '', code: '' });
    setIsAddExpressOpen(false);
    
    // 添加日志
    const newLog: IOperationLog = {
      id: Date.now().toString(),
      operator: 'admin',
      action: '添加物流',
      target: company.name,
      ip: '192.168.1.100',
      time: new Date().toLocaleString('zh-CN'),
    };
    setOperationLogs(prev => [newLog, ...prev]);
    
    toast.success(`已添加物流：${company.name}`);
  };

  // 切换物流状态
  const toggleExpressStatus = (id: string) => {
    setExpressCompanies(prev => prev.map(c => 
      c.id === id ? { ...c, enabled: !c.enabled } : c
    ));
    
    const company = expressCompanies.find(c => c.id === id);
    if (company) {
      const newStatus = !company.enabled;
      toast.success(`${company.name}已${newStatus ? '启用' : '停用'}`);
      
      const newLog: IOperationLog = {
        id: Date.now().toString(),
        operator: 'admin',
        action: newStatus ? '启用物流' : '停用物流',
        target: company.name,
        ip: '192.168.1.100',
        time: new Date().toLocaleString('zh-CN'),
      };
      setOperationLogs(prev => [newLog, ...prev]);
    }
  };

  // 删除物流
  const deleteExpress = (id: string) => {
    const company = expressCompanies.find(c => c.id === id);
    setExpressCompanies(prev => prev.filter(c => c.id !== id));
    
    if (company) {
      toast.success(`已删除：${company.name}`);
      
      const newLog: IOperationLog = {
        id: Date.now().toString(),
        operator: 'admin',
        action: '删除物流',
        target: company.name,
        ip: '192.168.1.100',
        time: new Date().toLocaleString('zh-CN'),
      };
      setOperationLogs(prev => [newLog, ...prev]);
    }
  };

  // 添加管理员
  const handleAddAdmin = () => {
    if (!newAdmin.name.trim() || !newAdmin.account.trim() || !newAdmin.password.trim()) {
      toast.error('请填写完整信息');
      return;
    }
    
    const admin: IAdmin = {
      id: Date.now().toString(),
      name: newAdmin.name.trim(),
      account: newAdmin.account.trim(),
      role: newAdmin.role === 'super' ? '超级管理员' : newAdmin.role === 'operator' ? '运营' : '客服',
      status: 'active',
      lastLogin: '-',
    };
    
    setAdmins(prev => [...prev, admin]);
    setNewAdmin({ name: '', account: '', password: '', role: 'operator' });
    setIsAddAdminOpen(false);
    
    const newLog: IOperationLog = {
      id: Date.now().toString(),
      operator: 'admin',
      action: '添加成员',
      target: admin.name,
      ip: '192.168.1.100',
      time: new Date().toLocaleString('zh-CN'),
    };
    setOperationLogs(prev => [newLog, ...prev]);
    
    toast.success(`已添加成员：${admin.name}`);
  };

  // 删除管理员
  const deleteAdmin = (id: string) => {
    const admin = admins.find(a => a.id === id);
    if (admin?.account === 'admin') {
      toast.error('不能删除超级管理员');
      return;
    }
    setAdmins(prev => prev.filter(a => a.id !== id));
    
    if (admin) {
      toast.success(`已删除：${admin.name}`);
      
      const newLog: IOperationLog = {
        id: Date.now().toString(),
        operator: 'admin',
        action: '删除成员',
        target: admin.name,
        ip: '192.168.1.100',
        time: new Date().toLocaleString('zh-CN'),
      };
      setOperationLogs(prev => [newLog, ...prev]);
    }
  };

  const adminColumns = [
    { title: '姓名', dataIndex: 'name', key: 'name' },
    { title: '账号', dataIndex: 'account', key: 'account' },
    { title: '角色', dataIndex: 'role', key: 'role' },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Badge variant={status === 'active' ? 'default' : 'secondary'}>
          {status === 'active' ? '活跃' : '停用'}
        </Badge>
      ),
    },
    { title: '最后登录', dataIndex: 'lastLogin', key: 'lastLogin' },
    {
      title: '操作',
      key: 'action',
      render: (_: any, record: IAdmin) => (
        <div className="flex gap-2">
          <Button variant="ghost" size="sm"><Edit className="w-4 h-4" /></Button>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-destructive"
            onClick={() => deleteAdmin(record.id)}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  const logColumns = [
    { title: '操作人', dataIndex: 'operator', key: 'operator' },
    { title: '操作', dataIndex: 'action', key: 'action' },
    { title: '目标', dataIndex: 'target', key: 'target' },
    { title: 'IP地址', dataIndex: 'ip', key: 'ip' },
    { title: '时间', dataIndex: 'time', key: 'time' },
  ];

  return (
    <>
      <style jsx>{`
        .settings-page { animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .logo-preview {
          transition: all 0.3s ease;
        }
        .logo-preview:hover .logo-overlay {
          opacity: 1;
        }
      `}</style>

      <div className="settings-page space-y-6">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">系统设置</h1>
            <p className="text-gray-500 mt-1">配置商城基础信息、支付方式和系统参数</p>
          </div>
          <div className="flex gap-3">
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={handleLogoUpload}
            />
            <Button onClick={handleSaveConfig} className="bg-gray-900 hover:bg-gray-800">
              <Save className="w-4 h-4 mr-2" />
              保存设置
            </Button>
          </div>
        </header>

        <Tabs defaultValue="shop" className="w-full">
          <TabsList className="bg-gray-100/50 p-1">
            <TabsTrigger value="shop" className="data-[state=active]:bg-white data-[state=active]:shadow-sm"><Store className="w-4 h-4 mr-2" />商城配置</TabsTrigger>
            <TabsTrigger value="payment" className="data-[state=active]:bg-white data-[state=active]:shadow-sm"><CreditCard className="w-4 h-4 mr-2" />支付配置</TabsTrigger>
            <TabsTrigger value="logistics" className="data-[state=active]:bg-white data-[state=active]:shadow-sm"><Truck className="w-4 h-4 mr-2" />物流配置</TabsTrigger>
            <TabsTrigger value="permission" className="data-[state=active]:bg-white data-[state=active]:shadow-sm"><Users className="w-4 h-4 mr-2" />权限管理</TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-white data-[state=active]:shadow-sm"><FileText className="w-4 h-4 mr-2" />操作日志</TabsTrigger>
          </TabsList>

          <TabsContent value="shop" className="space-y-6 mt-6">
            <Card className="border-gray-200">
              <CardHeader><CardTitle className="text-lg">基础信息</CardTitle></CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>商城名称</Label>
                    <Input value={shopConfig.name} onChange={(e) => setShopConfig({ ...shopConfig, name: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>客服电话</Label>
                    <Input value={shopConfig.phone} onChange={(e) => setShopConfig({ ...shopConfig, phone: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>客服邮箱</Label>
                    <Input value={shopConfig.email} onChange={(e) => setShopConfig({ ...shopConfig, email: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>ICP备案号</Label>
                    <Input value={shopConfig.icp} onChange={(e) => setShopConfig({ ...shopConfig, icp: e.target.value })} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Logo</Label>
                  <div className="flex items-center gap-4">
                    <div className="logo-preview relative w-20 h-20 rounded-xl bg-gray-100 flex items-center justify-center border border-dashed border-gray-300 overflow-hidden">
                      {shopConfig.logo ? (
                        <>
                          <img src={shopConfig.logo} alt="Logo" className="w-full h-full object-contain p-2" />
                          <div className="logo-overlay absolute inset-0 bg-black/50 opacity-0 flex items-center justify-center transition-opacity">
                            <button onClick={handleClearLogo} className="text-white p-1 hover:bg-white/20 rounded">
                              <X className="w-5 h-5" />
                            </button>
                          </div>
                        </>
                      ) : (
                        <Store className="w-8 h-8 text-gray-400" />
                      )}
                    </div>
                    <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                      <Upload className="w-4 h-4 mr-2" />
                      {shopConfig.logo ? '更换' : '上传'}
                    </Button>
                    {shopConfig.logo && (
                      <Button variant="ghost" size="sm" onClick={handleClearLogo} className="text-destructive">
                        删除
                      </Button>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>版权信息</Label>
                  <Input value={shopConfig.copyright} onChange={(e) => setShopConfig({ ...shopConfig, copyright: e.target.value })} />
                </div>
              </CardContent>
            </Card>

            <Card className="border-gray-200">
              <CardHeader><CardTitle className="text-lg">SEO设置</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>页面标题</Label>
                  <Input value={shopConfig.seoTitle} onChange={(e) => setShopConfig({ ...shopConfig, seoTitle: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>关键词</Label>
                  <Input value={shopConfig.seoKeywords} onChange={(e) => setShopConfig({ ...shopConfig, seoKeywords: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>描述</Label>
                  <Textarea rows={3} value={shopConfig.seoDescription} onChange={(e) => setShopConfig({ ...shopConfig, seoDescription: e.target.value })} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="payment" className="space-y-6 mt-6">
            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">微信支付</CardTitle>
                  <Switch checked={paymentConfig.wechatEnabled} onCheckedChange={(checked) => setPaymentConfig({ ...paymentConfig, wechatEnabled: checked })} />
                </div>
              </CardHeader>
              {paymentConfig.wechatEnabled && (
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>AppID</Label><Input value={paymentConfig.wechatAppId} onChange={(e) => setPaymentConfig({ ...paymentConfig, wechatAppId: e.target.value })} /></div>
                    <div className="space-y-2"><Label>商户号</Label><Input value={paymentConfig.wechatMchId} onChange={(e) => setPaymentConfig({ ...paymentConfig, wechatMchId: e.target.value })} /></div>
                  </div>
                  <div className="space-y-2"><Label>API密钥</Label><Input type="password" value={paymentConfig.wechatKey} onChange={(e) => setPaymentConfig({ ...paymentConfig, wechatKey: e.target.value })} /></div>
                </CardContent>
              )}
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">支付宝</CardTitle>
                  <Switch checked={paymentConfig.alipayEnabled} onCheckedChange={(checked) => setPaymentConfig({ ...paymentConfig, alipayEnabled: checked })} />
                </div>
              </CardHeader>
              {paymentConfig.alipayEnabled && (
                <CardContent className="space-y-4">
                  <div className="space-y-2"><Label>AppID</Label><Input value={paymentConfig.alipayAppId} onChange={(e) => setPaymentConfig({ ...paymentConfig, alipayAppId: e.target.value })} /></div>
                  <div className="space-y-2"><Label>公钥</Label><Textarea rows={3} value={paymentConfig.alipayPublicKey} onChange={(e) => setPaymentConfig({ ...paymentConfig, alipayPublicKey: e.target.value })} /></div>
                  <div className="space-y-2"><Label>私钥</Label><Textarea rows={3} value={paymentConfig.alipayPrivateKey} onChange={(e) => setPaymentConfig({ ...paymentConfig, alipayPrivateKey: e.target.value })} /></div>
                </CardContent>
              )}
            </Card>

            <Card className="border-gray-200">
              <CardHeader><CardTitle className="text-lg">沙箱模式</CardTitle></CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div><Label className="text-base">启用沙箱模式</Label><p className="text-sm text-gray-500">使用测试环境进行支付测试</p></div>
                  <Switch checked={paymentConfig.sandboxMode} onCheckedChange={(checked) => setPaymentConfig({ ...paymentConfig, sandboxMode: checked })} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logistics" className="space-y-6 mt-6">
            <Card className="border-gray-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">物流承运商</CardTitle>
                <Button variant="outline" onClick={() => setIsAddExpressOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />添加
                </Button>
              </CardHeader>
              <CardContent>
                <div className="rounded-lg border border-gray-200">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">物流公司</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">编码</th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">状态</th>
                        <th className="px-4 py-3 text-right text-sm font-medium text-gray-700">操作</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {expressCompanies.map((company) => (
                        <tr key={company.id}>
                          <td className="px-4 py-3 text-sm">{company.name}</td>
                          <td className="px-4 py-3 text-sm text-gray-500">{company.code}</td>
                          <td className="px-4 py-3">
                            <Badge 
                              variant={company.enabled ? 'default' : 'secondary'}
                              className="cursor-pointer"
                              onClick={() => toggleExpressStatus(company.id)}
                            >
                              {company.enabled ? '启用' : '停用'}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => toggleExpressStatus(company.id)}>
                                {company.enabled ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="text-destructive"
                                onClick={() => deleteExpress(company.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {expressCompanies.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    暂无物流承运商，点击"添加"按钮添加
                  </div>
                )}
              </CardContent>
            </Card>

            {/* 添加物流对话框 */}
            <Dialog open={isAddExpressOpen} onOpenChange={setIsAddExpressOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>添加物流承运商</DialogTitle>
                  <DialogDescription>添加新的物流公司</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>物流公司名称</Label>
                    <Input 
                      placeholder="如：顺丰速运" 
                      value={newExpress.name}
                      onChange={(e) => setNewExpress({ ...newExpress, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>编码</Label>
                    <Input 
                      placeholder="如：SF" 
                      value={newExpress.code}
                      onChange={(e) => setNewExpress({ ...newExpress, code: e.target.value })}
                    />
                    <p className="text-xs text-gray-500">用于物流查询接口，建议使用大写字母</p>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddExpressOpen(false)}>取消</Button>
                  <Button onClick={handleAddExpress} className="bg-gray-900">添加</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </TabsContent>

          <TabsContent value="permission" className="space-y-6 mt-6">
            <Card className="border-gray-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">团队成员</CardTitle>
                <Dialog open={isAddAdminOpen} onOpenChange={setIsAddAdminOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-gray-900 hover:bg-gray-800">
                      <Plus className="w-4 h-4 mr-2" />添加成员
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>添加团队成员</DialogTitle>
                      <DialogDescription>创建新的管理员账号</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label>姓名</Label>
                        <Input 
                          placeholder="请输入姓名" 
                          value={newAdmin.name}
                          onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>账号</Label>
                        <Input 
                          placeholder="请输入账号" 
                          value={newAdmin.account}
                          onChange={(e) => setNewAdmin({ ...newAdmin, account: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>密码</Label>
                        <Input 
                          type="password" 
                          placeholder="请输入密码" 
                          value={newAdmin.password}
                          onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>角色</Label>
                        <Select 
                          value={newAdmin.role}
                          onValueChange={(value) => setNewAdmin({ ...newAdmin, role: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="选择角色" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="super">超级管理员</SelectItem>
                            <SelectItem value="operator">运营人员</SelectItem>
                            <SelectItem value="support">客服人员</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsAddAdminOpen(false)}>取消</Button>
                      <Button onClick={handleAddAdmin} className="bg-gray-900">添加</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <Table columns={adminColumns} dataSource={admins} rowKey="id" scroll={{ x: true }} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6 mt-6">
            <Card className="border-gray-200">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg">操作记录</CardTitle>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input placeholder="搜索..." className="pl-10 w-56" />
                </div>
              </CardHeader>
              <CardContent>
                <Table columns={logColumns} dataSource={operationLogs} rowKey="id" scroll={{ x: true }} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
};

export default AdminSettings;
