import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowUpRight, ArrowDownRight, Package, Users, Clock, TrendingUp } from 'lucide-react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { cn } from '@/lib/utils';

// 数据概览
const statsData = [
  {
    title: '今日销售额',
    value: '¥28,456',
    change: '+12.5%',
    trend: 'up',
    description: '较昨日',
  },
  {
    title: '今日订单',
    value: '156',
    change: '+8.2%',
    trend: 'up',
    description: '较昨日',
  },
  {
    title: '访问用户',
    value: '1,234',
    change: '-3.1%',
    trend: 'down',
    description: '较昨日',
  },
  {
    title: '转化率',
    value: '3.2%',
    change: '+0.5%',
    trend: 'up',
    description: '较昨日',
  },
];

// 待处理
const pendingTasks = [
  { id: 1, title: '待发货订单', count: 23, icon: Package },
  { id: 2, title: '待处理退款', count: 5, icon: Clock },
  { id: 3, title: '新客户', count: 12, icon: Users },
];

// 销售趋势
const salesChartOption: EChartsOption = {
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'line' },
  },
  grid: {
    left: '0%',
    right: '0%',
    bottom: '0%',
    top: '10%',
    containLabel: true,
  },
  xAxis: {
    type: 'category',
    boundaryGap: false,
    data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel: { color: '#86868B' },
  },
  yAxis: {
    type: 'value',
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel: { color: '#86868B', formatter: (v: number) => `¥${v / 1000}k` },
    splitLine: { lineStyle: { color: '#F5F5F7' } },
  },
  series: [
    {
      name: '销售额',
      type: 'line',
      smooth: true,
      data: [28000, 32000, 28000, 38000, 42000, 35000, 28456],
      lineStyle: { color: '#000000', width: 2 },
      itemStyle: { color: '#000000' },
      areaStyle: {
        color: {
          type: 'linear',
          x: 0, y: 0, x2: 0, y2: 1,
          colorStops: [
            { offset: 0, color: 'rgba(0, 0, 0, 0.1)' },
            { offset: 1, color: 'rgba(0, 0, 0, 0)' },
          ],
        },
      },
    },
  ],
};

// 订单趋势
const orderChartOption: EChartsOption = {
  tooltip: {
    trigger: 'axis',
    axisPointer: { type: 'shadow' },
  },
  grid: {
    left: '0%',
    right: '0%',
    bottom: '0%',
    top: '10%',
    containLabel: true,
  },
  xAxis: {
    type: 'category',
    data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
    axisLine: { lineStyle: { color: '#F5F5F7' } },
    axisTick: { show: false },
    axisLabel: { color: '#86868B' },
  },
  yAxis: {
    type: 'value',
    axisLine: { show: false },
    axisTick: { show: false },
    axisLabel: { color: '#86868B' },
    splitLine: { lineStyle: { color: '#F5F5F7' } },
  },
  series: [
    {
      name: '订单数',
      type: 'bar',
      data: [120, 145, 130, 165, 180, 150, 156],
      itemStyle: { color: '#000000', borderRadius: [4, 4, 0, 0] },
      barWidth: '60%',
    },
  ],
};

interface IAdminDashboardProps {}

const AdminDashboard: React.FC<IAdminDashboardProps> = () => {
  const [timeRange, setTimeRange] = useState('today');

  return (
    <div className="w-full space-y-8">
      {/* 头部 */}
      <section className="w-full flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 tracking-tight">概览</h1>
          <p className="text-gray-500 mt-1">欢迎回来，查看今日数据</p>
        </div>
        <Tabs value={timeRange} onValueChange={setTimeRange}>
          <TabsList className="bg-gray-100">
            <TabsTrigger value="today" className="text-sm">今日</TabsTrigger>
            <TabsTrigger value="week" className="text-sm">本周</TabsTrigger>
            <TabsTrigger value="month" className="text-sm">本月</TabsTrigger>
          </TabsList>
        </Tabs>
      </section>

      {/* 数据卡片 */}
      <section className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statsData.map((stat) => (
          <Card key={stat.title} className="border-0 shadow-sm bg-white">
            <CardContent className="p-6">
              <p className="text-sm text-gray-500">{stat.title}</p>
              <p className="text-2xl font-semibold text-gray-900 mt-2">{stat.value}</p>
              <div className="flex items-center gap-1.5 mt-3">
                <span
                  className={cn(
                    'text-xs font-medium flex items-center gap-0.5',
                    stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  )}
                >
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="w-3 h-3" />
                  ) : (
                    <ArrowDownRight className="w-3 h-3" />
                  )}
                  {stat.change}
                </span>
                <span className="text-xs text-gray-400">{stat.description}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* 图表区域 */}
      <section className="w-full grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold text-gray-900">销售趋势</CardTitle>
          </CardHeader>
          <CardContent>
            <ReactECharts option={salesChartOption} style={{ height: '280px' }} />
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold text-gray-900">订单趋势</CardTitle>
          </CardHeader>
          <CardContent>
            <ReactECharts option={orderChartOption} style={{ height: '280px' }} />
          </CardContent>
        </Card>
      </section>

      {/* 待处理 + 快捷操作 */}
      <section className="w-full grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="border-0 shadow-sm lg:col-span-2">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold text-gray-900">待处理事项</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingTasks.map((task) => (
                <Link
                  key={task.id}
                  to="/admin/orders"
                  className="flex items-center justify-between p-4 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <task.icon className="w-5 h-5 text-gray-700" />
                    </div>
                    <span className="text-sm font-medium text-gray-900">{task.title}</span>
                  </div>
                  <span className="text-lg font-semibold text-gray-900">{task.count}</span>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold text-gray-900">快捷操作</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start h-11 border-gray-200" asChild>
                <Link to="/admin/products/new">发布新产品</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start h-11 border-gray-200" asChild>
                <Link to="/admin/orders">查看订单</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start h-11 border-gray-200" asChild>
                <Link to="/admin/marketing">优惠码</Link>
              </Button>
              <Button variant="outline" className="w-full justify-start h-11 border-gray-200" asChild>
                <Link to="/admin/settings">系统设置</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
};

export default AdminDashboard;
