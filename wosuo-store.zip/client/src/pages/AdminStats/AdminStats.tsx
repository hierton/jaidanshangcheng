import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { TrendingUp, TrendingDown, Users, ShoppingCart, DollarSign, Package, Download, Calendar, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Table } from '@lark-apaas/client-toolkit/antd-table';

// 销售趋势数据
const salesTrendData = [
  { date: '03-01', sales: 12500, orders: 45 },
  { date: '03-02', sales: 15800, orders: 52 },
  { date: '03-03', sales: 13200, orders: 48 },
  { date: '03-04', sales: 18900, orders: 67 },
  { date: '03-05', sales: 22100, orders: 78 },
  { date: '03-06', sales: 19800, orders: 69 },
  { date: '03-07', sales: 24500, orders: 85 },
  { date: '03-08', sales: 21200, orders: 74 },
  { date: '03-09', sales: 26800, orders: 92 },
  { date: '03-10', sales: 28900, orders: 98 },
  { date: '03-11', sales: 25600, orders: 87 },
  { date: '03-12', sales: 31200, orders: 105 },
  { date: '03-13', sales: 29800, orders: 101 },
  { date: '03-14', sales: 33400, orders: 112 },
];

// 热销商品排行
const topProducts = [
  { id: 1, name: 'MacBook Pro 14"', sales: 289, revenue: 4331000, trend: 'up' },
  { id: 2, name: 'iPhone 15 Pro', sales: 456, revenue: 3643000, trend: 'up' },
  { id: 3, name: 'AirPods Pro', sales: 892, revenue: 1693000, trend: 'up' },
  { id: 4, name: 'iPad Air', sales: 234, revenue: 1123000, trend: 'flat' },
  { id: 5, name: 'Apple Watch Ultra', sales: 178, revenue: 1119000, trend: 'down' },
  { id: 6, name: 'Studio Display', sales: 67, revenue: 770300, trend: 'up' },
  { id: 7, name: 'Magic Keyboard', sales: 345, revenue: 827000, trend: 'up' },
  { id: 8, name: 'Magic Mouse', sales: 432, revenue: 301000, trend: 'flat' },
];

// 滞销商品
const slowProducts = [
  { id: 101, name: 'Lightning 转 USB 线', stock: 500, sales30d: 3 },
  { id: 102, name: 'MagSafe 外接电池', stock: 200, sales30d: 5 },
  { id: 103, name: 'AirTag 皮革钥匙扣', stock: 300, sales30d: 8 },
  { id: 104, name: 'iPhone 14 手机壳', stock: 450, sales30d: 12 },
];

// 分类销售占比
const categorySales = [
  { name: 'Mac', value: 42.5, sales: 2580000 },
  { name: 'iPhone', value: 28.3, sales: 1718000 },
  { name: 'iPad', value: 15.2, sales: 923000 },
  { name: 'Watch', value: 8.7, sales: 528000 },
  { name: '音频', value: 3.8, sales: 231000 },
  { name: '配件', value: 1.5, sales: 91000 },
];

// 用户分析数据
const userStats = {
  totalUsers: 45680,
  newUsersToday: 128,
  newUsersWeek: 892,
  newUsersMonth: 3456,
  activeUsers: 12340,
  retention: {
    day1: 45.2,
    day7: 28.6,
    day30: 18.3,
  },
};

interface IAdminStatsProps {}

const AdminStats: React.FC<IAdminStatsProps> = () => {
  const [period, setPeriod] = useState('7d');

  // 销售概览统计数据
  const salesOverview = [
    { label: '今日销售额', value: '¥33,400', change: '+12.5%', trend: 'up', icon: DollarSign },
    { label: '今日订单数', value: '112', change: '+8.3%', trend: 'up', icon: ShoppingCart },
    { label: '客单价', value: '¥298', change: '-2.1%', trend: 'down', icon: Package },
    { label: '转化率', value: '3.2%', change: '+0.5%', trend: 'up', icon: TrendingUp },
  ];

  // 热销商品表格列
  const topProductsColumns = [
    {
      title: '排名',
      dataIndex: 'id',
      key: 'rank',
      width: 70,
      render: (_: unknown, __: unknown, index: number) => (
        <span className={`text-sm font-medium ${index < 3 ? 'text-gray-900' : 'text-gray-400'}`}>
          {index + 1}
        </span>
      ),
    },
    {
      title: '商品名称',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: '销量',
      dataIndex: 'sales',
      key: 'sales',
      width: 100,
      render: (value: number) => value.toLocaleString(),
    },
    {
      title: '销售额',
      dataIndex: 'revenue',
      key: 'revenue',
      width: 140,
      render: (value: number) => `¥${(value / 10000).toFixed(1)}万`,
    },
    {
      title: '趋势',
      dataIndex: 'trend',
      key: 'trend',
      width: 80,
      render: (trend: string) => {
        if (trend === 'up') return <ArrowUpRight className="w-4 h-4 text-green-600" />;
        if (trend === 'down') return <ArrowDownRight className="w-4 h-4 text-red-500" />;
        return <span className="text-gray-300">—</span>;
      },
    },
  ];

  // 滞销商品表格列
  const slowProductsColumns = [
    {
      title: '商品名称',
      dataIndex: 'name',
      key: 'name',
      ellipsis: true,
    },
    {
      title: '库存',
      dataIndex: 'stock',
      key: 'stock',
      width: 100,
    },
    {
      title: '30天销量',
      dataIndex: 'sales30d',
      key: 'sales30d',
      width: 110,
      render: (value: number) => (
        <span className={`text-sm ${value < 5 ? 'text-red-500' : 'text-gray-600'}`}>
          {value}
        </span>
      ),
    },
  ];

  return (
    <>
      <style jsx>{`
        .stats-grid {
          display: grid;
          gap: 1.5rem;
        }
        @media (min-width: 640px) {
          .stats-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }
        @media (min-width: 1024px) {
          .stats-grid {
            grid-template-columns: repeat(4, 1fr);
          }
        }
        .chart-bar {
          transition: opacity 0.2s ease;
        }
        .chart-bar:hover {
          opacity: 0.8;
        }
      `}</style>

      <div className="w-full space-y-8">
        {/* 页面标题 */}
        <section className="w-full flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold text-gray-900 tracking-tight">数据统计</h1>
            <p className="text-gray-500 mt-1">全面了解商城运营数据</p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-32 h-10 bg-white border-gray-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">今日</SelectItem>
                <SelectItem value="7d">近7天</SelectItem>
                <SelectItem value="30d">近30天</SelectItem>
                <SelectItem value="90d">近90天</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="h-10 border-gray-200">
              <Download className="w-4 h-4 mr-2" />
              导出
            </Button>
          </div>
        </section>

        {/* 销售概览卡片 */}
        <section className="w-full stats-grid">
          {salesOverview.map((item, index) => (
            <Card key={index} className="border-gray-100 shadow-sm">
              <CardContent className="p-6">
                <p className="text-sm text-gray-500">{item.label}</p>
                <p className="text-3xl font-semibold text-gray-900 mt-2">{item.value}</p>
                <div className="flex items-center gap-2 mt-3">
                  {item.trend === 'up' ? (
                    <ArrowUpRight className="w-4 h-4 text-green-600" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-red-500" />
                  )}
                  <span className={`text-sm font-medium ${item.trend === 'up' ? 'text-green-600' : 'text-red-500'}`}>
                    {item.change}
                  </span>
                  <span className="text-sm text-gray-400">环比</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        {/* 主内容区 Tabs */}
        <section className="w-full">
          <Tabs defaultValue="sales" className="w-full">
            <TabsList className="bg-gray-100 p-1 h-11">
              <TabsTrigger value="sales" className="px-6">销售分析</TabsTrigger>
              <TabsTrigger value="products" className="px-6">商品分析</TabsTrigger>
              <TabsTrigger value="users" className="px-6">用户分析</TabsTrigger>
            </TabsList>

            {/* 销售分析 Tab */}
            <TabsContent value="sales" className="space-y-6 mt-8">
              {/* 销售趋势图 */}
              <Card className="border-gray-100 shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium text-gray-900">销售额趋势</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-56 flex items-end gap-1">
                    {salesTrendData.map((item, index) => {
                      const maxSales = Math.max(...salesTrendData.map(d => d.sales));
                      const height = (item.sales / maxSales) * 100;
                      return (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2 group">
                          <div className="relative w-full flex-1 flex items-end">
                            <div
                              className="chart-bar w-full bg-gray-900 rounded-t-sm"
                              style={{ height: `${height}%`, minHeight: '4px' }}
                            />
                          </div>
                          <span className="text-xs text-gray-400">{item.date}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* 分类销售占比 */}
              <Card className="border-gray-100 shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium text-gray-900">分类销售占比</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                    {/* 环形图 */}
                    <div className="flex items-center justify-center">
                      <div className="relative w-40 h-40">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          {categorySales.reduce((acc, item, index) => {
                            const prevOffset = index === 0 ? 0 : acc.offset;
                            const dashArray = `${item.value} ${100 - item.value}`;
                            const colors = ['#111827', '#374151', '#6B7280', '#9CA3AF', '#D1D5DB', '#E5E7EB'];
                            acc.elements.push(
                              <circle
                                key={index}
                                cx="50"
                                cy="50"
                                r="40"
                                fill="none"
                                stroke={colors[index]}
                                strokeWidth="12"
                                strokeDasharray={dashArray}
                                strokeDashoffset={-prevOffset}
                              />
                            );
                            acc.offset = prevOffset + item.value;
                            return acc;
                          }, { elements: [] as React.ReactNode[], offset: 0 }).elements}
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="text-center">
                            <p className="text-2xl font-semibold text-gray-900">¥607万</p>
                            <p className="text-xs text-gray-400">总销售额</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* 图例 */}
                    <div className="space-y-4">
                      {categorySales.map((item, index) => {
                        const colors = ['bg-gray-900', 'bg-gray-700', 'bg-gray-500', 'bg-gray-400', 'bg-gray-300', 'bg-gray-200'];
                        return (
                          <div key={index} className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className={`w-2.5 h-2.5 rounded-full ${colors[index]}`} />
                              <span className="text-sm text-gray-700">{item.name}</span>
                            </div>
                            <div className="flex items-center gap-6">
                              <span className="text-sm font-medium text-gray-900">{item.value}%</span>
                              <span className="text-sm text-gray-400 w-20 text-right">
                                ¥{(item.sales / 10000).toFixed(0)}万
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 商品分析 Tab */}
            <TabsContent value="products" className="space-y-6 mt-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* 热销商品排行 */}
                <Card className="border-gray-100 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-medium text-gray-900 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      热销商品 TOP8
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table
                      columns={topProductsColumns}
                      dataSource={topProducts}
                      rowKey="id"
                      pagination={false}
                    />
                  </CardContent>
                </Card>

                {/* 滞销商品 */}
                <Card className="border-gray-100 shadow-sm">
                  <CardHeader className="pb-4">
                    <CardTitle className="text-lg font-medium text-gray-900 flex items-center gap-2">
                      <TrendingDown className="w-5 h-5 text-red-500" />
                      滞销商品预警
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Table
                      columns={slowProductsColumns}
                      dataSource={slowProducts}
                      rowKey="id"
                      pagination={false}
                    />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* 用户分析 Tab */}
            <TabsContent value="users" className="space-y-6 mt-8">
              {/* 用户统计卡片 */}
              <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card className="border-gray-100 shadow-sm">
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-500">总用户数</p>
                    <p className="text-3xl font-semibold text-gray-900 mt-2">{userStats.totalUsers.toLocaleString()}</p>
                  </CardContent>
                </Card>
                <Card className="border-gray-100 shadow-sm">
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-500">今日新增</p>
                    <p className="text-3xl font-semibold text-gray-900 mt-2">+{userStats.newUsersToday}</p>
                  </CardContent>
                </Card>
                <Card className="border-gray-100 shadow-sm">
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-500">活跃用户</p>
                    <p className="text-3xl font-semibold text-gray-900 mt-2">{userStats.activeUsers.toLocaleString()}</p>
                  </CardContent>
                </Card>
                <Card className="border-gray-100 shadow-sm">
                  <CardContent className="p-6">
                    <p className="text-sm text-gray-500">本月新增</p>
                    <p className="text-3xl font-semibold text-gray-900 mt-2">+{userStats.newUsersMonth}</p>
                  </CardContent>
                </Card>
              </div>

              {/* 留存率 */}
              <Card className="border-gray-100 shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-medium text-gray-900">用户留存率</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto">
                    <div className="text-center">
                      <div className="relative w-28 h-28 mx-auto">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          <circle cx="50" cy="50" r="42" fill="none" stroke="#F3F4F6" strokeWidth="8" />
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            fill="none"
                            stroke="#111827"
                            strokeWidth="8"
                            strokeDasharray={`${userStats.retention.day1 * 2.64} 264`}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-xl font-semibold text-gray-900">{userStats.retention.day1}%</span>
                        </div>
                      </div>
                      <p className="mt-3 text-sm text-gray-500">次日留存</p>
                    </div>
                    <div className="text-center">
                      <div className="relative w-28 h-28 mx-auto">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          <circle cx="50" cy="50" r="42" fill="none" stroke="#F3F4F6" strokeWidth="8" />
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            fill="none"
                            stroke="#374151"
                            strokeWidth="8"
                            strokeDasharray={`${userStats.retention.day7 * 2.64} 264`}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-xl font-semibold text-gray-900">{userStats.retention.day7}%</span>
                        </div>
                      </div>
                      <p className="mt-3 text-sm text-gray-500">7日留存</p>
                    </div>
                    <div className="text-center">
                      <div className="relative w-28 h-28 mx-auto">
                        <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                          <circle cx="50" cy="50" r="42" fill="none" stroke="#F3F4F6" strokeWidth="8" />
                          <circle
                            cx="50"
                            cy="50"
                            r="42"
                            fill="none"
                            stroke="#6B7280"
                            strokeWidth="8"
                            strokeDasharray={`${userStats.retention.day30 * 2.64} 264`}
                            strokeLinecap="round"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-xl font-semibold text-gray-900">{userStats.retention.day30}%</span>
                        </div>
                      </div>
                      <p className="mt-3 text-sm text-gray-500">30日留存</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </div>
    </>
  );
};

export default AdminStats;
