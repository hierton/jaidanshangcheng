import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { ChevronLeft, Plus, Check, MapPin, Truck, CreditCard, Tag } from 'lucide-react';

interface IAddress {
  id: string;
  name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  isDefault: boolean;
}

interface ICartItem {
  id: string;
  productId: string;
  skuId: string;
  name: string;
  image: string;
  specs: Record<string, string>;
  price: number;
  quantity: number;
}

interface IDiscountCode {
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  maxDiscount?: number;
  minOrder: number;
}

const mockAddresses: IAddress[] = [
  {
    id: '1',
    name: '张三',
    phone: '138****8888',
    province: '北京市',
    city: '北京市',
    district: '朝阳区',
    detail: '建国路88号SOHO现代城A座1201室',
    isDefault: true,
  },
  {
    id: '2',
    name: '张三',
    phone: '139****9999',
    province: '上海市',
    city: '上海市',
    district: '浦东新区',
    detail: '陆家嘴环路1000号恒生银行大厦',
    isDefault: false,
  },
];

const mockCartItems: ICartItem[] = [
  {
    id: '1',
    productId: 'p1',
    skuId: 's1',
    name: 'MacBook Pro 14英寸',
    image: 'https://picsum.photos/seed/macbook/200/200',
    specs: { color: '深空灰', chip: 'M3 Pro' },
    price: 16999,
    quantity: 1,
  },
  {
    id: '2',
    productId: 'p2',
    skuId: 's2',
    name: 'AirPods Pro',
    image: 'https://picsum.photos/seed/airpods/200/200',
    specs: { color: '白色' },
    price: 1899,
    quantity: 1,
  },
];

const shippingMethods = [
  { id: 'express', name: '快递配送', price: 0, time: '预计 2-3 个工作日' },
  { id: 'same-day', name: '当日达', price: 50, time: '今日送达' },
];

const paymentMethods = [
  { id: 'card', name: '银行卡', desc: '支持主流银行卡' },
  { id: 'alipay', name: '支付宝', desc: '快捷支付' },
];

const validDiscountCodes: Record<string, IDiscountCode> = {
  'SAVE100': { code: 'SAVE100', type: 'fixed', value: 100, minOrder: 1000 },
};

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const [addresses, setAddresses] = useState<IAddress[]>(mockAddresses);
  const [selectedAddressId, setSelectedAddressId] = useState<string>('1');
  const [selectedShipping, setSelectedShipping] = useState<string>('express');
  const [selectedPayment, setSelectedPayment] = useState<string>('card');
  const [discountCode, setDiscountCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<IDiscountCode | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [showAddressDialog, setShowAddressDialog] = useState(false);
  const [needInvoice, setNeedInvoice] = useState(false);
  const [remark, setRemark] = useState('');

  const goodsTotal = mockCartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shippingFee = shippingMethods.find(m => m.id === selectedShipping)?.price || 0;
  
  const discountAmount = React.useMemo(() => {
    if (!appliedDiscount) return 0;
    if (goodsTotal < appliedDiscount.minOrder) return 0;
    if (appliedDiscount.type === 'fixed') return appliedDiscount.value;
    return Math.min(goodsTotal * appliedDiscount.value, appliedDiscount.maxDiscount || Infinity);
  }, [appliedDiscount, goodsTotal]);

  const finalTotal = goodsTotal + shippingFee - discountAmount;

  const verifyDiscountCode = () => {
    if (!discountCode.trim()) {
      toast.error('请输入优惠码');
      return;
    }
    setIsVerifying(true);
    setTimeout(() => {
      const code = discountCode.toUpperCase().trim();
      const discount = validDiscountCodes[code];
      if (discount && goodsTotal >= discount.minOrder) {
        setAppliedDiscount(discount);
        toast.success('优惠码已应用');
      } else {
        toast.error('优惠码无效');
        setAppliedDiscount(null);
      }
      setIsVerifying(false);
    }, 400);
  };

  const handleSubmitOrder = () => {
    if (!selectedAddressId) {
      toast.error('请选择收货地址');
      return;
    }
    toast.success('订单已提交');
    navigate('/orders');
  };

  const selectedAddress = addresses.find(a => a.id === selectedAddressId);

  return (
    <>
      <style jsx>{`
        .checkout-page {
          animation: fadeIn 0.4s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .section-card {
          background: white;
          border-radius: 1rem;
          border: 1px solid hsl(0 0% 92%);
        }
        .section-card:hover {
          border-color: hsl(0 0% 85%);
        }
        .option-item {
          transition: all 0.2s ease;
        }
        .option-item.selected {
          border-color: hsl(0 0% 11%);
          background: hsl(0 0% 98%);
        }
      `}</style>

      <div className="checkout-page w-full max-w-4xl mx-auto px-6 py-12">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-900 mb-8 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          返回
        </button>

        <h1 className="text-3xl font-semibold text-gray-900 mb-2">结账</h1>
        <p className="text-gray-500 mb-12">请确认您的订单信息</p>

        <div className="space-y-6">
          <section className="w-full section-card p-6">
            <div className="flex items-center gap-3 mb-6">
              <MapPin className="w-5 h-5 text-gray-400" strokeWidth={1.5} />
              <h2 className="text-lg font-medium text-gray-900">配送地址</h2>
            </div>
            
            {selectedAddress ? (
              <div 
                onClick={() => setShowAddressDialog(true)}
                className="option-item selected p-4 rounded-xl border cursor-pointer"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="font-medium text-gray-900">{selectedAddress.name}</span>
                      <span className="text-gray-500">{selectedAddress.phone}</span>
                      {selectedAddress.isDefault && (
                        <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">默认</span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500">
                      {selectedAddress.province} {selectedAddress.city} {selectedAddress.district} {selectedAddress.detail}
                    </p>
                  </div>
                  <Check className="w-5 h-5 text-gray-900" />
                </div>
              </div>
            ) : (
              <button 
                onClick={() => setShowAddressDialog(true)}
                className="w-full p-6 border border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-gray-400 transition-colors"
              >
                <Plus className="w-5 h-5 mx-auto mb-2" />
                添加配送地址
              </button>
            )}
          </section>

          <section className="w-full section-card p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-6">商品清单</h2>
            <div className="space-y-4">
              {mockCartItems.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-20 h-20 object-cover rounded-lg bg-gray-100"
                  />
                  <div className="flex-1 flex flex-col justify-between py-1">
                    <div>
                      <h3 className="font-medium text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-500 mt-0.5">
                        {Object.entries(item.specs).map(([k, v]) => v).join(' · ')}
                      </p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-900">¥{item.price.toLocaleString()}</span>
                      <span className="text-sm text-gray-500">数量 {item.quantity}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="w-full section-card p-6">
            <div className="flex items-center gap-3 mb-6">
              <Truck className="w-5 h-5 text-gray-400" strokeWidth={1.5} />
              <h2 className="text-lg font-medium text-gray-900">配送方式</h2>
            </div>
            
            <RadioGroup value={selectedShipping} onValueChange={setSelectedShipping} className="space-y-3">
              {shippingMethods.map((method) => (
                <label
                  key={method.id}
                  className={`option-item flex items-center justify-between p-4 border rounded-xl cursor-pointer ${
                    selectedShipping === method.id ? 'selected' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                    <div>
                      <div className="font-medium text-gray-900">{method.name}</div>
                      <div className="text-sm text-gray-500">{method.time}</div>
                    </div>
                  </div>
                  <span className="font-medium text-gray-900">
                    {method.price === 0 ? '免费' : `¥${method.price}`}
                  </span>
                </label>
              ))}
            </RadioGroup>
          </section>

          <section className="w-full section-card p-6">
            <div className="flex items-center gap-3 mb-6">
              <CreditCard className="w-5 h-5 text-gray-400" strokeWidth={1.5} />
              <h2 className="text-lg font-medium text-gray-900">支付方式</h2>
            </div>
            
            <RadioGroup value={selectedPayment} onValueChange={setSelectedPayment} className="space-y-3">
              {paymentMethods.map((method) => (
                <label
                  key={method.id}
                  className={`option-item flex items-center justify-between p-4 border rounded-xl cursor-pointer ${
                    selectedPayment === method.id ? 'selected' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value={method.id} id={method.id} className="sr-only" />
                    <div>
                      <div className="font-medium text-gray-900">{method.name}</div>
                      <div className="text-sm text-gray-500">{method.desc}</div>
                    </div>
                  </div>
                  {selectedPayment === method.id && <Check className="w-5 h-5 text-gray-900" />}
                </label>
              ))}
            </RadioGroup>
          </section>

          <section className="w-full section-card p-6">
            <div className="flex items-center gap-3 mb-6">
              <Tag className="w-5 h-5 text-gray-400" strokeWidth={1.5} />
              <h2 className="text-lg font-medium text-gray-900">优惠码</h2>
            </div>
            
            {appliedDiscount ? (
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div>
                  <span className="font-medium text-gray-900">{appliedDiscount.code}</span>
                  <span className="text-sm text-gray-500 ml-2">已优惠 ¥{discountAmount}</span>
                </div>
                <button 
                  onClick={() => { setAppliedDiscount(null); setDiscountCode(''); }}
                  className="text-sm text-gray-500 hover:text-gray-900"
                >
                  移除
                </button>
              </div>
            ) : (
              <div className="flex gap-3">
                <Input
                  placeholder="输入优惠码"
                  value={discountCode}
                  onChange={(e) => setDiscountCode(e.target.value)}
                  className="flex-1 h-11 border-gray-200 focus:border-gray-400"
                />
                <Button 
                  onClick={verifyDiscountCode} 
                  disabled={isVerifying}
                  variant="secondary"
                  className="h-11 px-6"
                >
                  应用
                </Button>
              </div>
            )}
          </section>

          <section className="w-full section-card p-6">
            <div className="flex items-center gap-3 mb-6">
              <input
                type="checkbox"
                id="invoice"
                checked={needInvoice}
                onChange={(e) => setNeedInvoice(e.target.checked)}
                className="w-4 h-4 rounded border-gray-300"
              />
              <label htmlFor="invoice" className="text-lg font-medium text-gray-900 cursor-pointer">
                需要发票
              </label>
            </div>
            
            {needInvoice && (
              <div className="space-y-4 pt-4 border-t border-gray-100">
                <div>
                  <Label className="text-sm text-gray-600">发票抬头</Label>
                  <Input placeholder="个人或公司名称" className="mt-2 h-11 border-gray-200" />
                </div>
              </div>
            )}
          </section>

          <section className="w-full section-card p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">订单备注</h2>
            <Textarea
              placeholder="添加备注（选填）"
              value={remark}
              onChange={(e) => setRemark(e.target.value.slice(0, 100))}
              className="resize-none border-gray-200 focus:border-gray-400"
              rows={3}
            />
          </section>

          <section className="w-full section-card p-6 bg-gray-50">
            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>小计</span>
                <span>¥{goodsTotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>运费</span>
                <span>{shippingFee === 0 ? '免费' : `¥${shippingFee}`}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>优惠</span>
                  <span>-¥{discountAmount}</span>
                </div>
              )}
              <Separator className="my-4 bg-gray-200" />
              <div className="flex justify-between items-center">
                <span className="text-lg font-medium text-gray-900">总计</span>
                <span className="text-2xl font-semibold text-gray-900">¥{finalTotal.toLocaleString()}</span>
              </div>
            </div>
            
            <Button
              onClick={handleSubmitOrder}
              className="w-full h-14 text-base font-medium bg-gray-900 hover:bg-gray-800 rounded-xl"
            >
              确认订单
            </Button>
          </section>
        </div>

        <Dialog open={showAddressDialog} onOpenChange={setShowAddressDialog}>
          <DialogContent className="max-w-md p-0 gap-0">
            <DialogHeader className="p-6 pb-4">
              <DialogTitle className="text-lg font-medium">选择地址</DialogTitle>
            </DialogHeader>
            <div className="px-6 pb-6 space-y-3 max-h-80 overflow-y-auto">
              {addresses.map((address) => (
                <div
                  key={address.id}
                  onClick={() => { setSelectedAddressId(address.id); setShowAddressDialog(false); }}
                  className={`p-4 border rounded-xl cursor-pointer transition-all ${
                    selectedAddressId === address.id 
                      ? 'border-gray-900 bg-gray-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-1">
                    <span className="font-medium text-gray-900">{address.name}</span>
                    <span className="text-sm text-gray-500">{address.phone}</span>
                    {address.isDefault && (
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">默认</span>
                    )}
                  </div>
                  <p className="text-sm text-gray-500">
                    {address.province} {address.city} {address.district} {address.detail}
                  </p>
                </div>
              ))}
              <button className="w-full py-4 border border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-gray-400 transition-colors flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" />
                添加新地址
              </button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default CheckoutPage;
