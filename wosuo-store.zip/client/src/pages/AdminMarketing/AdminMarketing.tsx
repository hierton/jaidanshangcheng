import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Table } from '@lark-apaas/client-toolkit/antd-table';
import { Plus, Search, Edit, Trash2, BarChart3, Copy, Tag } from 'lucide-react';
import { toast } from 'sonner';

interface IDiscountCode {
  id: string;
  name: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  maxDiscount?: number;
  minOrder: number;
  totalQuantity: number | null;
  usedQuantity: number;
  perUserLimit: number;
  startTime: string;
  endTime: string;
  scope: 'all' | 'specific';
  status: 'active' | 'inactive';
  createdAt: string;
}

const mockDiscountCodes: IDiscountCode[] = [
  {
    id: '1',
    name: '新品首发优惠',
    code: 'NEW2026',
    type: 'percentage',
    value: 15,
    minOrder: 0,
    totalQuantity: 500,
    usedQuantity: 128,
    perUserLimit: 1,
    startTime: '2026-03-01 00:00:00',
    endTime: '2026-03-31 23:59:59',
    scope: 'all',
    status: 'active',
    createdAt: '2026-02-28 10:00:00',
  },
  {
    id: '2',
    name: '满1000减100',
    code: 'SAVE100',
    type: 'fixed',
    value: 100,
    minOrder: 1000,
    totalQuantity: null,
    usedQuantity: 456,
    perUserLimit: 2,
    startTime: '2026-01-01 00:00:00',
    endTime: '2026-12-31 23:59:59',
    scope: 'all',
    status: 'active',
    createdAt: '2026-01-01 09:00:00',
  },
  {
    id: '3',
    name: '会员专享8折',
    code: 'VIP20',
    type: 'percentage',
    value: 20,
    maxDiscount: 500,
    minOrder: 500,
    totalQuantity: 200,
    usedQuantity: 200,
    perUserLimit: 1,
    startTime: '2026-02-01 00:00:00',
    endTime: '2026-02-28 23:59:59',
    scope: 'specific',
    status: 'inactive',
    createdAt: '2026-01-25 14:30:00',
  },
];

const AdminMarketing: React.FC = () => {
  const [discountCodes, setDiscountCodes] = useState<IDiscountCode[]>(mockDiscountCodes);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedCode, setSelectedCode] = useState<IDiscountCode | null>(null);
  const [isStatsDialogOpen, setIsStatsDialogOpen] = useState(false);

  const [formData, setFormData] = useState<Partial<IDiscountCode>>({
    name: '',
    code: '',
    type: 'percentage',
    value: 0,
    minOrder: 0,
    totalQuantity: null,
    perUserLimit: 1,
    startTime: '',
    endTime: '',
    scope: 'all',
    status: 'active',
  });

  const filteredData = discountCodes.filter((item) => {
    const matchKeyword =
      !searchKeyword ||
      item.name.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      item.code.toLowerCase().includes(searchKeyword.toLowerCase());
    const matchStatus = statusFilter === 'all' || item.status === statusFilter;
    return matchKeyword && matchStatus;
  });

  const stats = {
    total: discountCodes.length,
    active: discountCodes.filter((i) => i.status === 'active').length,
    totalUsed: discountCodes.reduce((sum, i) => sum + i.usedQuantity, 0),
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData((prev) => ({ ...prev, code }));
  };

  const handleSave = () => {
    if (!formData.name || !formData.code || !formData.startTime || !formData.endTime) {
      toast.error('请填写完整信息');
      return;
    }

    if (selectedCode) {
      setDiscountCodes((prev) =>
        prev.map((item) => (item.id === selectedCode.id ? { ...item, ...formData } as IDiscountCode : item))
      );
      toast.success('优惠码已更新');
    } else {
      const newCode: IDiscountCode = {
        ...formData as IDiscountCode,
        id: Date.now().toString(),
        usedQuantity: 0,
        createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
      };
      setDiscountCodes((prev) => [newCode, ...prev]);
      toast.success('优惠码已创建');
    }

    setIsCreateDialogOpen(false);
    setSelectedCode(null);
    resetForm();
  };

  const handleDelete = (id: string) => {
    setDiscountCodes((prev) => prev.filter((item) => item.id !== id));
    toast.success('优惠码已删除');
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success('已复制到剪贴板');
  };

  const openEditDialog = (code: IDiscountCode) => {
    setSelectedCode(code);
    setFormData(code);
    setIsCreateDialogOpen(true);
  };

  const openStatsDialog = (code: IDiscountCode) => {
    setSelectedCode(code);
    setIsStatsDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      code: '',
      type: 'percentage',
      value: 0,
      minOrder: 0,
      totalQuantity: null,
      perUserLimit: 1,
      startTime: '',
      endTime: '',
      scope: 'all',
      status: 'active',
    });
  };

  const columns = [
    {
      title: '优惠码',
      dataIndex: 'name',
      key: 'name',
      render: (text: string, record: IDiscountCode) => (
        <div>
          <div className="font-medium text-gray-900">{text}</div>
          <div className="text-sm text-gray-500">{record.code}</div>
        </div>
      ),
    },
    {
      title: '折扣',
      dataIndex: 'type',
      key: 'type',
      render: (type: string, record: IDiscountCode) => (
        <div className="font-medium">
          {type === 'percentage' ? `${record.value}% OFF` : `¥${record.value} OFF`}
        </div>
      ),
    },
    {
      title: '使用进度',
      dataIndex: 'usedQuantity',
      key: 'usedQuantity',
      render: (used: number, record: IDiscountCode) => {
        const total = record.totalQuantity;
        const percent = total ? Math.round((used / total) * 100) : 0;
        return (
          <div className="w-28">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
              <span>{used}</span>
              <span>{total || '∞'}</span>
            </div>
            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-gray-900" style={{ width: `${Math.min(percent, 100)}%` }} />
            </div>
          </div>
        );
      },
    },
    {
      title: '有效期',
      dataIndex: 'startTime',
      key: 'time',
      render: (_: string, record: IDiscountCode) => (
        <div className="text-sm text-gray-600">
          {record.startTime.split(' ')[0]} ~ {record.endTime.split(' ')[0]}
        </div>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) =>
        status === 'active' ? (
          <Badge className="bg-gray-900 text-white hover:bg-gray-800">启用</Badge>
        ) : (
          <Badge variant="secondary">禁用</Badge>
        ),
    },
    {
      title: '',
      key: 'action',
      fixed: 'right' as const,
      width: 120,
      render: (_: unknown, record: IDiscountCode) => (
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => copyCode(record.code)}>
            <Copy className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openStatsDialog(record)}>
            <BarChart3 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(record)}>
            <Edit className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => handleDelete(record.id)}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <style jsx>{`
        .marketing-page {
          animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      <div className="marketing-page w-full max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">营销中心</h1>
            <p className="text-sm text-gray-500 mt-1">创建和管理优惠码活动</p>
          </div>
          <Button onClick={() => { setSelectedCode(null); resetForm(); setIsCreateDialogOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" />
            新建优惠码
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-5">
              <div className="text-sm text-gray-500">优惠码总数</div>
              <div className="text-3xl font-semibold text-gray-900 mt-2">{stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-sm text-gray-500">启用中</div>
              <div className="text-3xl font-semibold text-gray-900 mt-2">{stats.active}</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5">
              <div className="text-sm text-gray-500">累计使用次数</div>
              <div className="text-3xl font-semibold text-gray-900 mt-2">{stats.totalUsed.toLocaleString()}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="搜索优惠码"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="active">启用</SelectItem>
                  <SelectItem value="inactive">禁用</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-medium">优惠码列表</CardTitle>
          </CardHeader>
          <CardContent>
            <Table
              columns={columns}
              dataSource={filteredData}
              rowKey="id"
              scroll={{ x: 800 }}
              pagination={{ pageSize: 10, showSizeChanger: false }}
            />
          </CardContent>
        </Card>

        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">{selectedCode ? '编辑优惠码' : '新建优惠码'}</DialogTitle>
            </DialogHeader>
            <div className="space-y-5 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm">名称</Label>
                  <Input
                    placeholder="如：新品首发优惠"
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">代码</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="如：NEW2026"
                      value={formData.code}
                      onChange={(e) => setFormData((prev) => ({ ...prev, code: e.target.value.toUpperCase() }))}
                      className="flex-1"
                    />
                    <Button variant="outline" onClick={generateRandomCode} className="shrink-0">随机</Button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm">折扣类型</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => setFormData((prev) => ({ ...prev, type: value as 'percentage' | 'fixed' }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">百分比折扣</SelectItem>
                      <SelectItem value="fixed">固定金额减免</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">折扣值</Label>
                  <Input
                    type="number"
                    placeholder={formData.type === 'percentage' ? '如：20（8折）' : '如：50（元）'}
                    value={formData.value || ''}
                    onChange={(e) => setFormData((prev) => ({ ...prev, value: Number(e.target.value) }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm">使用门槛（元）</Label>
                  <Input
                    type="number"
                    placeholder="0表示无门槛"
                    value={formData.minOrder || ''}
                    onChange={(e) => setFormData((prev) => ({ ...prev, minOrder: Number(e.target.value) }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">总发放数量</Label>
                  <Input
                    type="number"
                    placeholder="留空表示不限量"
                    value={formData.totalQuantity || ''}
                    onChange={(e) => setFormData((prev) => ({ ...prev, totalQuantity: e.target.value ? Number(e.target.value) : null }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm">开始时间</Label>
                  <Input
                    type="datetime-local"
                    value={formData.startTime}
                    onChange={(e) => setFormData((prev) => ({ ...prev, startTime: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">结束时间</Label>
                  <Input
                    type="datetime-local"
                    value={formData.endTime}
                    onChange={(e) => setFormData((prev) => ({ ...prev, endTime: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-3">
                  <Switch
                    checked={formData.status === 'active'}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, status: checked ? 'active' : 'inactive' }))}
                  />
                  <Label className="text-sm">立即启用</Label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>取消</Button>
                <Button onClick={handleSave}>保存</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isStatsDialogOpen} onOpenChange={setIsStatsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-lg font-semibold">使用统计</DialogTitle>
            </DialogHeader>
            {selectedCode && (
              <div className="space-y-5 py-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <div className="font-medium text-gray-900">{selectedCode.name}</div>
                    <div className="text-sm text-gray-500">{selectedCode.code}</div>
                  </div>
                  <Badge className={selectedCode.status === 'active' ? 'bg-gray-900 text-white' : ''}>
                    {selectedCode.status === 'active' ? '启用中' : '已禁用'}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 border rounded-xl">
                    <div className="text-sm text-gray-500">已使用</div>
                    <div className="text-2xl font-semibold text-gray-900 mt-1">{selectedCode.usedQuantity}</div>
                  </div>
                  <div className="p-4 border rounded-xl">
                    <div className="text-sm text-gray-500">剩余</div>
                    <div className="text-2xl font-semibold text-gray-900 mt-1">
                      {selectedCode.totalQuantity ? selectedCode.totalQuantity - selectedCode.usedQuantity : '∞'}
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-xl">
                  <div className="text-sm text-gray-500 mb-3">使用率</div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gray-900 transition-all"
                      style={{ width: `${selectedCode.totalQuantity ? Math.min((selectedCode.usedQuantity / selectedCode.totalQuantity) * 100, 100) : Math.min(selectedCode.usedQuantity / 100, 100)}%` }}
                    />
                  </div>
                  <div className="text-right text-sm text-gray-500 mt-2">
                    {selectedCode.totalQuantity ? `${Math.round((selectedCode.usedQuantity / selectedCode.totalQuantity) * 100)}%` : `${selectedCode.usedQuantity} 次`}
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default AdminMarketing;
