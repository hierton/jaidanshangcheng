import React, { useState, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ChevronRight, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';

// 分类数据
interface ICategory {
  id: string;
  name: string;
  count?: number;
}

// 产品数据
interface IProduct {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  image: string;
  isNew?: boolean;
}

// 模拟分类数据
const CATEGORIES: ICategory[] = [
  { id: 'all', name: '全部产品', count: 48 },
  { id: 'mac', name: 'Mac', count: 12 },
  { id: 'ipad', name: 'iPad', count: 8 },
  { id: 'iphone', name: 'iPhone', count: 10 },
  { id: 'watch', name: 'Watch', count: 6 },
  { id: 'airpods', name: 'AirPods', count: 5 },
  { id: 'accessories', name: '配件', count: 7 },
];

// 模拟产品数据
const PRODUCTS: IProduct[] = [
  { id: '1', name: 'MacBook Pro 14', subtitle: 'M3 芯片', price: 12999, image: 'https://picsum.photos/seed/macbook14/600/600', isNew: true },
  { id: '2', name: 'MacBook Pro 16', subtitle: 'M3 Max 芯片', price: 19999, image: 'https://picsum.photos/seed/macbook16/600/600' },
  { id: '3', name: 'iMac 24', subtitle: 'M3 芯片', price: 10999, image: 'https://picsum.photos/seed/imac/600/600' },
  { id: '4', name: 'Mac Studio', subtitle: 'M2 Ultra 芯片', price: 16499, image: 'https://picsum.photos/seed/macstudio/600/600' },
  { id: '5', name: 'Mac mini', subtitle: 'M2 芯片', price: 4499, image: 'https://picsum.photos/seed/macmini/600/600' },
  { id: '6', name: 'Studio Display', subtitle: '27 英寸 5K', price: 11499, image: 'https://picsum.photos/seed/studio/600/600' },
  { id: '7', name: 'Pro Display XDR', subtitle: '32 英寸 6K', price: 39999, image: 'https://picsum.photos/seed/prodisplay/600/600' },
  { id: '8', name: 'MacBook Air 15', subtitle: 'M2 芯片', price: 10499, image: 'https://picsum.photos/seed/macbookair/600/600' },
];

// 排序选项
const SORT_OPTIONS = [
  { value: 'featured', label: '精选' },
  { value: 'newest', label: '最新' },
  { value: 'price_asc', label: '价格从低到高' },
  { value: 'price_desc', label: '价格从高到低' },
];

const CategoryPage: React.FC = () => {
  const { id } = useParams<{ id?: string }>();
  const navigate = useNavigate();

  const [activeCategory, setActiveCategory] = useState(id || 'all');
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);

  // 当前分类
  const currentCategory = useMemo(() => 
    CATEGORIES.find(c => c.id === activeCategory) || CATEGORIES[0],
    [activeCategory]
  );

  // 排序后的产品
  const sortedProducts = useMemo(() => {
    let products = [...PRODUCTS];
    switch (sortBy) {
      case 'newest':
        products.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
        break;
      case 'price_asc':
        products.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        products.sort((a, b) => b.price - a.price);
        break;
      default:
        break;
    }
    return products;
  }, [sortBy]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('zh-CN', {
      style: 'currency',
      currency: 'CNY',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="w-full bg-white">
      <style jsx>{`
        .product-card {
          transition: transform 0.3s ease;
        }
        .product-card:hover {
          transform: scale(1.02);
        }
      `}</style>

      {/* 页面标题 */}
      <section className="w-full bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 md:py-24">
          <h1 className="text-4xl md:text-5xl font-semibold text-gray-900 tracking-tight">
            {currentCategory.name}
          </h1>
          <p className="mt-4 text-lg text-gray-500">
            探索我们的 {currentCategory.name} 系列
          </p>
        </div>
      </section>

      {/* 主内容区 */}
      <section className="w-full max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="flex gap-12">
          {/* 左侧分类导航 */}
          <aside className="w-48 shrink-0 hidden md:block">
            <div className="sticky top-24">
              <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4">
                产品类别
              </h3>
              <ScrollArea className="h-[calc(100vh-300px)]">
                <nav className="space-y-1">
                  {CATEGORIES.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={cn(
                        'w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm transition-all',
                        activeCategory === category.id
                          ? 'bg-gray-900 text-white font-medium'
                          : 'text-gray-600 hover:bg-gray-100'
                      )}
                    >
                      <span>{category.name}</span>
                      <span className={cn(
                        'text-xs',
                        activeCategory === category.id ? 'text-gray-400' : 'text-gray-400'
                      )}>
                        {category.count}
                      </span>
                    </button>
                  ))}
                </nav>
              </ScrollArea>
            </div>
          </aside>

          {/* 右侧产品列表 */}
          <div className="flex-1 min-w-0">
            {/* 工具栏 */}
            <div className="flex items-center justify-between mb-8">
              <p className="text-sm text-gray-500">
                共 {sortedProducts.length} 款产品
              </p>

              <div className="flex items-center gap-4">
                {/* 排序 */}
                <div className="hidden sm:flex items-center gap-2">
                  {SORT_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => setSortBy(option.value)}
                      className={cn(
                        'px-3 py-1.5 rounded-full text-sm transition-colors',
                        sortBy === option.value
                          ? 'bg-gray-900 text-white'
                          : 'text-gray-600 hover:bg-gray-100'
                      )}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>

                {/* 筛选按钮 */}
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2 rounded-full border-gray-200"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <SlidersHorizontal className="w-4 h-4" />
                  筛选
                </Button>
              </div>
            </div>

            <Separator className="mb-8" />

            {/* 产品网格 */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {sortedProducts.map((product) => (
                <Link
                  key={product.id}
                  to={`/product/${product.id}`}
                  className="group product-card block"
                >
                  <div className="relative aspect-square bg-gray-50 rounded-2xl overflow-hidden mb-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    {product.isNew && (
                      <span className="absolute top-4 left-4 px-3 py-1 bg-gray-900 text-white text-xs font-medium rounded-full">
                        新品
                      </span>
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-gray-600 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-500">{product.subtitle}</p>
                    <p className="text-base font-medium text-gray-900 pt-1">
                      {formatPrice(product.price)} 起
                    </p>
                  </div>
                </Link>
              ))}
            </div>

            {/* 加载更多 */}
            <div className="mt-16 text-center">
              <Button 
                variant="outline" 
                className="rounded-full px-8 border-gray-300 hover:bg-gray-900 hover:text-white hover:border-gray-900 transition-all"
              >
                加载更多产品
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* 移动端分类选择 */}
      <div className="md:hidden fixed bottom-6 left-6 right-6 z-50">
        <div className="bg-white rounded-full shadow-lg border border-gray-200 p-1.5 flex overflow-x-auto">
          {CATEGORIES.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                'flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-colors',
                activeCategory === category.id
                  ? 'bg-gray-900 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              )}
            >
              {category.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
