import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import {
  User,
  MapPin,
  Heart,
  ChevronRight,
  Package,
  CreditCard,
  Settings,
  LogOut,
  Plus,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface IAddress {
  id: string;
  name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  isDefault: boolean;
}

interface IFavoriteItem {
  id: string;
  productId: string;
  name: string;
  image: string;
  price: number;
}

interface IUser {
  id: string;
  name: string;
  email: string;
  phone: string;
}

const mockUser: IUser = {
  id: 'u001',
  name: 'Alex Chen',
  email: 'alex@example.com',
  phone: '138****8888',
};

const mockAddresses: IAddress[] = [
  {
    id: 'addr1',
    name: 'Alex Chen',
    phone: '13812345678',
    province: '北京市',
    city: '北京市',
    district: '朝阳区',
    detail: '建国路88号',
    isDefault: true,
  },
  {
    id: 'addr2',
    name: 'Alex Chen',
    phone: '13987654321',
    province: '上海市',
    city: '上海市',
    district: '浦东新区',
    detail: '陆家嘴环路1000号',
    isDefault: false,
  },
];

const mockFavorites: IFavoriteItem[] = [
  {
    id: 'fav1',
    productId: 'p001',
    name: 'MacBook Pro 14"',
    image: 'https://picsum.photos/seed/macbook/400/400',
    price: 14999,
  },
  {
    id: 'fav2',
    productId: 'p002',
    name: 'AirPods Pro',
    image: 'https://picsum.photos/seed/airpods/400/400',
    price: 1999,
  },
  {
    id: 'fav3',
    productId: 'p003',
    name: 'iPhone 15 Pro',
    image: 'https://picsum.photos/seed/iphone/400/400',
    price: 7999,
  },
  {
    id: 'fav4',
    productId: 'p004',
    name: 'iPad Air',
    image: 'https://picsum.photos/seed/ipad/400/400',
    price: 4799,
  },
];

const menuItems = [
  { label: '我的订单', icon: Package, path: '/orders', count: 2 },
  { label: '收货地址', icon: MapPin, path: '#addresses' },
  { label: '我的收藏', icon: Heart, path: '#favorites' },
  { label: '账户设置', icon: Settings, path: '#settings' },
];

const ProfilePage: React.FC = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState<IUser>(mockUser);
  const [addresses, setAddresses] = useState<IAddress[]>(mockAddresses);
  const [favorites, setFavorites] = useState<IFavoriteItem[]>(mockFavorites);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);

  const [addressForm, setAddressForm] = useState<Partial<IAddress>>({
    name: '',
    phone: '',
    province: '',
    city: '',
    district: '',
    detail: '',
    isDefault: false,
  });

  useEffect(() => {
    const hash = window.location.hash;
    if (hash) {
      setActiveSection(hash.slice(1));
      setTimeout(() => {
        const element = document.getElementById(hash.slice(1));
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, []);

  const handleSaveAddress = () => {
    if (!addressForm.name || !addressForm.phone || !addressForm.detail) {
      toast.error('请填写完整信息');
      return;
    }

    const newAddress: IAddress = {
      id: `addr${Date.now()}`,
      name: addressForm.name || '',
      phone: addressForm.phone || '',
      province: addressForm.province || '',
      city: addressForm.city || '',
      district: addressForm.district || '',
      detail: addressForm.detail || '',
      isDefault: addressForm.isDefault || false,
    };

    let updated = [...addresses];
    if (newAddress.isDefault) {
      updated = updated.map((a) => ({ ...a, isDefault: false }));
    }
    setAddresses([...updated, newAddress]);
    setShowAddAddress(false);
    setAddressForm({ name: '', phone: '', province: '', city: '', district: '', detail: '', isDefault: false });
    toast.success('地址已添加');
  };

  const handleDeleteAddress = (id: string) => {
    setAddresses(addresses.filter((a) => a.id !== id));
    toast.success('地址已删除');
  };

  const handleSetDefault = (id: string) => {
    setAddresses(addresses.map((a) => ({ ...a, isDefault: a.id === id })));
  };

  const handleRemoveFavorite = (id: string) => {
    setFavorites(favorites.filter((f) => f.id !== id));
    toast.success('已取消收藏');
  };

  const handleAddToCart = (item: IFavoriteItem) => {
    const cart = JSON.parse(sessionStorage.getItem('__global_shop_cart') || '[]');
    const existing = cart.find((c: { productId: string }) => c.productId === item.productId);
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({
        id: `cart${Date.now()}`,
        productId: item.productId,
        skuId: 'default',
        name: item.name,
        image: item.image,
        specs: {},
        price: item.price,
        quantity: 1,
        stock: 999,
        selected: true,
        valid: true,
      });
    }
    sessionStorage.setItem('__global_shop_cart', JSON.stringify(cart));
    toast.success('已加入购物车');
  };

  const handleLogout = () => {
    sessionStorage.removeItem('__global_shop_user');
    toast.success('已退出');
    navigate('/login');
  };

  return (
    <div className="w-full bg-white">
      {/* Hero Section */}
      <section className="w-full bg-gray-50">
        <div className="max-w-5xl mx-auto px-6 lg:px-8 py-16 md:py-24">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-white shadow-lg">
              <AvatarFallback className="bg-gray-900 text-white text-2xl md:text-3xl font-light">
                {user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="text-center md:text-left">
              <h1 className="text-3xl md:text-4xl font-semibold text-gray-900 tracking-tight">
                {user.name}
              </h1>
              <p className="text-gray-500 mt-2 text-lg">{user.email}</p>
              <p className="text-gray-400 text-sm mt-1">{user.phone}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Grid */}
      <section className="w-full max-w-5xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {menuItems.map((item) => (
            <button
              key={item.label}
              onClick={() => item.path.startsWith('#') ? setActiveSection(item.path.slice(1)) : navigate(item.path)}
              className="group flex flex-col items-center gap-4 p-6 rounded-2xl bg-gray-50 hover:bg-gray-100 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-white shadow-sm flex items-center justify-center">
                <item.icon className="w-5 h-5 text-gray-700" strokeWidth={1.5} />
              </div>
              <div className="text-center">
                <span className="text-sm font-medium text-gray-900">{item.label}</span>
                {item.count && (
                  <span className="ml-1.5 text-xs text-gray-400">({item.count})</span>
                )}
              </div>
            </button>
          ))}
        </div>
      </section>

      <Separator className="max-w-5xl mx-auto" />

      {/* Addresses Section */}
      <section id="addresses" className="w-full max-w-5xl mx-auto px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-semibold text-gray-900">收货地址</h2>
          <Button
            variant="outline"
            onClick={() => setShowAddAddress(true)}
            className="rounded-full px-6"
          >
            <Plus className="w-4 h-4 mr-2" />
            添加地址
          </Button>
        </div>

        {showAddAddress && (
          <div className="bg-gray-50 rounded-2xl p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <Input
                placeholder="姓名"
                value={addressForm.name}
                onChange={(e) => setAddressForm({ ...addressForm, name: e.target.value })}
                className="bg-white border-0 h-12"
              />
              <Input
                placeholder="电话"
                value={addressForm.phone}
                onChange={(e) => setAddressForm({ ...addressForm, phone: e.target.value })}
                className="bg-white border-0 h-12"
              />
            </div>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <Input
                placeholder="省"
                value={addressForm.province}
                onChange={(e) => setAddressForm({ ...addressForm, province: e.target.value })}
                className="bg-white border-0 h-12"
              />
              <Input
                placeholder="市"
                value={addressForm.city}
                onChange={(e) => setAddressForm({ ...addressForm, city: e.target.value })}
                className="bg-white border-0 h-12"
              />
              <Input
                placeholder="区"
                value={addressForm.district}
                onChange={(e) => setAddressForm({ ...addressForm, district: e.target.value })}
                className="bg-white border-0 h-12"
              />
            </div>
            <Input
              placeholder="详细地址"
              value={addressForm.detail}
              onChange={(e) => setAddressForm({ ...addressForm, detail: e.target.value })}
              className="bg-white border-0 h-12 mb-4"
            />
            <div className="flex gap-3">
              <Button onClick={handleSaveAddress} className="rounded-full px-8">
                保存
              </Button>
              <Button variant="ghost" onClick={() => setShowAddAddress(false)}>
                取消
              </Button>
            </div>
          </div>
        )}

        <div className="space-y-4">
          {addresses.map((addr) => (
            <div
              key={addr.id}
              className={cn(
                'flex items-start justify-between p-6 rounded-2xl border transition-colors',
                addr.isDefault ? 'border-gray-900 bg-gray-50' : 'border-gray-200 hover:border-gray-300'
              )}
            >
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <span className="font-medium text-gray-900">{addr.name}</span>
                  <span className="text-gray-500">{addr.phone}</span>
                  {addr.isDefault && (
                    <span className="text-xs bg-gray-900 text-white px-2 py-0.5 rounded-full">
                      默认
                    </span>
                  )}
                </div>
                <p className="text-gray-500 text-sm">
                  {addr.province} {addr.city} {addr.district} {addr.detail}
                </p>
              </div>
              <div className="flex gap-2">
                {!addr.isDefault && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSetDefault(addr.id)}
                    className="text-gray-500"
                  >
                    设为默认
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteAddress(addr.id)}
                  className="text-gray-400 hover:text-red-500"
                >
                  删除
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Separator className="max-w-5xl mx-auto" />

      {/* Favorites Section */}
      <section id="favorites" className="w-full max-w-5xl mx-auto px-6 lg:px-8 py-16">
        <h2 className="text-2xl font-semibold text-gray-900 mb-8">我的收藏</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {favorites.map((item) => (
            <div key={item.id} className="group">
              <div
                className="relative aspect-square rounded-2xl overflow-hidden bg-gray-100 mb-4 cursor-pointer"
                onClick={() => navigate(`/product/${item.productId}`)}
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <button
                  className="absolute top-3 right-3 w-8 h-8 bg-white/90 backdrop-blur rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRemoveFavorite(item.id);
                  }}
                >
                  <X className="w-4 h-4 text-gray-600" />
                </button>
              </div>
              <h3
                className="font-medium text-gray-900 mb-1 cursor-pointer hover:text-gray-600 transition-colors"
                onClick={() => navigate(`/product/${item.productId}`)}
              >
                {item.name}
              </h3>
              <p className="text-gray-500 mb-3">¥{item.price.toLocaleString()}</p>
              <Button
                variant="outline"
                size="sm"
                className="w-full rounded-full"
                onClick={() => handleAddToCart(item)}
              >
                加入购物车
              </Button>
            </div>
          ))}
        </div>
      </section>

      {/* Logout */}
      <section className="w-full max-w-5xl mx-auto px-6 lg:px-8 pb-16">
        <Button
          variant="ghost"
          onClick={handleLogout}
          className="w-full h-14 text-gray-500 hover:text-gray-900 rounded-2xl"
        >
          <LogOut className="w-5 h-5 mr-2" />
          退出登录
        </Button>
      </section>
    </div>
  );
};

export default ProfilePage;
