import React from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';

// Consumer Frontend Pages
import HomePage from './pages/HomePage/HomePage';
import CategoryPage from './pages/CategoryPage/CategoryPage';
import ProductDetailPage from './pages/ProductDetailPage/ProductDetailPage';
import CartPage from './pages/CartPage/CartPage';
import CheckoutPage from './pages/CheckoutPage/CheckoutPage';
import OrdersPage from './pages/OrdersPage/OrdersPage';
import OrderDetailPage from './pages/OrderDetailPage/OrderDetailPage';
import ProfilePage from './pages/ProfilePage/ProfilePage';
import LoginPage from './pages/LoginPage/LoginPage';

// Admin Pages
import AdminLoginPage from './pages/AdminLoginPage/AdminLoginPage';
import AdminDashboard from './pages/AdminDashboard/AdminDashboard';
import AdminProducts from './pages/AdminProducts/AdminProducts';
import AdminProductEdit from './pages/AdminProductEdit/AdminProductEdit';
import AdminOrders from './pages/AdminOrders/AdminOrders';
import AdminOrderDetail from './pages/AdminOrderDetail/AdminOrderDetail';
import AdminMembers from './pages/AdminMembers/AdminMembers';
import AdminMarketing from './pages/AdminMarketing/AdminMarketing';
import AdminStats from './pages/AdminStats/AdminStats';
import AdminSettings from './pages/AdminSettings/AdminSettings';

const RoutesComponent = () => {
  return (
    <Routes>
      {/* Consumer Frontend Routes */}
      <Route path="/" element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="category" element={<CategoryPage />} />
        <Route path="category/:id" element={<CategoryPage />} />
        <Route path="product/:id" element={<ProductDetailPage />} />
        <Route path="cart" element={<CartPage />} />
        <Route path="checkout" element={<CheckoutPage />} />
        <Route path="orders" element={<OrdersPage />} />
        <Route path="orders/:id" element={<OrderDetailPage />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="login" element={<LoginPage />} />
      </Route>

      {/* Admin Login - No Layout */}
      <Route path="/admin/login" element={<AdminLoginPage />} />

      {/* Admin Backend Routes */}
      <Route path="/admin" element={<Layout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="products" element={<AdminProducts />} />
        <Route path="products/:id" element={<AdminProductEdit />} />
        <Route path="orders" element={<AdminOrders />} />
        <Route path="orders/:id" element={<AdminOrderDetail />} />
        <Route path="members" element={<AdminMembers />} />
        <Route path="marketing" element={<AdminMarketing />} />
        <Route path="stats" element={<AdminStats />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
