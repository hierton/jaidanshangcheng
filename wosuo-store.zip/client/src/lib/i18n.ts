import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// 语言类型
type Language = 'zh' | 'en';

// 翻译内容
export const translations = {
  zh: {
    // 通用
    home: '首页',
    products: '产品',
    orders: '订单',
    cart: '购物车',
    profile: '我的账户',
    login: '登录',
    logout: '退出登录',
    search: '搜索',
    save: '保存',
    cancel: '取消',
    confirm: '确认',
    delete: '删除',
    edit: '编辑',
    add: '添加',
    submit: '提交',
    loading: '加载中...',
    
    // 首页
    featuredProducts: '精选产品',
    discoverCollection: '发现我们的主打产品系列',
    viewAll: '查看全部',
    buyNow: '立即购买',
    learnMore: '了解更多',
    newArrivals: '新品上市',
    
    // 产品
    addToCart: '加入购物车',
    buy: '立即购买',
    outOfStock: '暂时缺货',
    description: '产品详情',
    specifications: '规格参数',
    reviews: '用户评价',
    relatedProducts: '相关产品',
    
    // 购物车
    shoppingCart: '购物车',
    emptyCart: '购物车是空的',
    continueShopping: '继续购物',
    selected: '已选',
    items: '件商品',
    total: '合计',
    checkout: '去结算',
    remove: '移除',
    
    // 订单
    orderConfirm: '确认订单',
    shippingAddress: '收货地址',
    paymentMethod: '支付方式',
    orderNotes: '订单备注',
    coupon: '优惠码',
    apply: '应用',
    subtotal: '商品小计',
    shipping: '运费',
    discount: '优惠',
    orderTotal: '订单总额',
    
    // 个人中心
    myOrders: '我的订单',
    addresses: '收货地址',
    favorites: '收藏夹',
    settings: '账户设置',
    
    // Footer
    support: '支持',
    company: '公司',
    legal: '法律',
    contactUs: '联系我们',
    aboutUs: '关于我们',
    helpCenter: '帮助中心',
    privacyPolicy: '隐私政策',
    termsOfService: '用户协议',
    allRightsReserved: '保留所有权利',
    
    // 后台
    admin: '后台管理',
    dashboard: '概览',
    productManagement: '产品管理',
    orderManagement: '订单管理',
    customerManagement: '客户管理',
    marketing: '营销中心',
    statistics: '数据统计',
    systemSettings: '系统设置',
    
    // 语言切换
    language: '语言',
    chinese: '中文',
    english: 'English',
  },
  en: {
    // Common
    home: 'Home',
    products: 'Products',
    orders: 'Orders',
    cart: 'Cart',
    profile: 'Account',
    login: 'Sign In',
    logout: 'Sign Out',
    search: 'Search',
    save: 'Save',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    submit: 'Submit',
    loading: 'Loading...',
    
    // Home
    featuredProducts: 'Featured Products',
    discoverCollection: 'Discover our flagship collection',
    viewAll: 'View All',
    buyNow: 'Buy Now',
    learnMore: 'Learn More',
    newArrivals: 'New Arrivals',
    
    // Product
    addToCart: 'Add to Cart',
    buy: 'Buy Now',
    outOfStock: 'Out of Stock',
    description: 'Description',
    specifications: 'Specifications',
    reviews: 'Reviews',
    relatedProducts: 'Related Products',
    
    // Cart
    shoppingCart: 'Shopping Cart',
    emptyCart: 'Your cart is empty',
    continueShopping: 'Continue Shopping',
    selected: 'Selected',
    items: 'items',
    total: 'Total',
    checkout: 'Checkout',
    remove: 'Remove',
    
    // Order
    orderConfirm: 'Order Confirmation',
    shippingAddress: 'Shipping Address',
    paymentMethod: 'Payment Method',
    orderNotes: 'Order Notes',
    coupon: 'Coupon Code',
    apply: 'Apply',
    subtotal: 'Subtotal',
    shipping: 'Shipping',
    discount: 'Discount',
    orderTotal: 'Order Total',
    
    // Profile
    myOrders: 'My Orders',
    addresses: 'Addresses',
    favorites: 'Favorites',
    settings: 'Settings',
    
    // Footer
    support: 'Support',
    company: 'Company',
    legal: 'Legal',
    contactUs: 'Contact Us',
    aboutUs: 'About Us',
    helpCenter: 'Help Center',
    privacyPolicy: 'Privacy Policy',
    termsOfService: 'Terms of Service',
    allRightsReserved: 'All Rights Reserved',
    
    // Admin
    admin: 'Admin',
    dashboard: 'Dashboard',
    productManagement: 'Products',
    orderManagement: 'Orders',
    customerManagement: 'Customers',
    marketing: 'Marketing',
    statistics: 'Statistics',
    systemSettings: 'Settings',
    
    // Language
    language: 'Language',
    chinese: '中文',
    english: 'English',
  },
};

// 语言状态管理
interface LanguageState {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: keyof typeof translations.zh) => string;
}

export const useLanguage = create<LanguageState>()(
  persist(
    (set, get) => ({
      lang: 'zh',
      setLang: (lang) => set({ lang }),
      t: (key) => {
        const currentLang = get().lang;
        return translations[currentLang][key] || key;
      },
    }),
    {
      name: 'language-storage',
    }
  )
);
