import { useLanguage } from '@/lib/i18n';
import { Globe } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface LanguageSwitcherProps {
  variant?: 'default' | 'minimal';
}

export function LanguageSwitcher({ variant = 'default' }: LanguageSwitcherProps) {
  const { lang, setLang, t } = useLanguage();

  if (variant === 'minimal') {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="flex items-center gap-1.5 text-sm text-gray-600 hover:text-gray-900 transition-colors">
            <Globe className="w-4 h-4" />
            <span className="uppercase">{lang}</span>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setLang('zh')} className={cn(lang === 'zh' && 'bg-gray-100')}>
            中文
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setLang('en')} className={cn(lang === 'en' && 'bg-gray-100')}>
            English
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <Globe className="w-4 h-4" />
          <span>{t('language')}</span>
          <span className="text-gray-400">|</span>
          <span className="uppercase">{lang}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => setLang('zh')} className={cn(lang === 'zh' && 'bg-gray-100')}>
          {t('chinese')}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => setLang('en')} className={cn(lang === 'en' && 'bg-gray-100')}>
          {t('english')}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
