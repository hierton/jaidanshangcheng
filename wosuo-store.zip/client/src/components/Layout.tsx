import { Outlet, Link, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { Search, ShoppingBag, User, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/lib/i18n";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

// 购物车数量
const getCartCount = () => {
  try {
    const cart = JSON.parse(sessionStorage.getItem("__global_shop_cart") || "[]");
    return cart.reduce((sum: number, item: { quantity?: number }) => sum + (item.quantity || 0), 0);
  } catch {
    return 0;
  }
};

// 前台导航 - 使用国际化
const useConsumerNavItems = () => {
  const { t } = useLanguage();
  return [
    { path: "/", label: t('home') },
    { path: "/category", label: t('products') },
    { path: "/orders", label: t('orders') },
  ];
};

// 后台导航
const adminNavItems = [
  { path: "/admin", label: "概览" },
  { path: "/admin/products", label: "产品" },
  { path: "/admin/orders", label: "订单" },
  { path: "/admin/members", label: "客户" },
  { path: "/admin/marketing", label: "营销" },
  { path: "/admin/stats", label: "数据" },
  { path: "/admin/settings", label: "设置" },
];

// 前台极简 Topbar
const ConsumerTopbar = ({ cartCount }: { cartCount: number }) => {
  const { pathname } = useLocation();
  const { t } = useLanguage();
  const consumerNavItems = useConsumerNavItems();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        isScrolled 
          ? "bg-white/80 backdrop-blur-md border-b border-gray-200/50" 
          : "bg-transparent"
      )}
    >
      <div className="mx-auto max-w-7xl h-14 px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <span className="text-xl font-semibold tracking-tight text-gray-900">Wosuo Store</span>
        </Link>

        {/* 桌面端导航 */}
        <nav className="hidden md:flex items-center gap-8">
          {consumerNavItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "text-sm font-medium transition-colors hover:text-gray-900",
                pathname === item.path ? "text-gray-900" : "text-gray-500"
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* 右侧操作区 */}
        <div className="flex items-center gap-3">
          <LanguageSwitcher variant="minimal" />
          
          <Link to="/cart" className="relative p-2 text-gray-600 hover:text-gray-900 transition-colors">
            <ShoppingBag className="w-5 h-5" strokeWidth={1.5} />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-gray-900 text-white text-[10px] font-medium rounded-full flex items-center justify-center">
                {cartCount > 9 ? '9+' : cartCount}
              </span>
            )}
          </Link>
          
          <Link to="/profile" className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
            <User className="w-5 h-5" strokeWidth={1.5} />
          </Link>

          {/* 移动端菜单 */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="h-9 w-9">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80 p-0">
              <div className="flex flex-col h-full">
                <div className="p-6 border-b">
                  <span className="text-xl font-semibold">Store</span>
                </div>
                <nav className="flex-1 p-6">
                  <div className="space-y-4">
                    {consumerNavItems.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        className={cn(
                          "block text-lg font-medium transition-colors",
                          pathname === item.path ? "text-gray-900" : "text-gray-500 hover:text-gray-900"
                        )}
                      >
                        {item.label}
                      </Link>
                    ))}
                  </div>
                </nav>
                <div className="p-6 border-t space-y-3">
                  <Link to="/cart" className="flex items-center justify-between py-2">
                    <span className="text-gray-600">购物车</span>
                    {cartCount > 0 && (
                      <span className="text-sm text-gray-900">{cartCount} 件商品</span>
                    )}
                  </Link>
                  <Link to="/profile" className="block py-2 text-gray-600">
                    我的账户
                  </Link>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

// 前台极简 Footer
const ConsumerFooter = () => {
  const { t } = useLanguage();
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
    <div className="mx-auto max-w-7xl px-6 lg:px-8 py-16">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-4">{t('products')}</h4>
          <ul className="space-y-3 text-sm text-gray-600">
            <li><Link to="/category" className="hover:text-gray-900 transition-colors">{t('viewAll')}</Link></li>
            <li><Link to="/category/new" className="hover:text-gray-900 transition-colors">{t('newArrivals')}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-4">{t('support')}</h4>
          <ul className="space-y-3 text-sm text-gray-600">
            <li><Link to="#" className="hover:text-gray-900 transition-colors">{t('helpCenter')}</Link></li>
            <li><Link to="#" className="hover:text-gray-900 transition-colors">{t('contactUs')}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-4">{t('company')}</h4>
          <ul className="space-y-3 text-sm text-gray-600">
            <li><Link to="#" className="hover:text-gray-900 transition-colors">{t('aboutUs')}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-4">{t('legal')}</h4>
          <ul className="space-y-3 text-sm text-gray-600">
            <li><Link to="#" className="hover:text-gray-900 transition-colors">{t('privacyPolicy')}</Link></li>
            <li><Link to="#" className="hover:text-gray-900 transition-colors">{t('termsOfService')}</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 mb-4">{t('admin')}</h4>
          <ul className="space-y-3 text-sm text-gray-600">
            <li><Link to="/admin/login" className="hover:text-gray-900 transition-colors">{t('admin')}</Link></li>
          </ul>
        </div>
      </div>
      
      <Separator className="my-10" />
      
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-500">
        <p>© 2026 Store. {t('allRightsReserved')}</p>
      </div>
    </div>
  </footer>
  );
};

// 后台 Sidebar
const AdminSidebar = () => {
  const { pathname } = useLocation();

  return (
    <Sidebar className="border-r border-gray-200">
      <SidebarHeader className="border-b border-gray-200 p-4">
        <Link to="/admin" className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gray-900 rounded-lg flex items-center justify-center">
            <span className="text-white font-semibold text-sm">S</span>
          </div>
          <div>
            <span className="font-semibold text-gray-900">Store Admin</span>
          </div>
        </Link>
      </SidebarHeader>

      <SidebarContent className="px-3 py-4">
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-1">
              {adminNavItems.map((item) => (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton 
                    asChild 
                    isActive={pathname === item.path || pathname.startsWith(item.path + "/")}
                    className="h-10"
                  >
                    <Link to={item.path}>
                      <span className="text-sm font-medium">{item.label}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-gray-200 p-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="w-full justify-start gap-3 h-11">
              <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-gray-600" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-gray-900">管理员</p>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuItem asChild>
              <Link to="/" className="cursor-pointer">返回前台</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/admin/login" className="cursor-pointer">退出登录</Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarFooter>
    </Sidebar>
  );
};

// 主布局
const Layout = () => {
  const { pathname } = useLocation();
  const isAdmin = pathname.startsWith("/admin");
  const isAdminLogin = pathname === "/admin/login";
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    setCartCount(getCartCount());
  }, []);

  // 后台登录页 - 无布局
  if (isAdminLogin) {
    return <Outlet />;
  }

  // 后台布局
  if (isAdmin) {
    return (
      <SidebarProvider>
        <AdminSidebar />
        <main className="flex-1 min-w-0 bg-gray-50/50">
          <div className="h-14 border-b border-gray-200 bg-white flex items-center px-6">
            <SidebarTrigger />
          </div>
          <div className="p-6">
            <Outlet />
          </div>
        </main>
      </SidebarProvider>
    );
  }

  // 前台布局
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <ConsumerTopbar cartCount={cartCount} />
      <main className="flex-1 pt-14">
        <Outlet />
      </main>
      <ConsumerFooter />
    </div>
  );
};

export default Layout;
